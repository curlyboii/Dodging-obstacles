﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>



// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.TextCore.Text.FontAsset>
struct Dictionary_2_tC20B3D6AE4370C892734F670EF4D1FB9CE91F371;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32>
struct Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.Character>
struct Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph>
struct Dictionary_2_tC61348D10610A6B3D7B65102D82AC3467D59EAA7;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0;
// System.Collections.Generic.Dictionary`2<System.UInt32,System.Int32>
struct Dictionary_2_t1A4804CA9724B6CE01D6ECABE81CE0848CBA80B4;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteCharacter>
struct Dictionary_2_tD4154357CA320908C5A7A35ED81FA2A9856C28D9;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteGlyph>
struct Dictionary_2_tDC0461D8CBB2E6B52DD2C421114EDE7C1C70DE73;
// System.Collections.Generic.HashSet`1<System.Int32>
struct HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2;
// System.Collections.Generic.HashSet`1<System.UInt32>
struct HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A;
// System.Collections.Generic.IEqualityComparer`1<System.UInt32>
struct IEqualityComparer_1_t0BB8211419723EB61BF19007AC9D62365E50500E;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct KeyCollection_tF62DA58D084558E31E5A09537D460287D59B1A89;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character>
struct List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset>
struct List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>
struct List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C;
// System.Collections.Generic.List`1<UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct List_1_t3CA8EA3609B406A4099002CBD02BB599F3B1D5DB;
// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>
struct List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B;
// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset>
struct List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter>
struct List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteGlyph>
struct List_1_t063B87D3CFDC3AEE80E33EFBDA1410C697D71AD6;
// System.Collections.Generic.List`1<UnityEngine.Texture2D>
struct List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4;
// System.Collections.Generic.List`1<System.UInt32>
struct List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.TextSettings/FontReferenceMap>
struct List_1_tA1547550E5FBA50050B20DA74245C38434654EE8;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct ValueCollection_tB99ECE94AB57EE9AB1FAC3276CC7108B468367C9;
// System.Collections.Generic.Dictionary`2/Entry<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>[]
struct EntryU5BU5D_t68A3C3C2FF61504922EC13C363BED0E17D474FA8;
// System.Collections.Generic.HashSet`1/Slot<System.UInt32>[]
struct SlotU5BU5D_tBF418274114DA8D3D070D784415BF0500C1960C6;
// System.Byte[]
struct ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031;
// System.Char[]
struct CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB;
// UnityEngine.Color32[]
struct Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259;
// UnityEngine.TextCore.Text.FontWeightPair[]
struct FontWeightPairU5BU5D_t76E8DB55C81EEBEFA2E6D1D3E3B3EA1FB4C4954F;
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
// System.Int32Enum[]
struct Int32EnumU5BU5D_t87B7DB802810C38016332669039EF42C487A081F;
// UnityEngine.TextCore.Text.LineInfo[]
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D;
// UnityEngine.TextCore.Text.LinkInfo[]
struct LinkInfoU5BU5D_tB7EB23E47AF29CCBEC884F9D0DB95BC97F62AE51;
// UnityEngine.TextCore.Text.MaterialReference[]
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E;
// UnityEngine.TextCore.Text.MeshInfo[]
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6;
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
// UnityEngine.TextCore.Text.PageInfo[]
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4;
// UnityEngine.TextCore.Text.RichTextTagAttribute[]
struct RichTextTagAttributeU5BU5D_tEE9D071B3246F23742DBF4226567620BCBB24A14;
// System.Single[]
struct SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C;
// UnityEngine.TextCore.Text.SpriteCharacter[]
struct SpriteCharacterU5BU5D_tF4060931C4A985100FE1C44BF53084E1630E96CA;
// UnityEngine.TextCore.Text.TextAlignment[]
struct TextAlignmentU5BU5D_t756DC2D672145699CB9718DDBA5982ED51A95F49;
// UnityEngine.TextCore.Text.TextColorGradient[]
struct TextColorGradientU5BU5D_tA27A5E49640CF01334A10DBDBC959903AFBD941A;
// UnityEngine.TextCore.Text.TextElementInfo[]
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E;
// UnityEngine.TextCore.Text.TextFontWeight[]
struct TextFontWeightU5BU5D_t3DE32809AEE657255C8333897D61F2EA5279D43F;
// UnityEngine.Texture2D[]
struct Texture2DU5BU5D_t05332F1E3F7D4493E304C702201F9BE4F9236191;
// System.UInt32[]
struct UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
// UnityEngine.TextCore.Text.WordInfo[]
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B;
// UnityEngine.TextCore.Text.XmlTagAttribute[]
struct XmlTagAttributeU5BU5D_tEDFE75BDDC81D11CEA2F2A12583516D3BFB309B2;
// UnityEngine.TextCore.Text.Character
struct Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC;
// UnityEngine.Font
struct Font_tC95270EA3198038970422D78B74A7F2E218A96B6;
// UnityEngine.TextCore.Text.FontAsset
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958;
// UnityEngine.TextCore.Text.FontFeatureTable
struct FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7;
// UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F;
// UnityEngine.Material
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3;
// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t3C47F63E24BEB9FCE2DC6309E027F238DC5C5E37;
// UnityEngine.Shader
struct Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692;
// UnityEngine.TextCore.Text.SpriteAsset
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313;
// UnityEngine.TextCore.Text.SpriteCharacter
struct SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5;
// System.String
struct String_t;
// UnityEngine.TextAsset
struct TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69;
// UnityEngine.TextCore.Text.TextAsset
struct TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8;
// UnityEngine.TextCore.Text.TextColorGradient
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70;
// UnityEngine.TextCore.Text.TextElement
struct TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA;
// UnityEngine.TextCore.Text.TextGenerationSettings
struct TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2;
// UnityEngine.TextCore.Text.TextGenerator
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366;
// UnityEngine.TextCore.Text.TextInfo
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09;
// UnityEngine.TextCore.Text.TextSettings
struct TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64;
// UnityEngine.TextCore.Text.TextStyleSheet
struct TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E;
// UnityEngine.Texture
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700;
// UnityEngine.Texture2D
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
// UnityEngine.TextCore.Text.UnicodeLineBreakingRules
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;

IL2CPP_EXTERN_C RuntimeClass* Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E;
IL2CPP_EXTERN_C String_t* _stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D;
IL2CPP_EXTERN_C String_t* _stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m25CB12C13D14620785B0E86F6543D20B5080AFF8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var;
struct Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B;
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7;
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2;

struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D;
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E;
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6;
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4;
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E;
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0  : public RuntimeObject
{
	// System.Int32[] System.Collections.Generic.Dictionary`2::_buckets
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets_0;
	// System.Collections.Generic.Dictionary`2/Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::_entries
	EntryU5BU5D_t68A3C3C2FF61504922EC13C363BED0E17D474FA8* ____entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::_count
	int32_t ____count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::_freeList
	int32_t ____freeList_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::_freeCount
	int32_t ____freeCount_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::_version
	int32_t ____version_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::_comparer
	RuntimeObject* ____comparer_6;
	// System.Collections.Generic.Dictionary`2/KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::_keys
	KeyCollection_tF62DA58D084558E31E5A09537D460287D59B1A89* ____keys_7;
	// System.Collections.Generic.Dictionary`2/ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::_values
	ValueCollection_tB99ECE94AB57EE9AB1FAC3276CC7108B468367C9* ____values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject* ____syncRoot_9;
};

// System.Collections.Generic.HashSet`1<System.UInt32>
struct HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A  : public RuntimeObject
{
	// System.Int32[] System.Collections.Generic.HashSet`1::_buckets
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets_7;
	// System.Collections.Generic.HashSet`1/Slot<T>[] System.Collections.Generic.HashSet`1::_slots
	SlotU5BU5D_tBF418274114DA8D3D070D784415BF0500C1960C6* ____slots_8;
	// System.Int32 System.Collections.Generic.HashSet`1::_count
	int32_t ____count_9;
	// System.Int32 System.Collections.Generic.HashSet`1::_lastIndex
	int32_t ____lastIndex_10;
	// System.Int32 System.Collections.Generic.HashSet`1::_freeList
	int32_t ____freeList_11;
	// System.Collections.Generic.IEqualityComparer`1<T> System.Collections.Generic.HashSet`1::_comparer
	RuntimeObject* ____comparer_12;
	// System.Int32 System.Collections.Generic.HashSet`1::_version
	int32_t ____version_13;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.HashSet`1::_siInfo
	SerializationInfo_t3C47F63E24BEB9FCE2DC6309E027F238DC5C5E37* ____siInfo_14;
};

// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter>
struct List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	SpriteCharacterU5BU5D_tF4060931C4A985100FE1C44BF53084E1630E96CA* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

struct List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	SpriteCharacterU5BU5D_tF4060931C4A985100FE1C44BF53084E1630E96CA* ___s_emptyArray_5;
};
struct Il2CppArrayBounds;

// UnityEngine.TextCore.Text.FontFeatureTable
struct FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7  : public RuntimeObject
{
	// System.Collections.Generic.List`1<UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord> UnityEngine.TextCore.Text.FontFeatureTable::m_GlyphPairAdjustmentRecords
	List_1_t3CA8EA3609B406A4099002CBD02BB599F3B1D5DB* ___m_GlyphPairAdjustmentRecords_0;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord> UnityEngine.TextCore.Text.FontFeatureTable::m_GlyphPairAdjustmentRecordLookup
	Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* ___m_GlyphPairAdjustmentRecordLookup_1;
};

// System.String
struct String_t  : public RuntimeObject
{
	// System.Int32 System.String::_stringLength
	int32_t ____stringLength_4;
	// System.Char System.String::_firstChar
	Il2CppChar ____firstChar_5;
};

struct String_t_StaticFields
{
	// System.String System.String::Empty
	String_t* ___Empty_6;
};

// UnityEngine.TextCore.Text.TextElement
struct TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA  : public RuntimeObject
{
	// UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextElement::m_ElementType
	uint8_t ___m_ElementType_0;
	// System.UInt32 UnityEngine.TextCore.Text.TextElement::m_Unicode
	uint32_t ___m_Unicode_1;
	// UnityEngine.TextCore.Text.TextAsset UnityEngine.TextCore.Text.TextElement::m_TextAsset
	TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* ___m_TextAsset_2;
	// UnityEngine.TextCore.Glyph UnityEngine.TextCore.Text.TextElement::m_Glyph
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* ___m_Glyph_3;
	// System.UInt32 UnityEngine.TextCore.Text.TextElement::m_GlyphIndex
	uint32_t ___m_GlyphIndex_4;
	// System.Single UnityEngine.TextCore.Text.TextElement::m_Scale
	float ___m_Scale_5;
};

// UnityEngine.TextCore.Text.TextShaderUtilities
struct TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692  : public RuntimeObject
{
};

struct TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields
{
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MainTex
	int32_t ___ID_MainTex_0;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_FaceTex
	int32_t ___ID_FaceTex_1;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_FaceColor
	int32_t ___ID_FaceColor_2;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_FaceDilate
	int32_t ___ID_FaceDilate_3;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Shininess
	int32_t ___ID_Shininess_4;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayColor
	int32_t ___ID_UnderlayColor_5;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayOffsetX
	int32_t ___ID_UnderlayOffsetX_6;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayOffsetY
	int32_t ___ID_UnderlayOffsetY_7;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayDilate
	int32_t ___ID_UnderlayDilate_8;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlaySoftness
	int32_t ___ID_UnderlaySoftness_9;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_WeightNormal
	int32_t ___ID_WeightNormal_10;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_WeightBold
	int32_t ___ID_WeightBold_11;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineTex
	int32_t ___ID_OutlineTex_12;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineWidth
	int32_t ___ID_OutlineWidth_13;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineSoftness
	int32_t ___ID_OutlineSoftness_14;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineColor
	int32_t ___ID_OutlineColor_15;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Outline2Color
	int32_t ___ID_Outline2Color_16;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Outline2Width
	int32_t ___ID_Outline2Width_17;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Padding
	int32_t ___ID_Padding_18;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GradientScale
	int32_t ___ID_GradientScale_19;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleX
	int32_t ___ID_ScaleX_20;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleY
	int32_t ___ID_ScaleY_21;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_PerspectiveFilter
	int32_t ___ID_PerspectiveFilter_22;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Sharpness
	int32_t ___ID_Sharpness_23;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_TextureWidth
	int32_t ___ID_TextureWidth_24;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_TextureHeight
	int32_t ___ID_TextureHeight_25;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_BevelAmount
	int32_t ___ID_BevelAmount_26;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowColor
	int32_t ___ID_GlowColor_27;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowOffset
	int32_t ___ID_GlowOffset_28;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowPower
	int32_t ___ID_GlowPower_29;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowOuter
	int32_t ___ID_GlowOuter_30;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowInner
	int32_t ___ID_GlowInner_31;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_LightAngle
	int32_t ___ID_LightAngle_32;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_EnvMap
	int32_t ___ID_EnvMap_33;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_EnvMatrix
	int32_t ___ID_EnvMatrix_34;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_EnvMatrixRotation
	int32_t ___ID_EnvMatrixRotation_35;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MaskCoord
	int32_t ___ID_MaskCoord_36;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ClipRect
	int32_t ___ID_ClipRect_37;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MaskSoftnessX
	int32_t ___ID_MaskSoftnessX_38;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MaskSoftnessY
	int32_t ___ID_MaskSoftnessY_39;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_VertexOffsetX
	int32_t ___ID_VertexOffsetX_40;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_VertexOffsetY
	int32_t ___ID_VertexOffsetY_41;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UseClipRect
	int32_t ___ID_UseClipRect_42;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilID
	int32_t ___ID_StencilID_43;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilOp
	int32_t ___ID_StencilOp_44;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilComp
	int32_t ___ID_StencilComp_45;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilReadMask
	int32_t ___ID_StencilReadMask_46;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilWriteMask
	int32_t ___ID_StencilWriteMask_47;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ShaderFlags
	int32_t ___ID_ShaderFlags_48;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleRatio_A
	int32_t ___ID_ScaleRatio_A_49;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleRatio_B
	int32_t ___ID_ScaleRatio_B_50;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleRatio_C
	int32_t ___ID_ScaleRatio_C_51;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Bevel
	String_t* ___Keyword_Bevel_52;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Glow
	String_t* ___Keyword_Glow_53;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Underlay
	String_t* ___Keyword_Underlay_54;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Ratios
	String_t* ___Keyword_Ratios_55;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_MASK_SOFT
	String_t* ___Keyword_MASK_SOFT_56;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_MASK_HARD
	String_t* ___Keyword_MASK_HARD_57;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_MASK_TEX
	String_t* ___Keyword_MASK_TEX_58;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Outline
	String_t* ___Keyword_Outline_59;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::ShaderTag_ZTestMode
	String_t* ___ShaderTag_ZTestMode_60;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::ShaderTag_CullMode
	String_t* ___ShaderTag_CullMode_61;
	// System.Single UnityEngine.TextCore.Text.TextShaderUtilities::m_clamp
	float ___m_clamp_62;
	// System.Boolean UnityEngine.TextCore.Text.TextShaderUtilities::isInitialized
	bool ___isInitialized_63;
	// UnityEngine.Shader UnityEngine.TextCore.Text.TextShaderUtilities::k_ShaderRef_MobileSDF
	Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692* ___k_ShaderRef_MobileSDF_64;
	// UnityEngine.Shader UnityEngine.TextCore.Text.TextShaderUtilities::k_ShaderRef_MobileBitmap
	Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692* ___k_ShaderRef_MobileBitmap_65;
};

// UnityEngine.TextCore.Text.UnicodeLineBreakingRules
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E  : public RuntimeObject
{
	// UnityEngine.TextAsset UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_UnicodeLineBreakingRules
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_UnicodeLineBreakingRules_1;
	// UnityEngine.TextAsset UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_LeadingCharacters
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_LeadingCharacters_2;
	// UnityEngine.TextAsset UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_FollowingCharacters
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_FollowingCharacters_3;
	// System.Boolean UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_UseModernHangulLineBreakingRules
	bool ___m_UseModernHangulLineBreakingRules_4;
};

struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E_StaticFields
{
	// UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.UnicodeLineBreakingRules::s_Instance
	UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* ___s_Instance_0;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::s_LeadingCharactersLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___s_LeadingCharactersLookup_5;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::s_FollowingCharactersLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___s_FollowingCharactersLookup_6;
};

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>
struct TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32Enum>
struct TextProcessingStack_1_t9C24840D494C4878BD8680855123926D6243C90D 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	Int32EnumU5BU5D_t87B7DB802810C38016332669039EF42C487A081F* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Object>
struct TextProcessingStack_1_t5EA97AAC21CEE068194F77E59929440F85AD3991 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	RuntimeObject* ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>
struct TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	float ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment>
struct TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	TextAlignmentU5BU5D_t756DC2D672145699CB9718DDBA5982ED51A95F49* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient>
struct TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	TextColorGradientU5BU5D_tA27A5E49640CF01334A10DBDBC959903AFBD941A* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight>
struct TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	TextFontWeightU5BU5D_t3DE32809AEE657255C8333897D61F2EA5279D43F* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;
};

struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;
};

// System.Byte
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3 
{
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;
};

// System.Char
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17 
{
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;
};

struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17_StaticFields
{
	// System.Byte[] System.Char::s_categoryForLatin1
	ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031* ___s_categoryForLatin1_3;
};

// UnityEngine.TextCore.Text.Character
struct Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC  : public TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA
{
};

// UnityEngine.Color
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;
};

// UnityEngine.Color32
struct Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B 
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Int32 UnityEngine.Color32::rgba
			int32_t ___rgba_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___rgba_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Byte UnityEngine.Color32::r
			uint8_t ___r_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			uint8_t ___r_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___g_2_OffsetPadding[1];
			// System.Byte UnityEngine.Color32::g
			uint8_t ___g_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___g_2_OffsetPadding_forAlignmentOnly[1];
			uint8_t ___g_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___b_3_OffsetPadding[2];
			// System.Byte UnityEngine.Color32::b
			uint8_t ___b_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___b_3_OffsetPadding_forAlignmentOnly[2];
			uint8_t ___b_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___a_4_OffsetPadding[3];
			// System.Byte UnityEngine.Color32::a
			uint8_t ___a_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___a_4_OffsetPadding_forAlignmentOnly[3];
			uint8_t ___a_4_forAlignmentOnly;
		};
	};
};

// UnityEngine.TextCore.FaceInfo
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 
{
	// System.Int32 UnityEngine.TextCore.FaceInfo::m_FaceIndex
	int32_t ___m_FaceIndex_0;
	// System.String UnityEngine.TextCore.FaceInfo::m_FamilyName
	String_t* ___m_FamilyName_1;
	// System.String UnityEngine.TextCore.FaceInfo::m_StyleName
	String_t* ___m_StyleName_2;
	// System.Int32 UnityEngine.TextCore.FaceInfo::m_PointSize
	int32_t ___m_PointSize_3;
	// System.Single UnityEngine.TextCore.FaceInfo::m_Scale
	float ___m_Scale_4;
	// System.Single UnityEngine.TextCore.FaceInfo::m_LineHeight
	float ___m_LineHeight_5;
	// System.Single UnityEngine.TextCore.FaceInfo::m_AscentLine
	float ___m_AscentLine_6;
	// System.Single UnityEngine.TextCore.FaceInfo::m_CapLine
	float ___m_CapLine_7;
	// System.Single UnityEngine.TextCore.FaceInfo::m_MeanLine
	float ___m_MeanLine_8;
	// System.Single UnityEngine.TextCore.FaceInfo::m_Baseline
	float ___m_Baseline_9;
	// System.Single UnityEngine.TextCore.FaceInfo::m_DescentLine
	float ___m_DescentLine_10;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SuperscriptOffset
	float ___m_SuperscriptOffset_11;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SuperscriptSize
	float ___m_SuperscriptSize_12;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SubscriptOffset
	float ___m_SubscriptOffset_13;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SubscriptSize
	float ___m_SubscriptSize_14;
	// System.Single UnityEngine.TextCore.FaceInfo::m_UnderlineOffset
	float ___m_UnderlineOffset_15;
	// System.Single UnityEngine.TextCore.FaceInfo::m_UnderlineThickness
	float ___m_UnderlineThickness_16;
	// System.Single UnityEngine.TextCore.FaceInfo::m_StrikethroughOffset
	float ___m_StrikethroughOffset_17;
	// System.Single UnityEngine.TextCore.FaceInfo::m_StrikethroughThickness
	float ___m_StrikethroughThickness_18;
	// System.Single UnityEngine.TextCore.FaceInfo::m_TabWidth
	float ___m_TabWidth_19;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.FaceInfo
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756_marshaled_pinvoke
{
	int32_t ___m_FaceIndex_0;
	char* ___m_FamilyName_1;
	char* ___m_StyleName_2;
	int32_t ___m_PointSize_3;
	float ___m_Scale_4;
	float ___m_LineHeight_5;
	float ___m_AscentLine_6;
	float ___m_CapLine_7;
	float ___m_MeanLine_8;
	float ___m_Baseline_9;
	float ___m_DescentLine_10;
	float ___m_SuperscriptOffset_11;
	float ___m_SuperscriptSize_12;
	float ___m_SubscriptOffset_13;
	float ___m_SubscriptSize_14;
	float ___m_UnderlineOffset_15;
	float ___m_UnderlineThickness_16;
	float ___m_StrikethroughOffset_17;
	float ___m_StrikethroughThickness_18;
	float ___m_TabWidth_19;
};
// Native definition for COM marshalling of UnityEngine.TextCore.FaceInfo
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756_marshaled_com
{
	int32_t ___m_FaceIndex_0;
	Il2CppChar* ___m_FamilyName_1;
	Il2CppChar* ___m_StyleName_2;
	int32_t ___m_PointSize_3;
	float ___m_Scale_4;
	float ___m_LineHeight_5;
	float ___m_AscentLine_6;
	float ___m_CapLine_7;
	float ___m_MeanLine_8;
	float ___m_Baseline_9;
	float ___m_DescentLine_10;
	float ___m_SuperscriptOffset_11;
	float ___m_SuperscriptSize_12;
	float ___m_SubscriptOffset_13;
	float ___m_SubscriptSize_14;
	float ___m_UnderlineOffset_15;
	float ___m_UnderlineThickness_16;
	float ___m_StrikethroughOffset_17;
	float ___m_StrikethroughThickness_18;
	float ___m_TabWidth_19;
};

// UnityEngine.TextCore.Text.FontAssetCreationEditorSettings
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52 
{
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::sourceFontFileGUID
	String_t* ___sourceFontFileGUID_0;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::faceIndex
	int32_t ___faceIndex_1;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::pointSizeSamplingMode
	int32_t ___pointSizeSamplingMode_2;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::pointSize
	int32_t ___pointSize_3;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::padding
	int32_t ___padding_4;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::packingMode
	int32_t ___packingMode_5;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::atlasWidth
	int32_t ___atlasWidth_6;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::atlasHeight
	int32_t ___atlasHeight_7;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::characterSetSelectionMode
	int32_t ___characterSetSelectionMode_8;
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::characterSequence
	String_t* ___characterSequence_9;
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::referencedFontAssetGUID
	String_t* ___referencedFontAssetGUID_10;
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::referencedTextAssetGUID
	String_t* ___referencedTextAssetGUID_11;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::fontStyle
	int32_t ___fontStyle_12;
	// System.Single UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::fontStyleModifier
	float ___fontStyleModifier_13;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::renderMode
	int32_t ___renderMode_14;
	// System.Boolean UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::includeFontFeatures
	bool ___includeFontFeatures_15;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.FontAssetCreationEditorSettings
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52_marshaled_pinvoke
{
	char* ___sourceFontFileGUID_0;
	int32_t ___faceIndex_1;
	int32_t ___pointSizeSamplingMode_2;
	int32_t ___pointSize_3;
	int32_t ___padding_4;
	int32_t ___packingMode_5;
	int32_t ___atlasWidth_6;
	int32_t ___atlasHeight_7;
	int32_t ___characterSetSelectionMode_8;
	char* ___characterSequence_9;
	char* ___referencedFontAssetGUID_10;
	char* ___referencedTextAssetGUID_11;
	int32_t ___fontStyle_12;
	float ___fontStyleModifier_13;
	int32_t ___renderMode_14;
	int32_t ___includeFontFeatures_15;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.FontAssetCreationEditorSettings
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52_marshaled_com
{
	Il2CppChar* ___sourceFontFileGUID_0;
	int32_t ___faceIndex_1;
	int32_t ___pointSizeSamplingMode_2;
	int32_t ___pointSize_3;
	int32_t ___padding_4;
	int32_t ___packingMode_5;
	int32_t ___atlasWidth_6;
	int32_t ___atlasHeight_7;
	int32_t ___characterSetSelectionMode_8;
	Il2CppChar* ___characterSequence_9;
	Il2CppChar* ___referencedFontAssetGUID_10;
	Il2CppChar* ___referencedTextAssetGUID_11;
	int32_t ___fontStyle_12;
	float ___fontStyleModifier_13;
	int32_t ___renderMode_14;
	int32_t ___includeFontFeatures_15;
};

// UnityEngine.TextCore.Text.FontStyleStack
struct FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 
{
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::bold
	uint8_t ___bold_0;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::italic
	uint8_t ___italic_1;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::underline
	uint8_t ___underline_2;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::strikethrough
	uint8_t ___strikethrough_3;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::highlight
	uint8_t ___highlight_4;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::superscript
	uint8_t ___superscript_5;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::subscript
	uint8_t ___subscript_6;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::uppercase
	uint8_t ___uppercase_7;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::lowercase
	uint8_t ___lowercase_8;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::smallcaps
	uint8_t ___smallcaps_9;
};

// UnityEngine.TextCore.GlyphMetrics
struct GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A 
{
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_Width
	float ___m_Width_0;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_Height
	float ___m_Height_1;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalBearingX
	float ___m_HorizontalBearingX_2;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalBearingY
	float ___m_HorizontalBearingY_3;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalAdvance
	float ___m_HorizontalAdvance_4;
};

// UnityEngine.TextCore.GlyphRect
struct GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D 
{
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Y
	int32_t ___m_Y_1;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Width
	int32_t ___m_Width_2;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Height
	int32_t ___m_Height_3;
};

struct GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D_StaticFields
{
	// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.GlyphRect::s_ZeroGlyphRect
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___s_ZeroGlyphRect_4;
};

// UnityEngine.TextCore.LowLevel.GlyphValueRecord
struct GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E 
{
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_XPlacement
	float ___m_XPlacement_0;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_YPlacement
	float ___m_YPlacement_1;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_XAdvance
	float ___m_XAdvance_2;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_YAdvance
	float ___m_YAdvance_3;
};

// System.Int32
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

struct IntPtr_t_StaticFields
{
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;
};

// UnityEngine.TextCore.Text.MaterialReference
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 
{
	// System.Int32 UnityEngine.TextCore.Text.MaterialReference::index
	int32_t ___index_0;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.MaterialReference::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.MaterialReference::spriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_2;
	// UnityEngine.Material UnityEngine.TextCore.Text.MaterialReference::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_3;
	// System.Boolean UnityEngine.TextCore.Text.MaterialReference::isDefaultMaterial
	bool ___isDefaultMaterial_4;
	// System.Boolean UnityEngine.TextCore.Text.MaterialReference::isFallbackMaterial
	bool ___isFallbackMaterial_5;
	// UnityEngine.Material UnityEngine.TextCore.Text.MaterialReference::fallbackMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial_6;
	// System.Single UnityEngine.TextCore.Text.MaterialReference::padding
	float ___padding_7;
	// System.Int32 UnityEngine.TextCore.Text.MaterialReference::referenceCount
	int32_t ___referenceCount_8;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.MaterialReference
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26_marshaled_pinvoke
{
	int32_t ___index_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_2;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_3;
	int32_t ___isDefaultMaterial_4;
	int32_t ___isFallbackMaterial_5;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial_6;
	float ___padding_7;
	int32_t ___referenceCount_8;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.MaterialReference
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26_marshaled_com
{
	int32_t ___index_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_2;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_3;
	int32_t ___isDefaultMaterial_4;
	int32_t ___isFallbackMaterial_5;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial_6;
	float ___padding_7;
	int32_t ___referenceCount_8;
};

// UnityEngine.Matrix4x4
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 
{
	// System.Single UnityEngine.Matrix4x4::m00
	float ___m00_0;
	// System.Single UnityEngine.Matrix4x4::m10
	float ___m10_1;
	// System.Single UnityEngine.Matrix4x4::m20
	float ___m20_2;
	// System.Single UnityEngine.Matrix4x4::m30
	float ___m30_3;
	// System.Single UnityEngine.Matrix4x4::m01
	float ___m01_4;
	// System.Single UnityEngine.Matrix4x4::m11
	float ___m11_5;
	// System.Single UnityEngine.Matrix4x4::m21
	float ___m21_6;
	// System.Single UnityEngine.Matrix4x4::m31
	float ___m31_7;
	// System.Single UnityEngine.Matrix4x4::m02
	float ___m02_8;
	// System.Single UnityEngine.Matrix4x4::m12
	float ___m12_9;
	// System.Single UnityEngine.Matrix4x4::m22
	float ___m22_10;
	// System.Single UnityEngine.Matrix4x4::m32
	float ___m32_11;
	// System.Single UnityEngine.Matrix4x4::m03
	float ___m03_12;
	// System.Single UnityEngine.Matrix4x4::m13
	float ___m13_13;
	// System.Single UnityEngine.Matrix4x4::m23
	float ___m23_14;
	// System.Single UnityEngine.Matrix4x4::m33
	float ___m33_15;
};

struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6_StaticFields
{
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::zeroMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___zeroMatrix_16;
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::identityMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___identityMatrix_17;
};

// UnityEngine.TextCore.Text.PageInfo
struct PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 
{
	// System.Int32 UnityEngine.TextCore.Text.PageInfo::firstCharacterIndex
	int32_t ___firstCharacterIndex_0;
	// System.Int32 UnityEngine.TextCore.Text.PageInfo::lastCharacterIndex
	int32_t ___lastCharacterIndex_1;
	// System.Single UnityEngine.TextCore.Text.PageInfo::ascender
	float ___ascender_2;
	// System.Single UnityEngine.TextCore.Text.PageInfo::baseLine
	float ___baseLine_3;
	// System.Single UnityEngine.TextCore.Text.PageInfo::descender
	float ___descender_4;
};

// UnityEngine.Rect
struct Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D 
{
	// System.Single UnityEngine.Rect::m_XMin
	float ___m_XMin_0;
	// System.Single UnityEngine.Rect::m_YMin
	float ___m_YMin_1;
	// System.Single UnityEngine.Rect::m_Width
	float ___m_Width_2;
	// System.Single UnityEngine.Rect::m_Height
	float ___m_Height_3;
};

// System.Single
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	// System.Single System.Single::m_value
	float ___m_value_0;
};

// UnityEngine.TextCore.Text.SpriteCharacter
struct SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5  : public TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA
{
	// System.String UnityEngine.TextCore.Text.SpriteCharacter::m_Name
	String_t* ___m_Name_6;
	// System.Int32 UnityEngine.TextCore.Text.SpriteCharacter::m_HashCode
	int32_t ___m_HashCode_7;
};

// System.UInt32
struct UInt32_t1833D51FFA667B18A5AA4B8D34DE284F8495D29B 
{
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;
};

// UnityEngine.Vector2
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;
};

struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___negativeInfinityVector_9;
};

// UnityEngine.Vector3
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;
};

struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields
{
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___negativeInfinityVector_14;
};

// UnityEngine.Vector4
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 
{
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;
};

struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3_StaticFields
{
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___negativeInfinityVector_8;
};

// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};

// UnityEngine.TextCore.Text.WordInfo
struct WordInfo_tA466206097891A5A2590896EE164AFC406EB060D 
{
	// System.Int32 UnityEngine.TextCore.Text.WordInfo::firstCharacterIndex
	int32_t ___firstCharacterIndex_0;
	// System.Int32 UnityEngine.TextCore.Text.WordInfo::lastCharacterIndex
	int32_t ___lastCharacterIndex_1;
	// System.Int32 UnityEngine.TextCore.Text.WordInfo::characterCount
	int32_t ___characterCount_2;
};

// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD 
{
	// UnityEngine.TextCore.Text.Character UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::character
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character_0;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_2;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::materialIndex
	int32_t ___materialIndex_3;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD_marshaled_pinvoke
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_2;
	int32_t ___materialIndex_3;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD_marshaled_com
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_2;
	int32_t ___materialIndex_3;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>
struct TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>
struct TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.Extents
struct Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 
{
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.Extents::min
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___min_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.Extents::max
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___max_1;
};

// UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F  : public RuntimeObject
{
	// System.UInt32 UnityEngine.TextCore.Glyph::m_Index
	uint32_t ___m_Index_0;
	// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::m_Metrics
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics_1;
	// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::m_GlyphRect
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect_2;
	// System.Single UnityEngine.TextCore.Glyph::m_Scale
	float ___m_Scale_3;
	// System.Int32 UnityEngine.TextCore.Glyph::m_AtlasIndex
	int32_t ___m_AtlasIndex_4;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_pinvoke
{
	uint32_t ___m_Index_0;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics_1;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect_2;
	float ___m_Scale_3;
	int32_t ___m_AtlasIndex_4;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_com
{
	uint32_t ___m_Index_0;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics_1;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect_2;
	float ___m_Scale_3;
	int32_t ___m_AtlasIndex_4;
};

// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord
struct GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 
{
	// System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::m_GlyphIndex
	uint32_t ___m_GlyphIndex_0;
	// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::m_GlyphValueRecord
	GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___m_GlyphValueRecord_1;
};

// UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F 
{
	// System.Int32 UnityEngine.TextCore.Text.MeshInfo::vertexCount
	int32_t ___vertexCount_1;
	// UnityEngine.Vector3[] UnityEngine.TextCore.Text.MeshInfo::vertices
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___vertices_2;
	// UnityEngine.Vector2[] UnityEngine.TextCore.Text.MeshInfo::uvs0
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___uvs0_3;
	// UnityEngine.Vector2[] UnityEngine.TextCore.Text.MeshInfo::uvs2
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___uvs2_4;
	// UnityEngine.Color32[] UnityEngine.TextCore.Text.MeshInfo::colors32
	Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259* ___colors32_5;
	// System.Int32[] UnityEngine.TextCore.Text.MeshInfo::triangles
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___triangles_6;
	// UnityEngine.Material UnityEngine.TextCore.Text.MeshInfo::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
};

struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_StaticFields
{
	// UnityEngine.Color32 UnityEngine.TextCore.Text.MeshInfo::k_DefaultColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___k_DefaultColor_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_marshaled_pinvoke
{
	int32_t ___vertexCount_1;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___vertices_2;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs0_3;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs2_4;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* ___colors32_5;
	Il2CppSafeArray/*NONE*/* ___triangles_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_marshaled_com
{
	int32_t ___vertexCount_1;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___vertices_2;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs0_3;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs2_4;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* ___colors32_5;
	Il2CppSafeArray/*NONE*/* ___triangles_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
};

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;
};

struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;
};
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// Unity.Profiling.ProfilerMarker
struct ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD 
{
	// System.IntPtr Unity.Profiling.ProfilerMarker::m_Ptr
	intptr_t ___m_Ptr_0;
};

// UnityEngine.TextCore.Text.TextGenerationSettings
struct TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2  : public RuntimeObject
{
	// System.String UnityEngine.TextCore.Text.TextGenerationSettings::text
	String_t* ___text_0;
	// UnityEngine.Rect UnityEngine.TextCore.Text.TextGenerationSettings::screenRect
	Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D ___screenRect_1;
	// UnityEngine.Vector4 UnityEngine.TextCore.Text.TextGenerationSettings::margins
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___margins_2;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::scale
	float ___scale_3;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextGenerationSettings::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextGenerationSettings::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_5;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextGenerationSettings::spriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_6;
	// UnityEngine.TextCore.Text.TextStyleSheet UnityEngine.TextCore.Text.TextGenerationSettings::styleSheet
	TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E* ___styleSheet_7;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextGenerationSettings::fontStyle
	int32_t ___fontStyle_8;
	// UnityEngine.TextCore.Text.TextSettings UnityEngine.TextCore.Text.TextGenerationSettings::textSettings
	TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* ___textSettings_9;
	// UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.TextGenerationSettings::textAlignment
	int32_t ___textAlignment_10;
	// UnityEngine.TextCore.Text.TextOverflowMode UnityEngine.TextCore.Text.TextGenerationSettings::overflowMode
	int32_t ___overflowMode_11;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::wordWrap
	bool ___wordWrap_12;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::wordWrappingRatio
	float ___wordWrappingRatio_13;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextGenerationSettings::color
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___color_14;
	// UnityEngine.TextCore.Text.TextColorGradient UnityEngine.TextCore.Text.TextGenerationSettings::fontColorGradient
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___fontColorGradient_15;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::tintSprites
	bool ___tintSprites_16;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::overrideRichTextColors
	bool ___overrideRichTextColors_17;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::fontSize
	float ___fontSize_18;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::autoSize
	bool ___autoSize_19;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::fontSizeMin
	float ___fontSizeMin_20;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::fontSizeMax
	float ___fontSizeMax_21;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::enableKerning
	bool ___enableKerning_22;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::richText
	bool ___richText_23;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::isRightToLeft
	bool ___isRightToLeft_24;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::extraPadding
	bool ___extraPadding_25;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::parseControlCharacters
	bool ___parseControlCharacters_26;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::characterSpacing
	float ___characterSpacing_27;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::wordSpacing
	float ___wordSpacing_28;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::lineSpacing
	float ___lineSpacing_29;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::paragraphSpacing
	float ___paragraphSpacing_30;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::lineSpacingMax
	float ___lineSpacingMax_31;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::maxVisibleCharacters
	int32_t ___maxVisibleCharacters_32;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::maxVisibleWords
	int32_t ___maxVisibleWords_33;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::maxVisibleLines
	int32_t ___maxVisibleLines_34;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::firstVisibleCharacter
	int32_t ___firstVisibleCharacter_35;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::useMaxVisibleDescender
	bool ___useMaxVisibleDescender_36;
	// UnityEngine.TextCore.Text.TextFontWeight UnityEngine.TextCore.Text.TextGenerationSettings::fontWeight
	int32_t ___fontWeight_37;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::pageToDisplay
	int32_t ___pageToDisplay_38;
	// UnityEngine.TextCore.Text.TextureMapping UnityEngine.TextCore.Text.TextGenerationSettings::horizontalMapping
	int32_t ___horizontalMapping_39;
	// UnityEngine.TextCore.Text.TextureMapping UnityEngine.TextCore.Text.TextGenerationSettings::verticalMapping
	int32_t ___verticalMapping_40;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::uvLineOffset
	float ___uvLineOffset_41;
	// UnityEngine.TextCore.Text.VertexSortingOrder UnityEngine.TextCore.Text.TextGenerationSettings::geometrySortingOrder
	int32_t ___geometrySortingOrder_42;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::inverseYAxis
	bool ___inverseYAxis_43;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::charWidthMaxAdj
	float ___charWidthMaxAdj_44;
};

// UnityEngine.TextCore.Text.TextGeneratorUtilities
struct TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53  : public RuntimeObject
{
};

struct TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGeneratorUtilities::largePositiveVector2
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___largePositiveVector2_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGeneratorUtilities::largeNegativeVector2
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___largeNegativeVector2_1;
};

// UnityEngine.TextCore.Text.TextInfo
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09  : public RuntimeObject
{
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::characterCount
	int32_t ___characterCount_2;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::spriteCount
	int32_t ___spriteCount_3;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::spaceCount
	int32_t ___spaceCount_4;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::wordCount
	int32_t ___wordCount_5;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::linkCount
	int32_t ___linkCount_6;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::lineCount
	int32_t ___lineCount_7;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::pageCount
	int32_t ___pageCount_8;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::materialCount
	int32_t ___materialCount_9;
	// UnityEngine.TextCore.Text.TextElementInfo[] UnityEngine.TextCore.Text.TextInfo::textElementInfo
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* ___textElementInfo_10;
	// UnityEngine.TextCore.Text.WordInfo[] UnityEngine.TextCore.Text.TextInfo::wordInfo
	WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* ___wordInfo_11;
	// UnityEngine.TextCore.Text.LinkInfo[] UnityEngine.TextCore.Text.TextInfo::linkInfo
	LinkInfoU5BU5D_tB7EB23E47AF29CCBEC884F9D0DB95BC97F62AE51* ___linkInfo_12;
	// UnityEngine.TextCore.Text.LineInfo[] UnityEngine.TextCore.Text.TextInfo::lineInfo
	LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* ___lineInfo_13;
	// UnityEngine.TextCore.Text.PageInfo[] UnityEngine.TextCore.Text.TextInfo::pageInfo
	PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* ___pageInfo_14;
	// UnityEngine.TextCore.Text.MeshInfo[] UnityEngine.TextCore.Text.TextInfo::meshInfo
	MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* ___meshInfo_15;
	// System.Boolean UnityEngine.TextCore.Text.TextInfo::isDirty
	bool ___isDirty_16;
};

struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextInfo::s_InfinityVectorPositive
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___s_InfinityVectorPositive_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextInfo::s_InfinityVectorNegative
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___s_InfinityVectorNegative_1;
};

// UnityEngine.TextCore.Text.TextVertex
struct TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 
{
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextVertex::position
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___position_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextVertex::uv
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv_1;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextVertex::uv2
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv2_2;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextVertex::uv4
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv4_3;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextVertex::color
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_4;
};

// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord
struct GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E 
{
	// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_FirstAdjustmentRecord
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 ___m_FirstAdjustmentRecord_0;
	// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_SecondAdjustmentRecord
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 ___m_SecondAdjustmentRecord_1;
	// UnityEngine.TextCore.LowLevel.FontFeatureLookupFlags UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_FeatureLookupFlags
	int32_t ___m_FeatureLookupFlags_2;
};

// UnityEngine.TextCore.Text.LineInfo
struct LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 
{
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::controlCharacterCount
	int32_t ___controlCharacterCount_0;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::characterCount
	int32_t ___characterCount_1;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::visibleCharacterCount
	int32_t ___visibleCharacterCount_2;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::spaceCount
	int32_t ___spaceCount_3;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::visibleSpaceCount
	int32_t ___visibleSpaceCount_4;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::wordCount
	int32_t ___wordCount_5;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::firstCharacterIndex
	int32_t ___firstCharacterIndex_6;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::firstVisibleCharacterIndex
	int32_t ___firstVisibleCharacterIndex_7;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::lastCharacterIndex
	int32_t ___lastCharacterIndex_8;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::lastVisibleCharacterIndex
	int32_t ___lastVisibleCharacterIndex_9;
	// System.Single UnityEngine.TextCore.Text.LineInfo::length
	float ___length_10;
	// System.Single UnityEngine.TextCore.Text.LineInfo::lineHeight
	float ___lineHeight_11;
	// System.Single UnityEngine.TextCore.Text.LineInfo::ascender
	float ___ascender_12;
	// System.Single UnityEngine.TextCore.Text.LineInfo::baseline
	float ___baseline_13;
	// System.Single UnityEngine.TextCore.Text.LineInfo::descender
	float ___descender_14;
	// System.Single UnityEngine.TextCore.Text.LineInfo::maxAdvance
	float ___maxAdvance_15;
	// System.Single UnityEngine.TextCore.Text.LineInfo::width
	float ___width_16;
	// System.Single UnityEngine.TextCore.Text.LineInfo::marginLeft
	float ___marginLeft_17;
	// System.Single UnityEngine.TextCore.Text.LineInfo::marginRight
	float ___marginRight_18;
	// UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.LineInfo::alignment
	int32_t ___alignment_19;
	// UnityEngine.TextCore.Text.Extents UnityEngine.TextCore.Text.LineInfo::lineExtents
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___lineExtents_20;
};

// UnityEngine.Material
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// UnityEngine.ScriptableObject
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_pinvoke : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_com : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
};

// UnityEngine.TextCore.Text.TextElementInfo
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 
{
	// System.Char UnityEngine.TextCore.Text.TextElementInfo::character
	Il2CppChar ___character_0;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::index
	int32_t ___index_1;
	// UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextElementInfo::elementType
	uint8_t ___elementType_2;
	// UnityEngine.TextCore.Text.TextElement UnityEngine.TextCore.Text.TextElementInfo::textElement
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement_3;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextElementInfo::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextElementInfo::spriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_5;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::spriteIndex
	int32_t ___spriteIndex_6;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextElementInfo::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::materialReferenceIndex
	int32_t ___materialReferenceIndex_8;
	// System.Boolean UnityEngine.TextCore.Text.TextElementInfo::isUsingAlternateTypeface
	bool ___isUsingAlternateTypeface_9;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::pointSize
	float ___pointSize_10;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::lineNumber
	int32_t ___lineNumber_11;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::pageNumber
	int32_t ___pageNumber_12;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::vertexIndex
	int32_t ___vertexIndex_13;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexTopLeft
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft_14;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexBottomLeft
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft_15;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexTopRight
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight_16;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexBottomRight
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight_17;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::topLeft
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft_18;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::bottomLeft
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft_19;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::topRight
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight_20;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::bottomRight
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight_21;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::origin
	float ___origin_22;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::ascender
	float ___ascender_23;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::baseLine
	float ___baseLine_24;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::descender
	float ___descender_25;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::xAdvance
	float ___xAdvance_26;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::aspectRatio
	float ___aspectRatio_27;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::scale
	float ___scale_28;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::color
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_29;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::underlineColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::strikethroughColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::highlightColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextElementInfo::style
	int32_t ___style_33;
	// System.Boolean UnityEngine.TextCore.Text.TextElementInfo::isVisible
	bool ___isVisible_34;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.TextElementInfo
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976_marshaled_pinvoke
{
	uint8_t ___character_0;
	int32_t ___index_1;
	uint8_t ___elementType_2;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement_3;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_5;
	int32_t ___spriteIndex_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
	int32_t ___materialReferenceIndex_8;
	int32_t ___isUsingAlternateTypeface_9;
	float ___pointSize_10;
	int32_t ___lineNumber_11;
	int32_t ___pageNumber_12;
	int32_t ___vertexIndex_13;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft_14;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft_15;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight_16;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight_17;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft_18;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft_19;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight_20;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight_21;
	float ___origin_22;
	float ___ascender_23;
	float ___baseLine_24;
	float ___descender_25;
	float ___xAdvance_26;
	float ___aspectRatio_27;
	float ___scale_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	int32_t ___style_33;
	int32_t ___isVisible_34;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.TextElementInfo
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976_marshaled_com
{
	uint8_t ___character_0;
	int32_t ___index_1;
	uint8_t ___elementType_2;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement_3;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_5;
	int32_t ___spriteIndex_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
	int32_t ___materialReferenceIndex_8;
	int32_t ___isUsingAlternateTypeface_9;
	float ___pointSize_10;
	int32_t ___lineNumber_11;
	int32_t ___pageNumber_12;
	int32_t ___vertexIndex_13;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft_14;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft_15;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight_16;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight_17;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft_18;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft_19;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight_20;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight_21;
	float ___origin_22;
	float ___ascender_23;
	float ___baseLine_24;
	float ___descender_25;
	float ___xAdvance_26;
	float ___aspectRatio_27;
	float ___scale_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	int32_t ___style_33;
	int32_t ___isVisible_34;
};

// UnityEngine.TextCore.Text.TextAsset
struct TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	// System.String UnityEngine.TextCore.Text.TextAsset::m_Version
	String_t* ___m_Version_4;
	// System.Int32 UnityEngine.TextCore.Text.TextAsset::m_InstanceID
	int32_t ___m_InstanceID_5;
	// System.Int32 UnityEngine.TextCore.Text.TextAsset::m_HashCode
	int32_t ___m_HashCode_6;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextAsset::m_Material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_Material_7;
	// System.Int32 UnityEngine.TextCore.Text.TextAsset::m_MaterialHashCode
	int32_t ___m_MaterialHashCode_8;
};

// UnityEngine.TextCore.Text.TextColorGradient
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	// UnityEngine.TextCore.Text.ColorGradientMode UnityEngine.TextCore.Text.TextColorGradient::colorMode
	int32_t ___colorMode_4;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::topLeft
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___topLeft_5;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::topRight
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___topRight_6;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::bottomLeft
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___bottomLeft_7;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::bottomRight
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___bottomRight_8;
};

struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70_StaticFields
{
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::k_DefaultColor
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___k_DefaultColor_10;
};

// UnityEngine.TextCore.Text.TextSettings
struct TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	// System.String UnityEngine.TextCore.Text.TextSettings::m_Version
	String_t* ___m_Version_4;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextSettings::m_DefaultFontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___m_DefaultFontAsset_5;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_DefaultFontAssetPath
	String_t* ___m_DefaultFontAssetPath_6;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.TextSettings::m_FallbackFontAssets
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___m_FallbackFontAssets_7;
	// System.Boolean UnityEngine.TextCore.Text.TextSettings::m_MatchMaterialPreset
	bool ___m_MatchMaterialPreset_8;
	// System.Int32 UnityEngine.TextCore.Text.TextSettings::m_MissingCharacterUnicode
	int32_t ___m_MissingCharacterUnicode_9;
	// System.Boolean UnityEngine.TextCore.Text.TextSettings::m_ClearDynamicDataOnBuild
	bool ___m_ClearDynamicDataOnBuild_10;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextSettings::m_DefaultSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_DefaultSpriteAsset_11;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_DefaultSpriteAssetPath
	String_t* ___m_DefaultSpriteAssetPath_12;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset> UnityEngine.TextCore.Text.TextSettings::m_FallbackSpriteAssets
	List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320* ___m_FallbackSpriteAssets_13;
	// System.UInt32 UnityEngine.TextCore.Text.TextSettings::m_MissingSpriteCharacterUnicode
	uint32_t ___m_MissingSpriteCharacterUnicode_14;
	// UnityEngine.TextCore.Text.TextStyleSheet UnityEngine.TextCore.Text.TextSettings::m_DefaultStyleSheet
	TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E* ___m_DefaultStyleSheet_15;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_StyleSheetsResourcePath
	String_t* ___m_StyleSheetsResourcePath_16;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_DefaultColorGradientPresetsPath
	String_t* ___m_DefaultColorGradientPresetsPath_17;
	// UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.TextSettings::m_UnicodeLineBreakingRules
	UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* ___m_UnicodeLineBreakingRules_18;
	// System.Boolean UnityEngine.TextCore.Text.TextSettings::m_DisplayWarnings
	bool ___m_DisplayWarnings_19;
	// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.TextSettings::m_FontLookup
	Dictionary_2_tC20B3D6AE4370C892734F670EF4D1FB9CE91F371* ___m_FontLookup_20;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.TextSettings/FontReferenceMap> UnityEngine.TextCore.Text.TextSettings::m_FontReferences
	List_1_tA1547550E5FBA50050B20DA74245C38434654EE8* ___m_FontReferences_21;
};

// UnityEngine.TextCore.Text.WordWrapState
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 
{
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::previousWordBreak
	int32_t ___previousWordBreak_0;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::totalCharacterCount
	int32_t ___totalCharacterCount_1;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::visibleCharacterCount
	int32_t ___visibleCharacterCount_2;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::visibleSpriteCount
	int32_t ___visibleSpriteCount_3;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::visibleLinkCount
	int32_t ___visibleLinkCount_4;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::firstCharacterIndex
	int32_t ___firstCharacterIndex_5;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::firstVisibleCharacterIndex
	int32_t ___firstVisibleCharacterIndex_6;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::lastCharacterIndex
	int32_t ___lastCharacterIndex_7;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::lastVisibleCharIndex
	int32_t ___lastVisibleCharIndex_8;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::lineNumber
	int32_t ___lineNumber_9;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxCapHeight
	float ___maxCapHeight_10;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxAscender
	float ___maxAscender_11;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxDescender
	float ___maxDescender_12;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxLineAscender
	float ___maxLineAscender_13;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxLineDescender
	float ___maxLineDescender_14;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::previousLineAscender
	float ___previousLineAscender_15;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::xAdvance
	float ___xAdvance_16;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::preferredWidth
	float ___preferredWidth_17;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::preferredHeight
	float ___preferredHeight_18;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::previousLineScale
	float ___previousLineScale_19;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::wordCount
	int32_t ___wordCount_20;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.WordWrapState::fontStyle
	int32_t ___fontStyle_21;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::fontScale
	float ___fontScale_22;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::fontScaleMultiplier
	float ___fontScaleMultiplier_23;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::currentFontSize
	float ___currentFontSize_24;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::baselineOffset
	float ___baselineOffset_25;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::lineOffset
	float ___lineOffset_26;
	// UnityEngine.TextCore.Text.TextInfo UnityEngine.TextCore.Text.WordWrapState::textInfo
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo_27;
	// UnityEngine.TextCore.Text.LineInfo UnityEngine.TextCore.Text.WordWrapState::lineInfo
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo_28;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::vertexColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor_29;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::underlineColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::strikethroughColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::highlightColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	// UnityEngine.TextCore.Text.FontStyleStack UnityEngine.TextCore.Text.WordWrapState::basicStyleStack
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack_33;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::colorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack_34;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::underlineColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack_35;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::strikethroughColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack_36;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::highlightColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack_37;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient> UnityEngine.TextCore.Text.WordWrapState::colorGradientStack
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack_38;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.WordWrapState::sizeStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack_39;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.WordWrapState::indentStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack_40;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight> UnityEngine.TextCore.Text.WordWrapState::fontWeightStack
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack_41;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.WordWrapState::styleStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack_42;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.WordWrapState::baselineStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack_43;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.WordWrapState::actionStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack_44;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference> UnityEngine.TextCore.Text.WordWrapState::materialReferenceStack
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack_45;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment> UnityEngine.TextCore.Text.WordWrapState::lineJustificationStack
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack_46;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::spriteAnimationId
	int32_t ___spriteAnimationId_47;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.WordWrapState::currentFontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset_48;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.WordWrapState::currentSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset_49;
	// UnityEngine.Material UnityEngine.TextCore.Text.WordWrapState::currentMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial_50;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::currentMaterialIndex
	int32_t ___currentMaterialIndex_51;
	// UnityEngine.TextCore.Text.Extents UnityEngine.TextCore.Text.WordWrapState::meshExtents
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents_52;
	// System.Boolean UnityEngine.TextCore.Text.WordWrapState::tagNoParsing
	bool ___tagNoParsing_53;
	// System.Boolean UnityEngine.TextCore.Text.WordWrapState::isNonBreakingSpace
	bool ___isNonBreakingSpace_54;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.WordWrapState
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123_marshaled_pinvoke
{
	int32_t ___previousWordBreak_0;
	int32_t ___totalCharacterCount_1;
	int32_t ___visibleCharacterCount_2;
	int32_t ___visibleSpriteCount_3;
	int32_t ___visibleLinkCount_4;
	int32_t ___firstCharacterIndex_5;
	int32_t ___firstVisibleCharacterIndex_6;
	int32_t ___lastCharacterIndex_7;
	int32_t ___lastVisibleCharIndex_8;
	int32_t ___lineNumber_9;
	float ___maxCapHeight_10;
	float ___maxAscender_11;
	float ___maxDescender_12;
	float ___maxLineAscender_13;
	float ___maxLineDescender_14;
	float ___previousLineAscender_15;
	float ___xAdvance_16;
	float ___preferredWidth_17;
	float ___preferredHeight_18;
	float ___previousLineScale_19;
	int32_t ___wordCount_20;
	int32_t ___fontStyle_21;
	float ___fontScale_22;
	float ___fontScaleMultiplier_23;
	float ___currentFontSize_24;
	float ___baselineOffset_25;
	float ___lineOffset_26;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo_27;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack_33;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack_34;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack_35;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack_36;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack_37;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack_38;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack_39;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack_40;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack_41;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack_42;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack_43;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack_44;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack_45;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack_46;
	int32_t ___spriteAnimationId_47;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset_48;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset_49;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial_50;
	int32_t ___currentMaterialIndex_51;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents_52;
	int32_t ___tagNoParsing_53;
	int32_t ___isNonBreakingSpace_54;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.WordWrapState
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123_marshaled_com
{
	int32_t ___previousWordBreak_0;
	int32_t ___totalCharacterCount_1;
	int32_t ___visibleCharacterCount_2;
	int32_t ___visibleSpriteCount_3;
	int32_t ___visibleLinkCount_4;
	int32_t ___firstCharacterIndex_5;
	int32_t ___firstVisibleCharacterIndex_6;
	int32_t ___lastCharacterIndex_7;
	int32_t ___lastVisibleCharIndex_8;
	int32_t ___lineNumber_9;
	float ___maxCapHeight_10;
	float ___maxAscender_11;
	float ___maxDescender_12;
	float ___maxLineAscender_13;
	float ___maxLineDescender_14;
	float ___previousLineAscender_15;
	float ___xAdvance_16;
	float ___preferredWidth_17;
	float ___preferredHeight_18;
	float ___previousLineScale_19;
	int32_t ___wordCount_20;
	int32_t ___fontStyle_21;
	float ___fontScale_22;
	float ___fontScaleMultiplier_23;
	float ___currentFontSize_24;
	float ___baselineOffset_25;
	float ___lineOffset_26;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo_27;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack_33;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack_34;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack_35;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack_36;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack_37;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack_38;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack_39;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack_40;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack_41;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack_42;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack_43;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack_44;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack_45;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack_46;
	int32_t ___spriteAnimationId_47;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset_48;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset_49;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial_50;
	int32_t ___currentMaterialIndex_51;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents_52;
	int32_t ___tagNoParsing_53;
	int32_t ___isNonBreakingSpace_54;
};

// UnityEngine.TextCore.Text.FontAsset
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958  : public TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8
{
	// System.String UnityEngine.TextCore.Text.FontAsset::m_SourceFontFileGUID
	String_t* ___m_SourceFontFileGUID_9;
	// UnityEngine.Font UnityEngine.TextCore.Text.FontAsset::m_SourceFontFile
	Font_tC95270EA3198038970422D78B74A7F2E218A96B6* ___m_SourceFontFile_10;
	// UnityEngine.TextCore.Text.AtlasPopulationMode UnityEngine.TextCore.Text.FontAsset::m_AtlasPopulationMode
	int32_t ___m_AtlasPopulationMode_11;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::InternalDynamicOS
	bool ___InternalDynamicOS_12;
	// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.FontAsset::m_FaceInfo
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 ___m_FaceInfo_13;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_FamilyNameHashCode
	int32_t ___m_FamilyNameHashCode_14;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_StyleNameHashCode
	int32_t ___m_StyleNameHashCode_15;
	// UnityEngine.TextCore.Text.FontWeightPair[] UnityEngine.TextCore.Text.FontAsset::m_FontWeightTable
	FontWeightPairU5BU5D_t76E8DB55C81EEBEFA2E6D1D3E3B3EA1FB4C4954F* ___m_FontWeightTable_16;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphTable
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphTable_17;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphLookupDictionary
	Dictionary_2_tC61348D10610A6B3D7B65102D82AC3467D59EAA7* ___m_GlyphLookupDictionary_18;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::m_CharacterTable
	List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317* ___m_CharacterTable_19;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::m_CharacterLookupDictionary
	Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* ___m_CharacterLookupDictionary_20;
	// UnityEngine.Texture2D UnityEngine.TextCore.Text.FontAsset::m_AtlasTexture
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___m_AtlasTexture_21;
	// UnityEngine.Texture2D[] UnityEngine.TextCore.Text.FontAsset::m_AtlasTextures
	Texture2DU5BU5D_t05332F1E3F7D4493E304C702201F9BE4F9236191* ___m_AtlasTextures_22;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasTextureIndex
	int32_t ___m_AtlasTextureIndex_23;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::m_IsMultiAtlasTexturesEnabled
	bool ___m_IsMultiAtlasTexturesEnabled_24;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::m_ClearDynamicDataOnBuild
	bool ___m_ClearDynamicDataOnBuild_25;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasWidth
	int32_t ___m_AtlasWidth_26;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasHeight
	int32_t ___m_AtlasHeight_27;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasPadding
	int32_t ___m_AtlasPadding_28;
	// UnityEngine.TextCore.LowLevel.GlyphRenderMode UnityEngine.TextCore.Text.FontAsset::m_AtlasRenderMode
	int32_t ___m_AtlasRenderMode_29;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect> UnityEngine.TextCore.Text.FontAsset::m_UsedGlyphRects
	List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B* ___m_UsedGlyphRects_30;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect> UnityEngine.TextCore.Text.FontAsset::m_FreeGlyphRects
	List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B* ___m_FreeGlyphRects_31;
	// UnityEngine.TextCore.Text.FontFeatureTable UnityEngine.TextCore.Text.FontAsset::m_FontFeatureTable
	FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* ___m_FontFeatureTable_32;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.FontAsset::m_FallbackFontAssetTable
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___m_FallbackFontAssetTable_33;
	// UnityEngine.TextCore.Text.FontAssetCreationEditorSettings UnityEngine.TextCore.Text.FontAsset::m_fontAssetCreationEditorSettings
	FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52 ___m_fontAssetCreationEditorSettings_34;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_RegularStyleWeight
	float ___m_RegularStyleWeight_35;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_RegularStyleSpacing
	float ___m_RegularStyleSpacing_36;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_BoldStyleWeight
	float ___m_BoldStyleWeight_37;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_BoldStyleSpacing
	float ___m_BoldStyleSpacing_38;
	// System.Byte UnityEngine.TextCore.Text.FontAsset::m_ItalicStyleSlant
	uint8_t ___m_ItalicStyleSlant_39;
	// System.Byte UnityEngine.TextCore.Text.FontAsset::m_TabMultiple
	uint8_t ___m_TabMultiple_40;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::IsFontAssetLookupTablesDirty
	bool ___IsFontAssetLookupTablesDirty_41;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphsToRender
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphsToRender_55;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphsRendered
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphsRendered_56;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphIndexList
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphIndexList_57;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphIndexListNewlyAdded
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphIndexListNewlyAdded_58;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphsToAdd
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphsToAdd_59;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphsToAddLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_GlyphsToAddLookup_60;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::m_CharactersToAdd
	List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317* ___m_CharactersToAdd_61;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_CharactersToAddLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_CharactersToAddLookup_62;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::s_MissingCharacterList
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___s_MissingCharacterList_63;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_MissingUnicodesFromFontFile
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_MissingUnicodesFromFontFile_64;
};

struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958_StaticFields
{
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_ReadFontAssetDefinitionMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_ReadFontAssetDefinitionMarker_42;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_AddSynthesizedCharactersMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_AddSynthesizedCharactersMarker_43;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_TryAddCharacterMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddCharacterMarker_44;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_TryAddCharactersMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddCharactersMarker_45;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_UpdateGlyphAdjustmentRecordsMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateGlyphAdjustmentRecordsMarker_46;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_ClearFontAssetDataMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_ClearFontAssetDataMarker_47;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_UpdateFontAssetDataMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateFontAssetDataMarker_48;
	// System.String UnityEngine.TextCore.Text.FontAsset::s_DefaultMaterialSuffix
	String_t* ___s_DefaultMaterialSuffix_49;
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.FontAsset::k_SearchedFontAssetLookup
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_SearchedFontAssetLookup_50;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_FontFeaturesUpdateQueue
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___k_FontAssets_FontFeaturesUpdateQueue_51;
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_FontFeaturesUpdateQueueLookup
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_FontAssets_FontFeaturesUpdateQueueLookup_52;
	// System.Collections.Generic.List`1<UnityEngine.Texture2D> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_AtlasTexturesUpdateQueue
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___k_FontAssets_AtlasTexturesUpdateQueue_53;
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_AtlasTexturesUpdateQueueLookup
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_FontAssets_AtlasTexturesUpdateQueueLookup_54;
	// System.UInt32[] UnityEngine.TextCore.Text.FontAsset::k_GlyphIndexArray
	UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA* ___k_GlyphIndexArray_65;
};

// UnityEngine.TextCore.Text.SpriteAsset
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313  : public TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8
{
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> UnityEngine.TextCore.Text.SpriteAsset::m_NameLookup
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___m_NameLookup_9;
	// System.Collections.Generic.Dictionary`2<System.UInt32,System.Int32> UnityEngine.TextCore.Text.SpriteAsset::m_GlyphIndexLookup
	Dictionary_2_t1A4804CA9724B6CE01D6ECABE81CE0848CBA80B4* ___m_GlyphIndexLookup_10;
	// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.SpriteAsset::m_FaceInfo
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 ___m_FaceInfo_11;
	// UnityEngine.Texture UnityEngine.TextCore.Text.SpriteAsset::m_SpriteAtlasTexture
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_SpriteAtlasTexture_12;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteCharacterTable
	List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51* ___m_SpriteCharacterTable_13;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteCharacterLookup
	Dictionary_2_tD4154357CA320908C5A7A35ED81FA2A9856C28D9* ___m_SpriteCharacterLookup_14;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteGlyph> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteGlyphTable
	List_1_t063B87D3CFDC3AEE80E33EFBDA1410C697D71AD6* ___m_SpriteGlyphTable_15;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteGlyph> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteGlyphLookup
	Dictionary_2_tDC0461D8CBB2E6B52DD2C421114EDE7C1C70DE73* ___m_SpriteGlyphLookup_16;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset> UnityEngine.TextCore.Text.SpriteAsset::fallbackSpriteAssets
	List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320* ___fallbackSpriteAssets_17;
	// System.Boolean UnityEngine.TextCore.Text.SpriteAsset::m_IsSpriteAssetLookupTablesDirty
	bool ___m_IsSpriteAssetLookupTablesDirty_18;
};

struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_StaticFields
{
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.SpriteAsset::k_searchedSpriteAssets
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_searchedSpriteAssets_19;
};

// UnityEngine.TextCore.Text.TextGenerator
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366  : public RuntimeObject
{
	// UnityEngine.Vector3[] UnityEngine.TextCore.Text.TextGenerator::m_RectTransformCorners
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___m_RectTransformCorners_1;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginWidth
	float ___m_MarginWidth_2;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginHeight
	float ___m_MarginHeight_3;
	// System.Int32[] UnityEngine.TextCore.Text.TextGenerator::m_CharBuffer
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___m_CharBuffer_4;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_PreferredWidth
	float ___m_PreferredWidth_5;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_PreferredHeight
	float ___m_PreferredHeight_6;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextGenerator::m_CurrentFontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___m_CurrentFontAsset_7;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextGenerator::m_CurrentMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_CurrentMaterial_8;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_CurrentMaterialIndex
	int32_t ___m_CurrentMaterialIndex_9;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference> UnityEngine.TextCore.Text.TextGenerator::m_MaterialReferenceStack
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___m_MaterialReferenceStack_10;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_Padding
	float ___m_Padding_11;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextGenerator::m_CurrentSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_CurrentSpriteAsset_12;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_TotalCharacterCount
	int32_t ___m_TotalCharacterCount_13;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_FontScale
	float ___m_FontScale_14;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_FontSize
	float ___m_FontSize_15;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_FontScaleMultiplier
	float ___m_FontScaleMultiplier_16;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_CurrentFontSize
	float ___m_CurrentFontSize_17;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.TextGenerator::m_SizeStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_SizeStack_18;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextGenerator::m_FontStyleInternal
	int32_t ___m_FontStyleInternal_19;
	// UnityEngine.TextCore.Text.FontStyleStack UnityEngine.TextCore.Text.TextGenerator::m_FontStyleStack
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___m_FontStyleStack_20;
	// UnityEngine.TextCore.Text.TextFontWeight UnityEngine.TextCore.Text.TextGenerator::m_FontWeightInternal
	int32_t ___m_FontWeightInternal_21;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight> UnityEngine.TextCore.Text.TextGenerator::m_FontWeightStack
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___m_FontWeightStack_22;
	// UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.TextGenerator::m_LineJustification
	int32_t ___m_LineJustification_23;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment> UnityEngine.TextCore.Text.TextGenerator::m_LineJustificationStack
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___m_LineJustificationStack_24;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_BaselineOffset
	float ___m_BaselineOffset_25;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.TextGenerator::m_BaselineOffsetStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_BaselineOffsetStack_26;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_FontColor32
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_FontColor32_27;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_HtmlColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_HtmlColor_28;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_UnderlineColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_UnderlineColor_29;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_StrikethroughColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_StrikethroughColor_30;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_ColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_ColorStack_31;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_UnderlineColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_UnderlineColorStack_32;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_StrikethroughColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_StrikethroughColorStack_33;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_HighlightColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_HighlightColorStack_34;
	// UnityEngine.TextCore.Text.TextColorGradient UnityEngine.TextCore.Text.TextGenerator::m_ColorGradientPreset
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___m_ColorGradientPreset_35;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient> UnityEngine.TextCore.Text.TextGenerator::m_ColorGradientStack
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___m_ColorGradientStack_36;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.TextGenerator::m_ActionStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_ActionStack_37;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsFxMatrixSet
	bool ___m_IsFxMatrixSet_38;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_LineOffset
	float ___m_LineOffset_39;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_LineHeight
	float ___m_LineHeight_40;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_CSpacing
	float ___m_CSpacing_41;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MonoSpacing
	float ___m_MonoSpacing_42;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_XAdvance
	float ___m_XAdvance_43;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_TagLineIndent
	float ___m_TagLineIndent_44;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_TagIndent
	float ___m_TagIndent_45;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.TextGenerator::m_IndentStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_IndentStack_46;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_TagNoParsing
	bool ___m_TagNoParsing_47;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_CharacterCount
	int32_t ___m_CharacterCount_48;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_FirstCharacterOfLine
	int32_t ___m_FirstCharacterOfLine_49;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LastCharacterOfLine
	int32_t ___m_LastCharacterOfLine_50;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_FirstVisibleCharacterOfLine
	int32_t ___m_FirstVisibleCharacterOfLine_51;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LastVisibleCharacterOfLine
	int32_t ___m_LastVisibleCharacterOfLine_52;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxLineAscender
	float ___m_MaxLineAscender_53;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxLineDescender
	float ___m_MaxLineDescender_54;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LineNumber
	int32_t ___m_LineNumber_55;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LineVisibleCharacterCount
	int32_t ___m_LineVisibleCharacterCount_56;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_FirstOverflowCharacterIndex
	int32_t ___m_FirstOverflowCharacterIndex_57;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_PageNumber
	int32_t ___m_PageNumber_58;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginLeft
	float ___m_MarginLeft_59;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginRight
	float ___m_MarginRight_60;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_Width
	float ___m_Width_61;
	// UnityEngine.TextCore.Text.Extents UnityEngine.TextCore.Text.TextGenerator::m_MeshExtents
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___m_MeshExtents_62;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxCapHeight
	float ___m_MaxCapHeight_63;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxAscender
	float ___m_MaxAscender_64;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxDescender
	float ___m_MaxDescender_65;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsNewPage
	bool ___m_IsNewPage_66;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsNonBreakingSpace
	bool ___m_IsNonBreakingSpace_67;
	// UnityEngine.TextCore.Text.WordWrapState UnityEngine.TextCore.Text.TextGenerator::m_SavedWordWrapState
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedWordWrapState_68;
	// UnityEngine.TextCore.Text.WordWrapState UnityEngine.TextCore.Text.TextGenerator::m_SavedLineState
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedLineState_69;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LoopCountA
	int32_t ___m_LoopCountA_70;
	// UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextGenerator::m_TextElementType
	uint8_t ___m_TextElementType_71;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsParsingText
	bool ___m_IsParsingText_72;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteIndex
	int32_t ___m_SpriteIndex_73;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_SpriteColor_74;
	// UnityEngine.TextCore.Text.TextElement UnityEngine.TextCore.Text.TextGenerator::m_CachedTextElement
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___m_CachedTextElement_75;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_HighlightColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_HighlightColor_76;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_CharWidthAdjDelta
	float ___m_CharWidthAdjDelta_77;
	// UnityEngine.Matrix4x4 UnityEngine.TextCore.Text.TextGenerator::m_FxMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_FxMatrix_78;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxFontSize
	float ___m_MaxFontSize_79;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MinFontSize
	float ___m_MinFontSize_80;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsCharacterWrappingEnabled
	bool ___m_IsCharacterWrappingEnabled_81;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_StartOfLineAscender
	float ___m_StartOfLineAscender_82;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_LineSpacingDelta
	float ___m_LineSpacingDelta_83;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsMaskingEnabled
	bool ___m_IsMaskingEnabled_84;
	// UnityEngine.TextCore.Text.MaterialReference[] UnityEngine.TextCore.Text.TextGenerator::m_MaterialReferences
	MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* ___m_MaterialReferences_85;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteCount
	int32_t ___m_SpriteCount_86;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.TextGenerator::m_StyleStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_StyleStack_87;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteAnimationId
	int32_t ___m_SpriteAnimationId_88;
	// System.UInt32[] UnityEngine.TextCore.Text.TextGenerator::m_InternalTextParsingBuffer
	UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA* ___m_InternalTextParsingBuffer_89;
	// UnityEngine.TextCore.Text.RichTextTagAttribute[] UnityEngine.TextCore.Text.TextGenerator::m_Attributes
	RichTextTagAttributeU5BU5D_tEE9D071B3246F23742DBF4226567620BCBB24A14* ___m_Attributes_90;
	// UnityEngine.TextCore.Text.XmlTagAttribute[] UnityEngine.TextCore.Text.TextGenerator::m_XmlAttribute
	XmlTagAttributeU5BU5D_tEDFE75BDDC81D11CEA2F2A12583516D3BFB309B2* ___m_XmlAttribute_91;
	// System.Char[] UnityEngine.TextCore.Text.TextGenerator::m_RichTextTag
	CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB* ___m_RichTextTag_92;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> UnityEngine.TextCore.Text.TextGenerator::m_MaterialReferenceIndexLookup
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___m_MaterialReferenceIndexLookup_93;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsCalculatingPreferredValues
	bool ___m_IsCalculatingPreferredValues_94;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextGenerator::m_DefaultSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_DefaultSpriteAsset_95;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_TintSprite
	bool ___m_TintSprite_96;
	// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter UnityEngine.TextCore.Text.TextGenerator::m_Ellipsis
	SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD ___m_Ellipsis_97;
	// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter UnityEngine.TextCore.Text.TextGenerator::m_Underline
	SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD ___m_Underline_98;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsUsingBold
	bool ___m_IsUsingBold_99;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsSdfShader
	bool ___m_IsSdfShader_100;
	// UnityEngine.TextCore.Text.TextElementInfo[] UnityEngine.TextCore.Text.TextGenerator::m_InternalTextElementInfo
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* ___m_InternalTextElementInfo_101;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_RecursiveCount
	int32_t ___m_RecursiveCount_102;
};

struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_StaticFields
{
	// UnityEngine.TextCore.Text.TextGenerator UnityEngine.TextCore.Text.TextGenerator::s_TextGenerator
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* ___s_TextGenerator_0;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C  : public RuntimeArray
{
	ALIGN_FIELD (8) Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 m_Items[1];

	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.TextElementInfo[]
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E  : public RuntimeArray
{
	ALIGN_FIELD (8) TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 m_Items[1];

	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___textElement_3), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___textElement_3), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
};
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C  : public RuntimeArray
{
	ALIGN_FIELD (8) int32_t m_Items[1];

	inline int32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int32_t value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.PageInfo[]
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4  : public RuntimeArray
{
	ALIGN_FIELD (8) PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 m_Items[1];

	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.LineInfo[]
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D  : public RuntimeArray
{
	ALIGN_FIELD (8) LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 m_Items[1];

	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.MaterialReference[]
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E  : public RuntimeArray
{
	ALIGN_FIELD (8) MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 m_Items[1];

	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fallbackMaterial_6), (void*)NULL);
		#endif
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fallbackMaterial_6), (void*)NULL);
		#endif
	}
};
// UnityEngine.TextCore.Text.MeshInfo[]
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6  : public RuntimeArray
{
	ALIGN_FIELD (8) MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F m_Items[1];

	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___vertices_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs0_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs2_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___colors32_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___triangles_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___vertices_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs0_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs2_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___colors32_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___triangles_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
};
// UnityEngine.TextCore.Text.WordInfo[]
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B  : public RuntimeArray
{
	ALIGN_FIELD (8) WordInfo_tA466206097891A5A2590896EE164AFC406EB060D m_Items[1];

	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, WordInfo_tA466206097891A5A2590896EE164AFC406EB060D value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, WordInfo_tA466206097891A5A2590896EE164AFC406EB060D value)
	{
		m_Items[index] = value;
	}
};


// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_gshared (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* __this, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___item0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_gshared (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, float ___item0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32Enum>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared (TextProcessingStack_1_t9C24840D494C4878BD8680855123926D6243C90D* __this, int32_t ___item0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_gshared (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_gshared (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___item0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Object>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m2748811181AC3D93A43815FE1FAC09A7E569806E_gshared (TextProcessingStack_1_t5EA97AAC21CEE068194F77E59929440F85AD3991* __this, RuntimeObject* ___item0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_gshared (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<System.Object>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, int32_t ___index0, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>::TryGetValue(TKey,TValue&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_gshared (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* __this, uint32_t ___key0, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* ___value1, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.PageInfo>(T[]&,System.Int32,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_gshared (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** ___array0, int32_t ___size1, bool ___isBlockAllocated2, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.HashSet`1<System.UInt32>::Contains(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_gshared (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* __this, uint32_t ___item0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.WordInfo>(T[]&,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_gshared (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** ___array0, int32_t ___size1, const RuntimeMethod* method) ;

// System.Void UnityEngine.TextCore.Text.TextInfo::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::ClearMesh(System.Boolean,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83 (bool ___updateMesh0, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo1, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MaterialReference::.ctor(System.Int32,UnityEngine.TextCore.Text.FontAsset,UnityEngine.TextCore.Text.SpriteAsset,UnityEngine.Material,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A (MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* __this, int32_t ___index0, FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset1, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset2, Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material3, float ___padding4, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* __this, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___item0, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA*, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_gshared)(__this, ___item0, method);
}
// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.FontAsset::get_faceInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9 (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, float ___item0, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*, float, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_gshared)(__this, ___item0, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79 (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790* __this, int32_t ___item0, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared)(__this, ___item0, method);
}
// System.Void UnityEngine.TextCore.Text.FontStyleStack::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0 (FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230 (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F* __this, int32_t ___item0, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared)(__this, ___item0, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::Clear()
inline void TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3 (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*, const RuntimeMethod*))TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_gshared)(__this, method);
}
// UnityEngine.Vector3 UnityEngine.Vector3::get_zero()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) ;
// UnityEngine.Color32 UnityEngine.Color32::op_Implicit(UnityEngine.Color)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___c0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54 (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___item0, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_gshared)(__this, ___item0, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9 (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E* __this, TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___item0, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E*, TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m2748811181AC3D93A43815FE1FAC09A7E569806E_gshared)(__this, ___item0, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>::Clear()
inline void TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*, const RuntimeMethod*))TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_gshared)(__this, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_lineHeight_m528B4A822181FCECF3D4FF1045DF288E5872AB9D (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Mathf::Clamp(System.Int32,System.Int32,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline (int32_t ___value0, int32_t ___min1, int32_t ___max2, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::ClearLineInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::SaveWordWrappingState(UnityEngine.TextCore.Text.WordWrapState&,System.Int32,System.Int32,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* ___state0, int32_t ___index1, int32_t ___count2, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo3, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.TextCore.Text.TextGenerator::ValidateHtmlTag(System.Int32[],System.Int32,System.Int32&,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGenerator_ValidateHtmlTag_m9C85462F15A6165B10E4C4EE93620AC1021BE5CD (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___chars0, int32_t ___startIndex1, int32_t* ___endIndex2, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings3, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo4, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsLower(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Char System.Char::ToUpper(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsUpper(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsUpper_mF150C44B70F522A14B2A8DF71DE0ADE52F9A3392 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Char System.Char::ToLower(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar Char_ToLower_m238489988C62CB10C7C7CAAEF8F3B2D1C5B5E056 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::get_spriteCharacterTable()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51* SpriteAsset_get_spriteCharacterTable_m8D0D65C430AD8BC8C2BC8151DC4672CC0F690E0A (SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* __this, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter>::get_Item(System.Int32)
inline SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* List_1_get_Item_m25CB12C13D14620785B0E86F6543D20B5080AFF8 (List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51* __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* (*) (List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51*, int32_t, const RuntimeMethod*))List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared)(__this, ___index0, method);
}
// UnityEngine.Color UnityEngine.Color::get_white()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline (const RuntimeMethod* method) ;
// UnityEngine.TextCore.Glyph UnityEngine.TextCore.Text.TextElement::get_glyph()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA (Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.TextElement::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.TextGenerator::GetPaddingForMaterial(UnityEngine.Material,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float TextGenerator_GetPaddingForMaterial_mE5A4DEF3F64851861C092F7A4FC58C902F775C74 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material0, bool ___extraPadding1, const RuntimeMethod* method) ;
// System.UInt32 UnityEngine.TextCore.Text.TextElement::get_glyphIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>::TryGetValue(TKey,TValue&)
inline bool Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* __this, uint32_t ___key0, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* ___value1, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0*, uint32_t, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E*, const RuntimeMethod*))Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_gshared)(__this, ___key0, ___value1, method);
}
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m867469548F17B298F893B78EE2F93D34E4A6C39C (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7 (GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_mFDFECB1F7A38E22BD2388FFE9C71E732F6B44D91 (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphValueRecord::op_Addition(UnityEngine.TextCore.LowLevel.GlyphValueRecord,UnityEngine.TextCore.LowLevel.GlyphValueRecord)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E GlyphValueRecord_op_Addition_mF26165B4CE61A5409AEFF24B0D1727804E13602B (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___a0, GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___b1, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_regularStyleSpacing()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsWhiteSpace(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Material::HasProperty(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222 (Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* __this, int32_t ___nameID0, const RuntimeMethod* method) ;
// System.Single UnityEngine.Material::GetFloat(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932 (Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* __this, int32_t ___nameID0, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_boldStyleWeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_boldStyleSpacing()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_regularStyleWeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_regularStyleWeight_m6C4B4D4CAD36800E6E686A05A5DB8D4475F2707F (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8 (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
// System.Byte UnityEngine.TextCore.Text.FontAsset::get_italicStyleSlant()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Addition(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___a0, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___b1, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Division(UnityEngine.Vector3,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___a0, float ___d1, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Subtraction(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___a0, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___b1, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Matrix4x4::MultiplyPoint3x4(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814 (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___point0, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_subscriptSize_mF6264BFB215FDE6C94A45D2F8FC946ADFCDD2E31 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Max(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline (float ___a0, float ___b1, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Min(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline (float ___a0, float ___b1, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::GenerateTextMesh(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings0, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo1, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.TextCore.Text.TextGenerator::RestoreWordWrappingState(UnityEngine.TextCore.Text.WordWrapState&,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* ___state0, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo1, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::Approximately(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D (float ___a0, float ___b1, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::AdjustLineOffset(System.Int32,System.Int32,System.Single,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123 (int32_t ___startIndex0, int32_t ___endIndex1, float ___offset2, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo3, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector2::.ctor(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___x0, float ___y1, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::ResizeLineExtents(System.Int32,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85 (int32_t ___size0, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo1, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::DisableMasking()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, const RuntimeMethod* method) ;
// System.String UnityEngine.Object::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// System.String System.String::Concat(System.String,System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B (String_t* ___str00, String_t* ___str11, String_t* ___str22, const RuntimeMethod* method) ;
// System.Void UnityEngine.Debug::LogWarning(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9 (RuntimeObject* ___message0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::EnableMasking()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::SaveGlyphVertexInfo(System.Single,System.Single,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, float ___padding0, float ___stylePadding1, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor2, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings3, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo4, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::SaveSpriteVertexInfo(UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor0, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings1, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo2, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsSeparator(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_tabWidth_mC6D9F42C40EDD767DE22050E4FBE3878AC96B161 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Byte UnityEngine.TextCore.Text.FontAsset::get_tabMultiple()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.PageInfo>(T[]&,System.Int32,System.Boolean)
inline void TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8 (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** ___array0, int32_t ___size1, bool ___isBlockAllocated2, const RuntimeMethod* method)
{
	((  void (*) (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4**, int32_t, bool, const RuntimeMethod*))TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_gshared)(___array0, ___size1, ___isBlockAllocated2, method);
}
// UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.TextSettings::get_lineBreakingRules()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04 (TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::get_leadingCharactersLookup()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.HashSet`1<System.UInt32>::Contains(T)
inline bool HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9 (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* __this, uint32_t ___item0, const RuntimeMethod* method)
{
	return ((  bool (*) (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A*, uint32_t, const RuntimeMethod*))HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_gshared)(__this, ___item0, method);
}
// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::get_followingCharactersLookup()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MeshInfo::Clear(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, bool ___uploadChanges0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Color32::.ctor(System.Byte,System.Byte,System.Byte,System.Byte)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* __this, uint8_t ___r0, uint8_t ___g1, uint8_t ___b2, uint8_t ___a3, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsControl(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsControl_m133C10360BE82B7580E4D3ECE3C881A6C82B3F7F (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Debug::Log(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB (RuntimeObject* ___message0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::FillCharacterVertexBuffers(System.Int32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_FillCharacterVertexBuffers_m54CA97C6C26BA84BC949845B20E9DADF2F0C19CA (int32_t ___i0, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings1, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo2, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::FillSpriteVertexBuffers(System.Int32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_FillSpriteVertexBuffers_m4305B80FA32FE21A59AF68A5501226E5A4203CC3 (int32_t ___i0, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings1, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo2, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsLetterOrDigit(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.WordInfo>(T[]&,System.Int32)
inline void TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** ___array0, int32_t ___size1, const RuntimeMethod* method)
{
	((  void (*) (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**, int32_t, const RuntimeMethod*))TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_gshared)(___array0, ___size1, method);
}
// System.Boolean System.Char::IsPunctuation(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsPunctuation_m619E42D942E22C9BA1DDB8E704BECA546C376473 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineOffset_mB1CBB29ECFFE69047F35E654E7F90755F95DD251 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::DrawUnderlineMesh(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32&,System.Single,System.Single,System.Single,System.Single,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___start0, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___end1, int32_t* ___index2, float ___startScale3, float ___endScale4, float ___maxScale5, float ___sdfScale6, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor7, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings8, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo9, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.TextCore.Text.ColorUtilities::CompareColors(UnityEngine.Color32,UnityEngine.Color32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875 (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___a0, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___b1, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_strikethroughOffset_m7997E4A1512FE358331B3A6543C62C92A0AA5CA5 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Object::GetInstanceID()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector2::op_Implicit(UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___v0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::DrawTextHighlight(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32&,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___start0, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___end1, int32_t* ___index2, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor3, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings4, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo5, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MeshInfo::SortGeometry(UnityEngine.TextCore.Text.VertexSortingOrder)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, int32_t ___order0, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MeshInfo::ClearUnusedVertices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Clamp01(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline (float ___value0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Color::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F* __this, float ___r0, float ___g1, float ___b2, float ___a3, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.TextCore.Text.TextGenerator::GenerateTextMesh(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___generationSettings0, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo1, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_m25CB12C13D14620785B0E86F6543D20B5080AFF8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	float V_4 = 0.0f;
	bool V_5 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_6;
	memset((&V_6), 0, sizeof(V_6));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_7;
	memset((&V_7), 0, sizeof(V_7));
	bool V_8 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_9;
	memset((&V_9), 0, sizeof(V_9));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_10;
	memset((&V_10), 0, sizeof(V_10));
	bool V_11 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_12;
	memset((&V_12), 0, sizeof(V_12));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_13;
	memset((&V_13), 0, sizeof(V_13));
	float V_14 = 0.0f;
	bool V_15 = false;
	int32_t V_16 = 0;
	int32_t V_17 = 0;
	int32_t V_18 = 0;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 V_19;
	memset((&V_19), 0, sizeof(V_19));
	float V_20 = 0.0f;
	float V_21 = 0.0f;
	float V_22 = 0.0f;
	TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* V_23 = NULL;
	float V_24 = 0.0f;
	float V_25 = 0.0f;
	bool V_26 = false;
	bool V_27 = false;
	bool V_28 = false;
	bool V_29 = false;
	int32_t V_30 = 0;
	int32_t V_31 = 0;
	float V_32 = 0.0f;
	int32_t V_33 = 0;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_34;
	memset((&V_34), 0, sizeof(V_34));
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* V_35 = NULL;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_36;
	memset((&V_36), 0, sizeof(V_36));
	int32_t V_37 = 0;
	int32_t V_38 = 0;
	int32_t V_39 = 0;
	bool V_40 = false;
	bool V_41 = false;
	int32_t V_42 = 0;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_43;
	memset((&V_43), 0, sizeof(V_43));
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_44;
	memset((&V_44), 0, sizeof(V_44));
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_45;
	memset((&V_45), 0, sizeof(V_45));
	float V_46 = 0.0f;
	float V_47 = 0.0f;
	float V_48 = 0.0f;
	float V_49 = 0.0f;
	int32_t V_50 = 0;
	float V_51 = 0.0f;
	float V_52 = 0.0f;
	float V_53 = 0.0f;
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* V_54 = NULL;
	bool V_55 = false;
	bool V_56 = false;
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 V_57;
	memset((&V_57), 0, sizeof(V_57));
	float V_58 = 0.0f;
	int32_t V_59 = 0;
	int32_t V_60 = 0;
	int32_t V_61 = 0;
	bool V_62 = false;
	float V_63 = 0.0f;
	float V_64 = 0.0f;
	GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E V_65;
	memset((&V_65), 0, sizeof(V_65));
	float V_66 = 0.0f;
	float V_67 = 0.0f;
	float V_68 = 0.0f;
	float V_69 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_70;
	memset((&V_70), 0, sizeof(V_70));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_71;
	memset((&V_71), 0, sizeof(V_71));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_72;
	memset((&V_72), 0, sizeof(V_72));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_73;
	memset((&V_73), 0, sizeof(V_73));
	float V_74 = 0.0f;
	float V_75 = 0.0f;
	float V_76 = 0.0f;
	float V_77 = 0.0f;
	bool V_78 = false;
	bool V_79 = false;
	bool V_80 = false;
	bool V_81 = false;
	bool V_82 = false;
	bool V_83 = false;
	bool V_84 = false;
	bool V_85 = false;
	bool V_86 = false;
	bool V_87 = false;
	bool V_88 = false;
	bool V_89 = false;
	SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* V_90 = NULL;
	float V_91 = 0.0f;
	bool V_92 = false;
	bool V_93 = false;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A V_94;
	memset((&V_94), 0, sizeof(V_94));
	bool V_95 = false;
	bool V_96 = false;
	bool V_97 = false;
	bool V_98 = false;
	GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E V_99;
	memset((&V_99), 0, sizeof(V_99));
	uint32_t V_100 = 0;
	bool V_101 = false;
	uint32_t V_102 = 0;
	uint32_t V_103 = 0;
	bool V_104 = false;
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 V_105;
	memset((&V_105), 0, sizeof(V_105));
	bool V_106 = false;
	uint32_t V_107 = 0;
	uint32_t V_108 = 0;
	bool V_109 = false;
	bool V_110 = false;
	bool V_111 = false;
	bool V_112 = false;
	bool V_113 = false;
	bool V_114 = false;
	float V_115 = 0.0f;
	bool V_116 = false;
	bool V_117 = false;
	float V_118 = 0.0f;
	bool V_119 = false;
	bool V_120 = false;
	float V_121 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_122;
	memset((&V_122), 0, sizeof(V_122));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_123;
	memset((&V_123), 0, sizeof(V_123));
	bool V_124 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_125;
	memset((&V_125), 0, sizeof(V_125));
	bool V_126 = false;
	float V_127 = 0.0f;
	float V_128 = 0.0f;
	bool V_129 = false;
	bool V_130 = false;
	bool V_131 = false;
	bool V_132 = false;
	float V_133 = 0.0f;
	bool V_134 = false;
	bool V_135 = false;
	float V_136 = 0.0f;
	float V_137 = 0.0f;
	bool V_138 = false;
	bool V_139 = false;
	bool V_140 = false;
	bool V_141 = false;
	bool V_142 = false;
	bool V_143 = false;
	bool V_144 = false;
	bool V_145 = false;
	float V_146 = 0.0f;
	bool V_147 = false;
	bool V_148 = false;
	int32_t V_149 = 0;
	bool V_150 = false;
	bool V_151 = false;
	float V_152 = 0.0f;
	bool V_153 = false;
	bool V_154 = false;
	bool V_155 = false;
	int32_t V_156 = 0;
	int32_t V_157 = 0;
	bool V_158 = false;
	bool V_159 = false;
	bool V_160 = false;
	bool V_161 = false;
	bool V_162 = false;
	bool V_163 = false;
	bool V_164 = false;
	bool V_165 = false;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* V_166 = NULL;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_167;
	memset((&V_167), 0, sizeof(V_167));
	bool V_168 = false;
	bool V_169 = false;
	bool V_170 = false;
	bool V_171 = false;
	bool V_172 = false;
	bool V_173 = false;
	bool V_174 = false;
	bool V_175 = false;
	float V_176 = 0.0f;
	bool V_177 = false;
	bool V_178 = false;
	bool V_179 = false;
	bool V_180 = false;
	bool V_181 = false;
	bool V_182 = false;
	int32_t V_183 = 0;
	int32_t V_184 = 0;
	bool V_185 = false;
	bool V_186 = false;
	bool V_187 = false;
	bool V_188 = false;
	bool V_189 = false;
	bool V_190 = false;
	bool V_191 = false;
	bool V_192 = false;
	bool V_193 = false;
	bool V_194 = false;
	bool V_195 = false;
	bool V_196 = false;
	bool V_197 = false;
	bool V_198 = false;
	float V_199 = 0.0f;
	float V_200 = 0.0f;
	bool V_201 = false;
	bool V_202 = false;
	bool V_203 = false;
	float V_204 = 0.0f;
	bool V_205 = false;
	bool V_206 = false;
	bool V_207 = false;
	bool V_208 = false;
	float V_209 = 0.0f;
	float V_210 = 0.0f;
	bool V_211 = false;
	float V_212 = 0.0f;
	bool V_213 = false;
	bool V_214 = false;
	bool V_215 = false;
	bool V_216 = false;
	bool V_217 = false;
	bool V_218 = false;
	bool V_219 = false;
	bool V_220 = false;
	bool V_221 = false;
	bool V_222 = false;
	bool V_223 = false;
	bool V_224 = false;
	bool V_225 = false;
	bool V_226 = false;
	bool V_227 = false;
	bool V_228 = false;
	bool V_229 = false;
	bool V_230 = false;
	bool V_231 = false;
	bool V_232 = false;
	bool V_233 = false;
	bool V_234 = false;
	int32_t V_235 = 0;
	int32_t V_236 = 0;
	bool V_237 = false;
	bool V_238 = false;
	bool V_239 = false;
	int32_t V_240 = 0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* V_241 = NULL;
	Il2CppChar V_242 = 0x0;
	int32_t V_243 = 0;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 V_244;
	memset((&V_244), 0, sizeof(V_244));
	int32_t V_245 = 0;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_246;
	memset((&V_246), 0, sizeof(V_246));
	bool V_247 = false;
	int32_t V_248 = 0;
	bool V_249 = false;
	float V_250 = 0.0f;
	bool V_251 = false;
	float V_252 = 0.0f;
	bool V_253 = false;
	Il2CppChar V_254 = 0x0;
	bool V_255 = false;
	int32_t V_256 = 0;
	int32_t V_257 = 0;
	bool V_258 = false;
	bool V_259 = false;
	bool V_260 = false;
	bool V_261 = false;
	bool V_262 = false;
	bool V_263 = false;
	bool V_264 = false;
	float V_265 = 0.0f;
	int32_t V_266 = 0;
	int32_t V_267 = 0;
	float V_268 = 0.0f;
	bool V_269 = false;
	bool V_270 = false;
	bool V_271 = false;
	bool V_272 = false;
	bool V_273 = false;
	bool V_274 = false;
	bool V_275 = false;
	uint8_t V_276 = 0;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 V_277;
	memset((&V_277), 0, sizeof(V_277));
	float V_278 = 0.0f;
	uint8_t V_279 = 0;
	uint8_t V_280 = 0;
	float V_281 = 0.0f;
	int32_t V_282 = 0;
	int32_t V_283 = 0;
	bool V_284 = false;
	int32_t V_285 = 0;
	int32_t V_286 = 0;
	float V_287 = 0.0f;
	int32_t V_288 = 0;
	int32_t V_289 = 0;
	bool V_290 = false;
	bool V_291 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* V_292 = NULL;
	bool V_293 = false;
	bool V_294 = false;
	bool V_295 = false;
	bool V_296 = false;
	bool V_297 = false;
	bool V_298 = false;
	bool V_299 = false;
	bool V_300 = false;
	bool V_301 = false;
	int32_t V_302 = 0;
	int32_t V_303 = 0;
	bool V_304 = false;
	bool V_305 = false;
	bool V_306 = false;
	int32_t V_307 = 0;
	int32_t V_308 = 0;
	bool V_309 = false;
	bool V_310 = false;
	bool V_311 = false;
	int32_t V_312 = 0;
	bool V_313 = false;
	bool V_314 = false;
	bool V_315 = false;
	bool V_316 = false;
	bool V_317 = false;
	bool V_318 = false;
	bool V_319 = false;
	bool V_320 = false;
	int32_t V_321 = 0;
	bool V_322 = false;
	bool V_323 = false;
	bool V_324 = false;
	bool V_325 = false;
	bool V_326 = false;
	bool V_327 = false;
	bool V_328 = false;
	bool V_329 = false;
	bool V_330 = false;
	bool V_331 = false;
	int32_t V_332 = 0;
	bool V_333 = false;
	int32_t V_334 = 0;
	bool V_335 = false;
	bool V_336 = false;
	bool V_337 = false;
	bool V_338 = false;
	bool V_339 = false;
	bool V_340 = false;
	int32_t V_341 = 0;
	bool V_342 = false;
	bool V_343 = false;
	bool V_344 = false;
	bool V_345 = false;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_346;
	memset((&V_346), 0, sizeof(V_346));
	bool V_347 = false;
	bool V_348 = false;
	bool V_349 = false;
	bool V_350 = false;
	bool V_351 = false;
	bool V_352 = false;
	bool V_353 = false;
	bool V_354 = false;
	bool V_355 = false;
	int32_t V_356 = 0;
	bool V_357 = false;
	bool V_358 = false;
	int32_t G_B6_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B10_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B9_0 = NULL;
	int32_t G_B11_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B11_1 = NULL;
	int32_t G_B15_0 = 0;
	float G_B51_0 = 0.0f;
	int32_t G_B68_0 = 0;
	int32_t G_B77_0 = 0;
	int32_t G_B94_0 = 0;
	float G_B100_0 = 0.0f;
	float G_B99_0 = 0.0f;
	float G_B101_0 = 0.0f;
	float G_B101_1 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B103_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B102_0 = NULL;
	float G_B104_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B104_1 = NULL;
	float G_B106_0 = 0.0f;
	float G_B105_0 = 0.0f;
	float G_B107_0 = 0.0f;
	float G_B107_1 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B109_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B108_0 = NULL;
	float G_B110_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B110_1 = NULL;
	int32_t G_B113_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B116_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B115_0 = NULL;
	float G_B117_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B117_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B119_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B118_0 = NULL;
	float G_B120_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B120_1 = NULL;
	int32_t G_B124_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B127_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B126_0 = NULL;
	float G_B128_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B128_1 = NULL;
	float G_B133_0 = 0.0f;
	int32_t G_B141_0 = 0;
	float G_B145_0 = 0.0f;
	int32_t G_B148_0 = 0;
	float G_B150_0 = 0.0f;
	float G_B149_0 = 0.0f;
	float G_B151_0 = 0.0f;
	float G_B151_1 = 0.0f;
	float G_B153_0 = 0.0f;
	float G_B153_1 = 0.0f;
	float G_B152_0 = 0.0f;
	float G_B152_1 = 0.0f;
	float G_B154_0 = 0.0f;
	float G_B154_1 = 0.0f;
	float G_B154_2 = 0.0f;
	float G_B156_0 = 0.0f;
	float G_B156_1 = 0.0f;
	float G_B155_0 = 0.0f;
	float G_B155_1 = 0.0f;
	float G_B157_0 = 0.0f;
	float G_B157_1 = 0.0f;
	float G_B157_2 = 0.0f;
	int32_t G_B161_0 = 0;
	int32_t G_B166_0 = 0;
	int32_t G_B186_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B190_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B189_0 = NULL;
	float G_B191_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B191_1 = NULL;
	int32_t G_B197_0 = 0;
	int32_t G_B199_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B203_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B203_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B202_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B202_1 = NULL;
	int32_t G_B204_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B204_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B204_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B206_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B206_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B205_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B205_1 = NULL;
	int32_t G_B207_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B207_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B207_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B209_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B209_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B208_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B208_1 = NULL;
	int32_t G_B210_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B210_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B210_2 = NULL;
	int32_t G_B219_0 = 0;
	int32_t G_B253_0 = 0;
	int32_t G_B266_0 = 0;
	int32_t G_B277_0 = 0;
	int32_t G_B287_0 = 0;
	int32_t G_B294_0 = 0;
	int32_t G_B301_0 = 0;
	int32_t G_B306_0 = 0;
	int32_t G_B341_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B355_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B354_0 = NULL;
	float G_B356_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B356_1 = NULL;
	int32_t G_B361_0 = 0;
	int32_t G_B370_0 = 0;
	int32_t G_B379_0 = 0;
	int32_t G_B385_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B389_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B388_0 = NULL;
	float G_B390_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B390_1 = NULL;
	int32_t G_B396_0 = 0;
	int32_t G_B398_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B402_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B402_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B401_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B401_1 = NULL;
	int32_t G_B403_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B403_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B403_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B405_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B405_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B404_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B404_1 = NULL;
	int32_t G_B406_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B406_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B406_2 = NULL;
	int32_t G_B425_0 = 0;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B430_0 = NULL;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B429_0 = NULL;
	float G_B431_0 = 0.0f;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B431_1 = NULL;
	int32_t G_B434_0 = 0;
	int32_t G_B439_0 = 0;
	int32_t G_B448_0 = 0;
	int32_t G_B460_0 = 0;
	int32_t G_B478_0 = 0;
	int32_t G_B484_0 = 0;
	int32_t G_B486_0 = 0;
	int32_t G_B488_0 = 0;
	int32_t G_B494_0 = 0;
	int32_t G_B502_0 = 0;
	int32_t G_B508_0 = 0;
	int32_t G_B672_0 = 0;
	int32_t G_B677_0 = 0;
	int32_t G_B680_0 = 0;
	int32_t G_B685_0 = 0;
	float G_B696_0 = 0.0f;
	int32_t G_B699_0 = 0;
	float G_B704_0 = 0.0f;
	int32_t G_B710_0 = 0;
	int32_t G_B712_0 = 0;
	int32_t G_B756_0 = 0;
	int32_t G_B765_0 = 0;
	int32_t G_B773_0 = 0;
	int32_t G_B784_0 = 0;
	int32_t G_B796_0 = 0;
	int32_t G_B802_0 = 0;
	int32_t G_B814_0 = 0;
	int32_t G_B816_0 = 0;
	int32_t G_B818_0 = 0;
	int32_t G_B827_0 = 0;
	int32_t G_B832_0 = 0;
	int32_t G_B842_0 = 0;
	int32_t G_B844_0 = 0;
	int32_t G_B849_0 = 0;
	float G_B853_0 = 0.0f;
	int32_t G_B859_0 = 0;
	int32_t G_B863_0 = 0;
	int32_t G_B871_0 = 0;
	int32_t G_B877_0 = 0;
	int32_t G_B879_0 = 0;
	int32_t G_B883_0 = 0;
	int32_t G_B890_0 = 0;
	int32_t G_B896_0 = 0;
	int32_t G_B908_0 = 0;
	int32_t G_B910_0 = 0;
	int32_t G_B915_0 = 0;
	int32_t G_B919_0 = 0;
	int32_t G_B925_0 = 0;
	int32_t G_B930_0 = 0;
	int32_t G_B934_0 = 0;
	int32_t G_B943_0 = 0;
	int32_t G_B945_0 = 0;
	int32_t G_B954_0 = 0;
	int32_t G_B959_0 = 0;
	int32_t G_B971_0 = 0;
	int32_t G_B973_0 = 0;
	int32_t G_B980_0 = 0;
	int32_t G_B984_0 = 0;
	int32_t G_B996_0 = 0;
	int32_t G_B1002_0 = 0;
	int32_t G_B1004_0 = 0;
	int32_t G_B1009_0 = 0;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1019_0 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1018_0 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1020_0 = NULL;
	int32_t G_B1021_0 = 0;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1021_1 = NULL;
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_0 = ___textInfo1;
		V_55 = (bool)((((RuntimeObject*)(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09*)L_0) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_1 = V_55;
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		goto IL_6c5c;
	}

IL_0010:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2 = ___textInfo1;
		NullCheck(L_2);
		TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128(L_2, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = __this->___m_CharBuffer_4;
		if (!L_3)
		{
			goto IL_0035;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_4 = __this->___m_CharBuffer_4;
		NullCheck(L_4);
		if (!(((RuntimeArray*)L_4)->max_length))
		{
			goto IL_0035;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_5 = __this->___m_CharBuffer_4;
		NullCheck(L_5);
		int32_t L_6 = 0;
		int32_t L_7 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		G_B6_0 = ((((int32_t)L_7) == ((int32_t)0))? 1 : 0);
		goto IL_0036;
	}

IL_0035:
	{
		G_B6_0 = 1;
	}

IL_0036:
	{
		V_56 = (bool)G_B6_0;
		bool L_8 = V_56;
		if (!L_8)
		{
			goto IL_0060;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_9 = ___textInfo1;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_9, NULL);
		__this->___m_PreferredWidth_5 = (0.0f);
		__this->___m_PreferredHeight_6 = (0.0f);
		goto IL_6c5c;
	}

IL_0060:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_10 = ___generationSettings0;
		NullCheck(L_10);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_11 = L_10->___fontAsset_4;
		__this->___m_CurrentFontAsset_7 = L_11;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset_7), (void*)L_11);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_12 = ___generationSettings0;
		NullCheck(L_12);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_13 = L_12->___material_5;
		__this->___m_CurrentMaterial_8 = L_13;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentMaterial_8), (void*)L_13);
		__this->___m_CurrentMaterialIndex_9 = 0;
		TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* L_14 = (&__this->___m_MaterialReferenceStack_10);
		int32_t L_15 = __this->___m_CurrentMaterialIndex_9;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_16 = __this->___m_CurrentFontAsset_7;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_17 = __this->___m_CurrentMaterial_8;
		float L_18 = __this->___m_Padding_11;
		MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 L_19;
		memset((&L_19), 0, sizeof(L_19));
		MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A((&L_19), L_15, L_16, (SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)NULL, L_17, L_18, /*hidden argument*/NULL);
		TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C(L_14, L_19, TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_20 = ___generationSettings0;
		NullCheck(L_20);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_21 = L_20->___spriteAsset_6;
		__this->___m_CurrentSpriteAsset_12 = L_21;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentSpriteAsset_12), (void*)L_21);
		int32_t L_22 = __this->___m_TotalCharacterCount_13;
		V_0 = L_22;
		float L_23 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_24 = ___generationSettings0;
		NullCheck(L_24);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_25 = L_24->___fontAsset_4;
		NullCheck(L_25);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_26;
		L_26 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_25, NULL);
		V_57 = L_26;
		int32_t L_27;
		L_27 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_57), NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_28 = ___generationSettings0;
		NullCheck(L_28);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_29 = L_28->___fontAsset_4;
		NullCheck(L_29);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_30;
		L_30 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_29, NULL);
		V_57 = L_30;
		float L_31;
		L_31 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		float L_32 = ((float)il2cpp_codegen_multiply(((float)(L_23/((float)L_27))), L_31));
		V_58 = L_32;
		__this->___m_FontScale_14 = L_32;
		float L_33 = V_58;
		V_1 = L_33;
		float L_34 = V_1;
		V_2 = L_34;
		__this->___m_FontScaleMultiplier_16 = (1.0f);
		float L_35 = __this->___m_FontSize_15;
		__this->___m_CurrentFontSize_17 = L_35;
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_36 = (&__this->___m_SizeStack_18);
		float L_37 = __this->___m_CurrentFontSize_17;
		TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9(L_36, L_37, TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_38 = ___generationSettings0;
		NullCheck(L_38);
		int32_t L_39 = L_38->___fontStyle_8;
		__this->___m_FontStyleInternal_19 = L_39;
		int32_t L_40 = __this->___m_FontStyleInternal_19;
		G_B9_0 = __this;
		if ((((int32_t)((int32_t)((int32_t)L_40&1))) == ((int32_t)1)))
		{
			G_B10_0 = __this;
			goto IL_0144;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_41 = ___generationSettings0;
		NullCheck(L_41);
		int32_t L_42 = L_41->___fontWeight_37;
		G_B11_0 = ((int32_t)(L_42));
		G_B11_1 = G_B9_0;
		goto IL_0149;
	}

IL_0144:
	{
		G_B11_0 = ((int32_t)700);
		G_B11_1 = G_B10_0;
	}

IL_0149:
	{
		NullCheck(G_B11_1);
		G_B11_1->___m_FontWeightInternal_21 = G_B11_0;
		TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790* L_43 = (&__this->___m_FontWeightStack_22);
		int32_t L_44 = __this->___m_FontWeightInternal_21;
		TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79(L_43, L_44, TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var);
		FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7* L_45 = (&__this->___m_FontStyleStack_20);
		FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0(L_45, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_46 = ___generationSettings0;
		NullCheck(L_46);
		int32_t L_47 = L_46->___textAlignment_10;
		__this->___m_LineJustification_23 = L_47;
		TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F* L_48 = (&__this->___m_LineJustificationStack_24);
		int32_t L_49 = __this->___m_LineJustification_23;
		TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230(L_48, L_49, TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var);
		V_3 = (0.0f);
		V_4 = (1.0f);
		__this->___m_BaselineOffset_25 = (0.0f);
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_50 = (&__this->___m_BaselineOffsetStack_26);
		TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3(L_50, TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var);
		V_5 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_51;
		L_51 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_6 = L_51;
		V_8 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_52;
		L_52 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_9 = L_52;
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_53;
		L_53 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_12 = L_53;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_54;
		L_54 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_13 = L_54;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_55 = ___generationSettings0;
		NullCheck(L_55);
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_56 = L_55->___color_14;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_57;
		L_57 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_56, NULL);
		__this->___m_FontColor32_27 = L_57;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_58 = __this->___m_FontColor32_27;
		__this->___m_HtmlColor_28 = L_58;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_59 = __this->___m_HtmlColor_28;
		__this->___m_UnderlineColor_29 = L_59;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_60 = __this->___m_HtmlColor_28;
		__this->___m_StrikethroughColor_30 = L_60;
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_61 = (&__this->___m_ColorStack_31);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_62 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_61, L_62, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_63 = (&__this->___m_UnderlineColorStack_32);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_64 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_63, L_64, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_65 = (&__this->___m_StrikethroughColorStack_33);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_66 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_65, L_66, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_67 = (&__this->___m_HighlightColorStack_34);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_68 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_67, L_68, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		__this->___m_ColorGradientPreset_35 = (TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_ColorGradientPreset_35), (void*)(TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL);
		TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E* L_69 = (&__this->___m_ColorGradientStack_36);
		TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9(L_69, (TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL, TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var);
		TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* L_70 = (&__this->___m_ActionStack_37);
		TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD(L_70, TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var);
		__this->___m_IsFxMatrixSet_38 = (bool)0;
		__this->___m_LineOffset_39 = (0.0f);
		__this->___m_LineHeight_40 = (-32767.0f);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_71 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_71);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_72;
		L_72 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_71, NULL);
		V_57 = L_72;
		float L_73;
		L_73 = FaceInfo_get_lineHeight_m528B4A822181FCECF3D4FF1045DF288E5872AB9D((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_74 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_74);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_75;
		L_75 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_74, NULL);
		V_57 = L_75;
		float L_76;
		L_76 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_77 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_77);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_78;
		L_78 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_77, NULL);
		V_57 = L_78;
		float L_79;
		L_79 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3((&V_57), NULL);
		V_14 = ((float)il2cpp_codegen_subtract(L_73, ((float)il2cpp_codegen_subtract(L_76, L_79))));
		__this->___m_CSpacing_41 = (0.0f);
		__this->___m_MonoSpacing_42 = (0.0f);
		__this->___m_XAdvance_43 = (0.0f);
		__this->___m_TagLineIndent_44 = (0.0f);
		__this->___m_TagIndent_45 = (0.0f);
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_80 = (&__this->___m_IndentStack_46);
		TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9(L_80, (0.0f), TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		__this->___m_TagNoParsing_47 = (bool)0;
		__this->___m_CharacterCount_48 = 0;
		__this->___m_FirstCharacterOfLine_49 = 0;
		__this->___m_LastCharacterOfLine_50 = 0;
		__this->___m_FirstVisibleCharacterOfLine_51 = 0;
		__this->___m_LastVisibleCharacterOfLine_52 = 0;
		__this->___m_MaxLineAscender_53 = (-32767.0f);
		__this->___m_MaxLineDescender_54 = (32767.0f);
		__this->___m_LineNumber_55 = 0;
		__this->___m_LineVisibleCharacterCount_56 = 0;
		V_15 = (bool)1;
		__this->___m_FirstOverflowCharacterIndex_57 = (-1);
		__this->___m_PageNumber_58 = 0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_81 = ___generationSettings0;
		NullCheck(L_81);
		int32_t L_82 = L_81->___pageToDisplay_38;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_83 = ___textInfo1;
		NullCheck(L_83);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_84 = L_83->___pageInfo_14;
		NullCheck(L_84);
		int32_t L_85;
		L_85 = Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline(((int32_t)il2cpp_codegen_subtract(L_82, 1)), 0, ((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_84)->max_length)), 1)), NULL);
		V_16 = L_85;
		V_17 = 0;
		V_18 = 0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_86 = ___generationSettings0;
		NullCheck(L_86);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_87 = L_86->___margins_2;
		V_19 = L_87;
		float L_88 = __this->___m_MarginWidth_2;
		V_20 = L_88;
		float L_89 = __this->___m_MarginHeight_3;
		V_21 = L_89;
		__this->___m_MarginLeft_59 = (0.0f);
		__this->___m_MarginRight_60 = (0.0f);
		__this->___m_Width_61 = (-1.0f);
		float L_90 = V_20;
		float L_91 = __this->___m_MarginLeft_59;
		float L_92 = __this->___m_MarginRight_60;
		V_22 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_90, (9.99999975E-05f))), L_91)), L_92));
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_93 = (&__this->___m_MeshExtents_62);
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_94 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largePositiveVector2_0;
		L_93->___min_0 = L_94;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_95 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_96 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largeNegativeVector2_1;
		L_95->___max_1 = L_96;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_97 = ___generationSettings0;
		NullCheck(L_97);
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_98 = L_97->___textSettings_9;
		V_23 = L_98;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_99 = ___textInfo1;
		NullCheck(L_99);
		TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7(L_99, NULL);
		__this->___m_MaxCapHeight_63 = (0.0f);
		__this->___m_MaxAscender_64 = (0.0f);
		__this->___m_MaxDescender_65 = (0.0f);
		V_24 = (0.0f);
		V_25 = (0.0f);
		V_26 = (bool)0;
		__this->___m_IsNewPage_66 = (bool)0;
		V_27 = (bool)1;
		__this->___m_IsNonBreakingSpace_67 = (bool)0;
		V_28 = (bool)0;
		V_29 = (bool)0;
		V_30 = 0;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_100 = (&__this->___m_SavedWordWrapState_68);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_101 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_100, (-1), (-1), L_101, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_102 = (&__this->___m_SavedLineState_69);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_103 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_102, (-1), (-1), L_103, NULL);
		int32_t L_104 = __this->___m_LoopCountA_70;
		__this->___m_LoopCountA_70 = ((int32_t)il2cpp_codegen_add(L_104, 1));
		V_59 = 0;
		goto IL_32a7;
	}

IL_0496:
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_105 = __this->___m_CharBuffer_4;
		int32_t L_106 = V_59;
		NullCheck(L_105);
		int32_t L_107 = L_106;
		int32_t L_108 = (L_105)->GetAt(static_cast<il2cpp_array_size_t>(L_107));
		V_60 = L_108;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_109 = ___generationSettings0;
		NullCheck(L_109);
		bool L_110 = L_109->___richText_23;
		if (!L_110)
		{
			goto IL_04b2;
		}
	}
	{
		int32_t L_111 = V_60;
		G_B15_0 = ((((int32_t)L_111) == ((int32_t)((int32_t)60)))? 1 : 0);
		goto IL_04b3;
	}

IL_04b2:
	{
		G_B15_0 = 0;
	}

IL_04b3:
	{
		V_78 = (bool)G_B15_0;
		bool L_112 = V_78;
		if (!L_112)
		{
			goto IL_04ff;
		}
	}
	{
		__this->___m_IsParsingText_72 = (bool)1;
		__this->___m_TextElementType_71 = 1;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_113 = __this->___m_CharBuffer_4;
		int32_t L_114 = V_59;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_115 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_116 = ___textInfo1;
		bool L_117;
		L_117 = TextGenerator_ValidateHtmlTag_m9C85462F15A6165B10E4C4EE93620AC1021BE5CD(__this, L_113, ((int32_t)il2cpp_codegen_add(L_114, 1)), (&V_31), L_115, L_116, NULL);
		V_79 = L_117;
		bool L_118 = V_79;
		if (!L_118)
		{
			goto IL_04fc;
		}
	}
	{
		int32_t L_119 = V_31;
		V_59 = L_119;
		uint8_t L_120 = __this->___m_TextElementType_71;
		V_80 = (bool)((((int32_t)L_120) == ((int32_t)1))? 1 : 0);
		bool L_121 = V_80;
		if (!L_121)
		{
			goto IL_04fb;
		}
	}
	{
		goto IL_329d;
	}

IL_04fb:
	{
	}

IL_04fc:
	{
		goto IL_0555;
	}

IL_04ff:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_122 = ___textInfo1;
		NullCheck(L_122);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_123 = L_122->___textElementInfo_10;
		int32_t L_124 = __this->___m_CharacterCount_48;
		NullCheck(L_123);
		uint8_t L_125 = ((L_123)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_124)))->___elementType_2;
		__this->___m_TextElementType_71 = L_125;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_126 = ___textInfo1;
		NullCheck(L_126);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_127 = L_126->___textElementInfo_10;
		int32_t L_128 = __this->___m_CharacterCount_48;
		NullCheck(L_127);
		int32_t L_129 = ((L_127)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_128)))->___materialReferenceIndex_8;
		__this->___m_CurrentMaterialIndex_9 = L_129;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_130 = ___textInfo1;
		NullCheck(L_130);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_131 = L_130->___textElementInfo_10;
		int32_t L_132 = __this->___m_CharacterCount_48;
		NullCheck(L_131);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_133 = ((L_131)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_132)))->___fontAsset_4;
		__this->___m_CurrentFontAsset_7 = L_133;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset_7), (void*)L_133);
	}

IL_0555:
	{
		int32_t L_134 = __this->___m_CurrentMaterialIndex_9;
		V_61 = L_134;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_135 = ___textInfo1;
		NullCheck(L_135);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_136 = L_135->___textElementInfo_10;
		int32_t L_137 = __this->___m_CharacterCount_48;
		NullCheck(L_136);
		bool L_138 = ((L_136)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_137)))->___isUsingAlternateTypeface_9;
		V_62 = L_138;
		__this->___m_IsParsingText_72 = (bool)0;
		int32_t L_139 = __this->___m_CharacterCount_48;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_140 = ___generationSettings0;
		NullCheck(L_140);
		int32_t L_141 = L_140->___firstVisibleCharacter_35;
		V_81 = (bool)((((int32_t)L_139) < ((int32_t)L_141))? 1 : 0);
		bool L_142 = V_81;
		if (!L_142)
		{
			goto IL_05d6;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_143 = ___textInfo1;
		NullCheck(L_143);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_144 = L_143->___textElementInfo_10;
		int32_t L_145 = __this->___m_CharacterCount_48;
		NullCheck(L_144);
		((L_144)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_145)))->___isVisible_34 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_146 = ___textInfo1;
		NullCheck(L_146);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_147 = L_146->___textElementInfo_10;
		int32_t L_148 = __this->___m_CharacterCount_48;
		NullCheck(L_147);
		((L_147)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_148)))->___character_0 = ((int32_t)8203);
		int32_t L_149 = __this->___m_CharacterCount_48;
		__this->___m_CharacterCount_48 = ((int32_t)il2cpp_codegen_add(L_149, 1));
		goto IL_329d;
	}

IL_05d6:
	{
		V_63 = (1.0f);
		uint8_t L_150 = __this->___m_TextElementType_71;
		V_82 = (bool)((((int32_t)L_150) == ((int32_t)1))? 1 : 0);
		bool L_151 = V_82;
		if (!L_151)
		{
			goto IL_0683;
		}
	}
	{
		int32_t L_152 = __this->___m_FontStyleInternal_19;
		V_83 = (bool)((((int32_t)((int32_t)((int32_t)L_152&((int32_t)16)))) == ((int32_t)((int32_t)16)))? 1 : 0);
		bool L_153 = V_83;
		if (!L_153)
		{
			goto IL_061f;
		}
	}
	{
		int32_t L_154 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_155;
		L_155 = Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE(((int32_t)(uint16_t)L_154), NULL);
		V_84 = L_155;
		bool L_156 = V_84;
		if (!L_156)
		{
			goto IL_061c;
		}
	}
	{
		int32_t L_157 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_158;
		L_158 = Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2(((int32_t)(uint16_t)L_157), NULL);
		V_60 = L_158;
	}

IL_061c:
	{
		goto IL_0682;
	}

IL_061f:
	{
		int32_t L_159 = __this->___m_FontStyleInternal_19;
		V_85 = (bool)((((int32_t)((int32_t)((int32_t)L_159&8))) == ((int32_t)8))? 1 : 0);
		bool L_160 = V_85;
		if (!L_160)
		{
			goto IL_064c;
		}
	}
	{
		int32_t L_161 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_162;
		L_162 = Char_IsUpper_mF150C44B70F522A14B2A8DF71DE0ADE52F9A3392(((int32_t)(uint16_t)L_161), NULL);
		V_86 = L_162;
		bool L_163 = V_86;
		if (!L_163)
		{
			goto IL_0649;
		}
	}
	{
		int32_t L_164 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_165;
		L_165 = Char_ToLower_m238489988C62CB10C7C7CAAEF8F3B2D1C5B5E056(((int32_t)(uint16_t)L_164), NULL);
		V_60 = L_165;
	}

IL_0649:
	{
		goto IL_0682;
	}

IL_064c:
	{
		int32_t L_166 = __this->___m_FontStyleInternal_19;
		V_87 = (bool)((((int32_t)((int32_t)((int32_t)L_166&((int32_t)32)))) == ((int32_t)((int32_t)32)))? 1 : 0);
		bool L_167 = V_87;
		if (!L_167)
		{
			goto IL_0682;
		}
	}
	{
		int32_t L_168 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_169;
		L_169 = Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE(((int32_t)(uint16_t)L_168), NULL);
		V_88 = L_169;
		bool L_170 = V_88;
		if (!L_170)
		{
			goto IL_0681;
		}
	}
	{
		V_63 = (0.800000012f);
		int32_t L_171 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_172;
		L_172 = Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2(((int32_t)(uint16_t)L_171), NULL);
		V_60 = L_172;
	}

IL_0681:
	{
	}

IL_0682:
	{
	}

IL_0683:
	{
		uint8_t L_173 = __this->___m_TextElementType_71;
		V_89 = (bool)((((int32_t)L_173) == ((int32_t)2))? 1 : 0);
		bool L_174 = V_89;
		if (!L_174)
		{
			goto IL_0831;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_175 = ___textInfo1;
		NullCheck(L_175);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_176 = L_175->___textElementInfo_10;
		int32_t L_177 = __this->___m_CharacterCount_48;
		NullCheck(L_176);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_178 = ((L_176)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_177)))->___spriteAsset_5;
		__this->___m_CurrentSpriteAsset_12 = L_178;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentSpriteAsset_12), (void*)L_178);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_179 = ___textInfo1;
		NullCheck(L_179);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_180 = L_179->___textElementInfo_10;
		int32_t L_181 = __this->___m_CharacterCount_48;
		NullCheck(L_180);
		int32_t L_182 = ((L_180)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_181)))->___spriteIndex_6;
		__this->___m_SpriteIndex_73 = L_182;
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_183 = __this->___m_CurrentSpriteAsset_12;
		NullCheck(L_183);
		List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51* L_184;
		L_184 = SpriteAsset_get_spriteCharacterTable_m8D0D65C430AD8BC8C2BC8151DC4672CC0F690E0A(L_183, NULL);
		int32_t L_185 = __this->___m_SpriteIndex_73;
		NullCheck(L_184);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_186;
		L_186 = List_1_get_Item_m25CB12C13D14620785B0E86F6543D20B5080AFF8(L_184, L_185, List_1_get_Item_m25CB12C13D14620785B0E86F6543D20B5080AFF8_RuntimeMethod_var);
		V_90 = L_186;
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_187 = V_90;
		V_92 = (bool)((((RuntimeObject*)(SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5*)L_187) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_188 = V_92;
		if (!L_188)
		{
			goto IL_06f6;
		}
	}
	{
		goto IL_329d;
	}

IL_06f6:
	{
		int32_t L_189 = V_60;
		V_93 = (bool)((((int32_t)L_189) == ((int32_t)((int32_t)60)))? 1 : 0);
		bool L_190 = V_93;
		if (!L_190)
		{
			goto IL_0712;
		}
	}
	{
		int32_t L_191 = __this->___m_SpriteIndex_73;
		V_60 = ((int32_t)il2cpp_codegen_add(((int32_t)57344), L_191));
		goto IL_0722;
	}

IL_0712:
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_192;
		L_192 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_193;
		L_193 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_192, NULL);
		__this->___m_SpriteColor_74 = L_193;
	}

IL_0722:
	{
		float L_194 = __this->___m_CurrentFontSize_17;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_195 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_195);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_196;
		L_196 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_195, NULL);
		V_57 = L_196;
		int32_t L_197;
		L_197 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_198 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_198);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_199;
		L_199 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_198, NULL);
		V_57 = L_199;
		float L_200;
		L_200 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		V_91 = ((float)il2cpp_codegen_multiply(((float)(L_194/((float)L_197))), L_200));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_201 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_201);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_202;
		L_202 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_201, NULL);
		V_57 = L_202;
		float L_203;
		L_203 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD((&V_57), NULL);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_204 = V_90;
		NullCheck(L_204);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_205;
		L_205 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_204, NULL);
		NullCheck(L_205);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_206;
		L_206 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_205, NULL);
		V_94 = L_206;
		float L_207;
		L_207 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_94), NULL);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_208 = V_90;
		NullCheck(L_208);
		float L_209;
		L_209 = TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6(L_208, NULL);
		float L_210 = V_91;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_211 = ___generationSettings0;
		NullCheck(L_211);
		float L_212 = L_211->___scale_3;
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_203/L_207)), L_209)), L_210)), L_212));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_213 = V_90;
		__this->___m_CachedTextElement_75 = L_213;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CachedTextElement_75), (void*)L_213);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_214 = ___textInfo1;
		NullCheck(L_214);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_215 = L_214->___textElementInfo_10;
		int32_t L_216 = __this->___m_CharacterCount_48;
		NullCheck(L_215);
		((L_215)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_216)))->___elementType_2 = 2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_217 = ___textInfo1;
		NullCheck(L_217);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_218 = L_217->___textElementInfo_10;
		int32_t L_219 = __this->___m_CharacterCount_48;
		NullCheck(L_218);
		float L_220 = V_91;
		((L_218)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_219)))->___scale_28 = L_220;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_221 = ___textInfo1;
		NullCheck(L_221);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_222 = L_221->___textElementInfo_10;
		int32_t L_223 = __this->___m_CharacterCount_48;
		NullCheck(L_222);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_224 = __this->___m_CurrentSpriteAsset_12;
		((L_222)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_223)))->___spriteAsset_5 = L_224;
		Il2CppCodeGenWriteBarrier((void**)(&((L_222)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_223)))->___spriteAsset_5), (void*)L_224);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_225 = ___textInfo1;
		NullCheck(L_225);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_226 = L_225->___textElementInfo_10;
		int32_t L_227 = __this->___m_CharacterCount_48;
		NullCheck(L_226);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_228 = __this->___m_CurrentFontAsset_7;
		((L_226)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_227)))->___fontAsset_4 = L_228;
		Il2CppCodeGenWriteBarrier((void**)(&((L_226)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_227)))->___fontAsset_4), (void*)L_228);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_229 = ___textInfo1;
		NullCheck(L_229);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_230 = L_229->___textElementInfo_10;
		int32_t L_231 = __this->___m_CharacterCount_48;
		NullCheck(L_230);
		int32_t L_232 = __this->___m_CurrentMaterialIndex_9;
		((L_230)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_231)))->___materialReferenceIndex_8 = L_232;
		int32_t L_233 = V_61;
		__this->___m_CurrentMaterialIndex_9 = L_233;
		V_3 = (0.0f);
		goto IL_0975;
	}

IL_0831:
	{
		uint8_t L_234 = __this->___m_TextElementType_71;
		V_95 = (bool)((((int32_t)L_234) == ((int32_t)1))? 1 : 0);
		bool L_235 = V_95;
		if (!L_235)
		{
			goto IL_0975;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_236 = ___textInfo1;
		NullCheck(L_236);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_237 = L_236->___textElementInfo_10;
		int32_t L_238 = __this->___m_CharacterCount_48;
		NullCheck(L_237);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_239 = ((L_237)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_238)))->___textElement_3;
		__this->___m_CachedTextElement_75 = L_239;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CachedTextElement_75), (void*)L_239);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_240 = __this->___m_CachedTextElement_75;
		V_96 = (bool)((((RuntimeObject*)(TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_240) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_241 = V_96;
		if (!L_241)
		{
			goto IL_0874;
		}
	}
	{
		goto IL_329d;
	}

IL_0874:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_242 = ___textInfo1;
		NullCheck(L_242);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_243 = L_242->___textElementInfo_10;
		int32_t L_244 = __this->___m_CharacterCount_48;
		NullCheck(L_243);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_245 = ((L_243)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_244)))->___fontAsset_4;
		__this->___m_CurrentFontAsset_7 = L_245;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset_7), (void*)L_245);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_246 = ___textInfo1;
		NullCheck(L_246);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_247 = L_246->___textElementInfo_10;
		int32_t L_248 = __this->___m_CharacterCount_48;
		NullCheck(L_247);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_249 = ((L_247)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_248)))->___material_7;
		__this->___m_CurrentMaterial_8 = L_249;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentMaterial_8), (void*)L_249);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_250 = ___textInfo1;
		NullCheck(L_250);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_251 = L_250->___textElementInfo_10;
		int32_t L_252 = __this->___m_CharacterCount_48;
		NullCheck(L_251);
		int32_t L_253 = ((L_251)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_252)))->___materialReferenceIndex_8;
		__this->___m_CurrentMaterialIndex_9 = L_253;
		float L_254 = __this->___m_CurrentFontSize_17;
		float L_255 = V_63;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_256 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_256);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_257;
		L_257 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_256, NULL);
		V_57 = L_257;
		int32_t L_258;
		L_258 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_259 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_259);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_260;
		L_260 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_259, NULL);
		V_57 = L_260;
		float L_261;
		L_261 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		__this->___m_FontScale_14 = ((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_multiply(L_254, L_255))/((float)L_258))), L_261));
		float L_262 = __this->___m_FontScale_14;
		float L_263 = __this->___m_FontScaleMultiplier_16;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_264 = __this->___m_CachedTextElement_75;
		NullCheck(L_264);
		float L_265;
		L_265 = TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6(L_264, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_266 = ___generationSettings0;
		NullCheck(L_266);
		float L_267 = L_266->___scale_3;
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_262, L_263)), L_265)), L_267));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_268 = ___textInfo1;
		NullCheck(L_268);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_269 = L_268->___textElementInfo_10;
		int32_t L_270 = __this->___m_CharacterCount_48;
		NullCheck(L_269);
		((L_269)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_270)))->___elementType_2 = 1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_271 = ___textInfo1;
		NullCheck(L_271);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_272 = L_271->___textElementInfo_10;
		int32_t L_273 = __this->___m_CharacterCount_48;
		NullCheck(L_272);
		float L_274 = V_2;
		((L_272)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_273)))->___scale_28 = L_274;
		int32_t L_275 = __this->___m_CurrentMaterialIndex_9;
		if (!L_275)
		{
			goto IL_096d;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_276 = __this->___m_CurrentMaterial_8;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_277 = ___generationSettings0;
		NullCheck(L_277);
		bool L_278 = L_277->___extraPadding_25;
		float L_279;
		L_279 = TextGenerator_GetPaddingForMaterial_mE5A4DEF3F64851861C092F7A4FC58C902F775C74(__this, L_276, L_278, NULL);
		G_B51_0 = L_279;
		goto IL_0973;
	}

IL_096d:
	{
		float L_280 = __this->___m_Padding_11;
		G_B51_0 = L_280;
	}

IL_0973:
	{
		V_3 = G_B51_0;
	}

IL_0975:
	{
		float L_281 = V_2;
		V_64 = L_281;
		int32_t L_282 = V_60;
		V_97 = (bool)((((int32_t)L_282) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_283 = V_97;
		if (!L_283)
		{
			goto IL_098f;
		}
	}
	{
		V_2 = (0.0f);
	}

IL_098f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_284 = ___textInfo1;
		NullCheck(L_284);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_285 = L_284->___textElementInfo_10;
		int32_t L_286 = __this->___m_CharacterCount_48;
		NullCheck(L_285);
		int32_t L_287 = V_60;
		((L_285)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_286)))->___character_0 = ((int32_t)(uint16_t)L_287);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_288 = ___textInfo1;
		NullCheck(L_288);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_289 = L_288->___textElementInfo_10;
		int32_t L_290 = __this->___m_CharacterCount_48;
		NullCheck(L_289);
		float L_291 = __this->___m_CurrentFontSize_17;
		((L_289)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_290)))->___pointSize_10 = L_291;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_292 = ___textInfo1;
		NullCheck(L_292);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_293 = L_292->___textElementInfo_10;
		int32_t L_294 = __this->___m_CharacterCount_48;
		NullCheck(L_293);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_295 = __this->___m_HtmlColor_28;
		((L_293)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_294)))->___color_29 = L_295;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_296 = ___textInfo1;
		NullCheck(L_296);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_297 = L_296->___textElementInfo_10;
		int32_t L_298 = __this->___m_CharacterCount_48;
		NullCheck(L_297);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_299 = __this->___m_UnderlineColor_29;
		((L_297)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_298)))->___underlineColor_30 = L_299;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_300 = ___textInfo1;
		NullCheck(L_300);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_301 = L_300->___textElementInfo_10;
		int32_t L_302 = __this->___m_CharacterCount_48;
		NullCheck(L_301);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_303 = __this->___m_StrikethroughColor_30;
		((L_301)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_302)))->___strikethroughColor_31 = L_303;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_304 = ___textInfo1;
		NullCheck(L_304);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_305 = L_304->___textElementInfo_10;
		int32_t L_306 = __this->___m_CharacterCount_48;
		NullCheck(L_305);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_307 = __this->___m_HighlightColor_76;
		((L_305)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_306)))->___highlightColor_32 = L_307;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_308 = ___textInfo1;
		NullCheck(L_308);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_309 = L_308->___textElementInfo_10;
		int32_t L_310 = __this->___m_CharacterCount_48;
		NullCheck(L_309);
		int32_t L_311 = __this->___m_FontStyleInternal_19;
		((L_309)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_310)))->___style_33 = L_311;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_312 = ___textInfo1;
		NullCheck(L_312);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_313 = L_312->___textElementInfo_10;
		int32_t L_314 = __this->___m_CharacterCount_48;
		NullCheck(L_313);
		int32_t L_315 = V_59;
		((L_313)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_314)))->___index_1 = L_315;
		il2cpp_codegen_initobj((&V_65), sizeof(GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_316 = ___generationSettings0;
		NullCheck(L_316);
		float L_317 = L_316->___characterSpacing_27;
		V_66 = L_317;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_318 = ___generationSettings0;
		NullCheck(L_318);
		bool L_319 = L_318->___enableKerning_22;
		V_98 = L_319;
		bool L_320 = V_98;
		if (!L_320)
		{
			goto IL_0b7c;
		}
	}
	{
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_321 = __this->___m_CachedTextElement_75;
		NullCheck(L_321);
		uint32_t L_322;
		L_322 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_321, NULL);
		V_100 = L_322;
		int32_t L_323 = __this->___m_CharacterCount_48;
		int32_t L_324 = V_0;
		V_101 = (bool)((((int32_t)L_323) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_324, 1))))? 1 : 0);
		bool L_325 = V_101;
		if (!L_325)
		{
			goto IL_0b04;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_326 = ___textInfo1;
		NullCheck(L_326);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_327 = L_326->___textElementInfo_10;
		int32_t L_328 = __this->___m_CharacterCount_48;
		NullCheck(L_327);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_329 = ((L_327)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_328, 1)))))->___textElement_3;
		NullCheck(L_329);
		uint32_t L_330;
		L_330 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_329, NULL);
		V_102 = L_330;
		uint32_t L_331 = V_102;
		uint32_t L_332 = V_100;
		V_103 = ((int32_t)(((int32_t)((int32_t)L_331<<((int32_t)16)))|(int32_t)L_332));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_333 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_333);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_334 = L_333->___m_FontFeatureTable_32;
		NullCheck(L_334);
		Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* L_335 = L_334->___m_GlyphPairAdjustmentRecordLookup_1;
		uint32_t L_336 = V_103;
		NullCheck(L_335);
		bool L_337;
		L_337 = Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA(L_335, L_336, (&V_99), Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		V_104 = L_337;
		bool L_338 = V_104;
		if (!L_338)
		{
			goto IL_0b03;
		}
	}
	{
		GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 L_339;
		L_339 = GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m867469548F17B298F893B78EE2F93D34E4A6C39C((&V_99), NULL);
		V_105 = L_339;
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_340;
		L_340 = GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7((&V_105), NULL);
		V_65 = L_340;
	}

IL_0b03:
	{
	}

IL_0b04:
	{
		int32_t L_341 = __this->___m_CharacterCount_48;
		V_106 = (bool)((((int32_t)((((int32_t)L_341) < ((int32_t)1))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_342 = V_106;
		if (!L_342)
		{
			goto IL_0b7b;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_343 = ___textInfo1;
		NullCheck(L_343);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_344 = L_343->___textElementInfo_10;
		int32_t L_345 = __this->___m_CharacterCount_48;
		NullCheck(L_344);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_346 = ((L_344)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_345, 1)))))->___textElement_3;
		NullCheck(L_346);
		uint32_t L_347;
		L_347 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_346, NULL);
		V_107 = L_347;
		uint32_t L_348 = V_100;
		uint32_t L_349 = V_107;
		V_108 = ((int32_t)(((int32_t)((int32_t)L_348<<((int32_t)16)))|(int32_t)L_349));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_350 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_350);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_351 = L_350->___m_FontFeatureTable_32;
		NullCheck(L_351);
		Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* L_352 = L_351->___m_GlyphPairAdjustmentRecordLookup_1;
		uint32_t L_353 = V_108;
		NullCheck(L_352);
		bool L_354;
		L_354 = Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA(L_352, L_353, (&V_99), Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		V_109 = L_354;
		bool L_355 = V_109;
		if (!L_355)
		{
			goto IL_0b7a;
		}
	}
	{
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_356 = V_65;
		GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 L_357;
		L_357 = GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_mFDFECB1F7A38E22BD2388FFE9C71E732F6B44D91((&V_99), NULL);
		V_105 = L_357;
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_358;
		L_358 = GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7((&V_105), NULL);
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_359;
		L_359 = GlyphValueRecord_op_Addition_mF26165B4CE61A5409AEFF24B0D1727804E13602B(L_356, L_358, NULL);
		V_65 = L_359;
	}

IL_0b7a:
	{
	}

IL_0b7b:
	{
	}

IL_0b7c:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_360 = ___generationSettings0;
		NullCheck(L_360);
		bool L_361 = L_360->___isRightToLeft_24;
		V_110 = L_361;
		bool L_362 = V_110;
		if (!L_362)
		{
			goto IL_0c17;
		}
	}
	{
		float L_363 = __this->___m_XAdvance_43;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_364 = __this->___m_CachedTextElement_75;
		NullCheck(L_364);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_365;
		L_365 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_364, NULL);
		NullCheck(L_365);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_366;
		L_366 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_365, NULL);
		V_94 = L_366;
		float L_367;
		L_367 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_94), NULL);
		float L_368 = V_4;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_369 = ___generationSettings0;
		NullCheck(L_369);
		float L_370 = L_369->___characterSpacing_27;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_371 = ___generationSettings0;
		NullCheck(L_371);
		float L_372 = L_371->___wordSpacing_28;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_373 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_373);
		float L_374;
		L_374 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_373, NULL);
		float L_375 = V_2;
		float L_376 = __this->___m_CSpacing_41;
		float L_377 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_subtract(L_363, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_367, L_368)), L_370)), L_372)), L_374)), L_375)), L_376)), ((float)il2cpp_codegen_subtract((1.0f), L_377))))));
		int32_t L_378 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_379;
		L_379 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_378), NULL);
		if (L_379)
		{
			goto IL_0bfa;
		}
	}
	{
		int32_t L_380 = V_60;
		G_B68_0 = ((((int32_t)L_380) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_0bfb;
	}

IL_0bfa:
	{
		G_B68_0 = 1;
	}

IL_0bfb:
	{
		V_111 = (bool)G_B68_0;
		bool L_381 = V_111;
		if (!L_381)
		{
			goto IL_0c16;
		}
	}
	{
		float L_382 = __this->___m_XAdvance_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_383 = ___generationSettings0;
		NullCheck(L_383);
		float L_384 = L_383->___wordSpacing_28;
		float L_385 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_subtract(L_382, ((float)il2cpp_codegen_multiply(L_384, L_385))));
	}

IL_0c16:
	{
	}

IL_0c17:
	{
		V_67 = (0.0f);
		float L_386 = __this->___m_MonoSpacing_42;
		V_112 = (bool)((((int32_t)((((float)L_386) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_387 = V_112;
		if (!L_387)
		{
			goto IL_0c9c;
		}
	}
	{
		float L_388 = __this->___m_MonoSpacing_42;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_389 = __this->___m_CachedTextElement_75;
		NullCheck(L_389);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_390;
		L_390 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_389, NULL);
		NullCheck(L_390);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_391;
		L_391 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_390, NULL);
		V_94 = L_391;
		float L_392;
		L_392 = GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13((&V_94), NULL);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_393 = __this->___m_CachedTextElement_75;
		NullCheck(L_393);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_394;
		L_394 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_393, NULL);
		NullCheck(L_394);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_395;
		L_395 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_394, NULL);
		V_94 = L_395;
		float L_396;
		L_396 = GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F((&V_94), NULL);
		float L_397 = V_2;
		float L_398 = __this->___m_CharWidthAdjDelta_77;
		V_67 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)(L_388/(2.0f))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)(L_392/(2.0f))), L_396)), L_397)))), ((float)il2cpp_codegen_subtract((1.0f), L_398))));
		float L_399 = __this->___m_XAdvance_43;
		float L_400 = V_67;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_399, L_400));
	}

IL_0c9c:
	{
		uint8_t L_401 = __this->___m_TextElementType_71;
		if ((!(((uint32_t)L_401) == ((uint32_t)1))))
		{
			goto IL_0cb6;
		}
	}
	{
		bool L_402 = V_62;
		if (L_402)
		{
			goto IL_0cb6;
		}
	}
	{
		int32_t L_403 = __this->___m_FontStyleInternal_19;
		G_B77_0 = ((((int32_t)((int32_t)((int32_t)L_403&1))) == ((int32_t)1))? 1 : 0);
		goto IL_0cb7;
	}

IL_0cb6:
	{
		G_B77_0 = 0;
	}

IL_0cb7:
	{
		V_113 = (bool)G_B77_0;
		bool L_404 = V_113;
		if (!L_404)
		{
			goto IL_0d4b;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_405 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_406 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_405);
		bool L_407;
		L_407 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_405, L_406, NULL);
		V_114 = L_407;
		bool L_408 = V_114;
		if (!L_408)
		{
			goto IL_0d28;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_409 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_410 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_409);
		float L_411;
		L_411 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_409, L_410, NULL);
		V_115 = L_411;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_412 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_412);
		float L_413;
		L_413 = FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA(L_412, NULL);
		float L_414 = V_115;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_415 = __this->___m_CurrentMaterial_8;
		int32_t L_416 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A_49;
		NullCheck(L_415);
		float L_417;
		L_417 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_415, L_416, NULL);
		V_68 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_413/(4.0f))), L_414)), L_417));
		float L_418 = V_68;
		float L_419 = V_3;
		float L_420 = V_115;
		V_116 = (bool)((((float)((float)il2cpp_codegen_add(L_418, L_419))) > ((float)L_420))? 1 : 0);
		bool L_421 = V_116;
		if (!L_421)
		{
			goto IL_0d25;
		}
	}
	{
		float L_422 = V_115;
		float L_423 = V_68;
		V_3 = ((float)il2cpp_codegen_subtract(L_422, L_423));
	}

IL_0d25:
	{
		goto IL_0d2f;
	}

IL_0d28:
	{
		V_68 = (0.0f);
	}

IL_0d2f:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_424 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_424);
		float L_425;
		L_425 = FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0(L_424, NULL);
		V_4 = ((float)il2cpp_codegen_add((1.0f), ((float)il2cpp_codegen_multiply(L_425, (0.00999999978f)))));
		goto IL_0dc2;
	}

IL_0d4b:
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_426 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_427 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_426);
		bool L_428;
		L_428 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_426, L_427, NULL);
		V_117 = L_428;
		bool L_429 = V_117;
		if (!L_429)
		{
			goto IL_0db3;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_430 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_431 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_430);
		float L_432;
		L_432 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_430, L_431, NULL);
		V_118 = L_432;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_433 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_433);
		float L_434;
		L_434 = FontAsset_get_regularStyleWeight_m6C4B4D4CAD36800E6E686A05A5DB8D4475F2707F(L_433, NULL);
		float L_435 = V_118;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_436 = __this->___m_CurrentMaterial_8;
		int32_t L_437 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A_49;
		NullCheck(L_436);
		float L_438;
		L_438 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_436, L_437, NULL);
		V_68 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_434/(4.0f))), L_435)), L_438));
		float L_439 = V_68;
		float L_440 = V_3;
		float L_441 = V_118;
		V_119 = (bool)((((float)((float)il2cpp_codegen_add(L_439, L_440))) > ((float)L_441))? 1 : 0);
		bool L_442 = V_119;
		if (!L_442)
		{
			goto IL_0db0;
		}
	}
	{
		float L_443 = V_118;
		float L_444 = V_68;
		V_3 = ((float)il2cpp_codegen_subtract(L_443, L_444));
	}

IL_0db0:
	{
		goto IL_0dba;
	}

IL_0db3:
	{
		V_68 = (0.0f);
	}

IL_0dba:
	{
		V_4 = (1.0f);
	}

IL_0dc2:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_445 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_445);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_446;
		L_446 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_445, NULL);
		V_57 = L_446;
		float L_447;
		L_447 = FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A((&V_57), NULL);
		float L_448 = __this->___m_FontScale_14;
		float L_449 = __this->___m_FontScaleMultiplier_16;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_450 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_450);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_451;
		L_451 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_450, NULL);
		V_57 = L_451;
		float L_452;
		L_452 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		V_69 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_447, L_448)), L_449)), L_452));
		float L_453 = __this->___m_XAdvance_43;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_454 = __this->___m_CachedTextElement_75;
		NullCheck(L_454);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_455;
		L_455 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_454, NULL);
		NullCheck(L_455);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_456;
		L_456 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_455, NULL);
		V_94 = L_456;
		float L_457;
		L_457 = GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F((&V_94), NULL);
		float L_458 = V_3;
		float L_459 = V_68;
		float L_460;
		L_460 = GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8((&V_65), NULL);
		float L_461 = V_2;
		float L_462 = __this->___m_CharWidthAdjDelta_77;
		(&V_70)->___x_2 = ((float)il2cpp_codegen_add(L_453, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_457, L_458)), L_459)), L_460)), L_461)), ((float)il2cpp_codegen_subtract((1.0f), L_462))))));
		float L_463 = V_69;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_464 = __this->___m_CachedTextElement_75;
		NullCheck(L_464);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_465;
		L_465 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_464, NULL);
		NullCheck(L_465);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_466;
		L_466 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_465, NULL);
		V_94 = L_466;
		float L_467;
		L_467 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_94), NULL);
		float L_468 = V_3;
		float L_469;
		L_469 = GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA((&V_65), NULL);
		float L_470 = V_2;
		float L_471 = __this->___m_LineOffset_39;
		float L_472 = __this->___m_BaselineOffset_25;
		(&V_70)->___y_3 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_463, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_467, L_468)), L_469)), L_470)))), L_471)), L_472));
		(&V_70)->___z_4 = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_473 = V_70;
		float L_474 = L_473.___x_2;
		(&V_71)->___x_2 = L_474;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_475 = V_70;
		float L_476 = L_475.___y_3;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_477 = __this->___m_CachedTextElement_75;
		NullCheck(L_477);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_478;
		L_478 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_477, NULL);
		NullCheck(L_478);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_479;
		L_479 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_478, NULL);
		V_94 = L_479;
		float L_480;
		L_480 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_94), NULL);
		float L_481 = V_3;
		float L_482 = V_2;
		(&V_71)->___y_3 = ((float)il2cpp_codegen_subtract(L_476, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_480, ((float)il2cpp_codegen_multiply(L_481, (2.0f))))), L_482))));
		(&V_71)->___z_4 = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_483 = V_71;
		float L_484 = L_483.___x_2;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_485 = __this->___m_CachedTextElement_75;
		NullCheck(L_485);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_486;
		L_486 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_485, NULL);
		NullCheck(L_486);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_487;
		L_487 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_486, NULL);
		V_94 = L_487;
		float L_488;
		L_488 = GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13((&V_94), NULL);
		float L_489 = V_3;
		float L_490 = V_68;
		float L_491 = V_2;
		float L_492 = __this->___m_CharWidthAdjDelta_77;
		(&V_72)->___x_2 = ((float)il2cpp_codegen_add(L_484, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_488, ((float)il2cpp_codegen_multiply(L_489, (2.0f))))), ((float)il2cpp_codegen_multiply(L_490, (2.0f))))), L_491)), ((float)il2cpp_codegen_subtract((1.0f), L_492))))));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_493 = V_70;
		float L_494 = L_493.___y_3;
		(&V_72)->___y_3 = L_494;
		(&V_72)->___z_4 = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_495 = V_72;
		float L_496 = L_495.___x_2;
		(&V_73)->___x_2 = L_496;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_497 = V_71;
		float L_498 = L_497.___y_3;
		(&V_73)->___y_3 = L_498;
		(&V_73)->___z_4 = (0.0f);
		uint8_t L_499 = __this->___m_TextElementType_71;
		if ((!(((uint32_t)L_499) == ((uint32_t)1))))
		{
			goto IL_0f77;
		}
	}
	{
		bool L_500 = V_62;
		if (L_500)
		{
			goto IL_0f77;
		}
	}
	{
		int32_t L_501 = __this->___m_FontStyleInternal_19;
		G_B94_0 = ((((int32_t)((int32_t)((int32_t)L_501&2))) == ((int32_t)2))? 1 : 0);
		goto IL_0f78;
	}

IL_0f77:
	{
		G_B94_0 = 0;
	}

IL_0f78:
	{
		V_120 = (bool)G_B94_0;
		bool L_502 = V_120;
		if (!L_502)
		{
			goto IL_1045;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_503 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_503);
		uint8_t L_504;
		L_504 = FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B(L_503, NULL);
		V_121 = ((float)il2cpp_codegen_multiply(((float)L_504), (0.00999999978f)));
		float L_505 = V_121;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_506 = __this->___m_CachedTextElement_75;
		NullCheck(L_506);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_507;
		L_507 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_506, NULL);
		NullCheck(L_507);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_508;
		L_508 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_507, NULL);
		V_94 = L_508;
		float L_509;
		L_509 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_94), NULL);
		float L_510 = V_3;
		float L_511 = V_68;
		float L_512 = V_2;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_122), ((float)il2cpp_codegen_multiply(L_505, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_509, L_510)), L_511)), L_512)))), (0.0f), (0.0f), NULL);
		float L_513 = V_121;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_514 = __this->___m_CachedTextElement_75;
		NullCheck(L_514);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_515;
		L_515 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_514, NULL);
		NullCheck(L_515);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_516;
		L_516 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_515, NULL);
		V_94 = L_516;
		float L_517;
		L_517 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_94), NULL);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_518 = __this->___m_CachedTextElement_75;
		NullCheck(L_518);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_519;
		L_519 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_518, NULL);
		NullCheck(L_519);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_520;
		L_520 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_519, NULL);
		V_94 = L_520;
		float L_521;
		L_521 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_94), NULL);
		float L_522 = V_3;
		float L_523 = V_68;
		float L_524 = V_2;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_123), ((float)il2cpp_codegen_multiply(L_513, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_517, L_521)), L_522)), L_523)), L_524)))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_525 = V_70;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_526 = V_122;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_527;
		L_527 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_525, L_526, NULL);
		V_70 = L_527;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_528 = V_71;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_529 = V_123;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_530;
		L_530 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_528, L_529, NULL);
		V_71 = L_530;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_531 = V_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_532 = V_122;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_533;
		L_533 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_531, L_532, NULL);
		V_72 = L_533;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_534 = V_73;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_535 = V_123;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_536;
		L_536 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_534, L_535, NULL);
		V_73 = L_536;
	}

IL_1045:
	{
		bool L_537 = __this->___m_IsFxMatrixSet_38;
		V_124 = L_537;
		bool L_538 = V_124;
		if (!L_538)
		{
			goto IL_10df;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_539 = V_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_540 = V_71;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_541;
		L_541 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_539, L_540, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_542;
		L_542 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_541, (2.0f), NULL);
		V_125 = L_542;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_543 = (&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_544 = V_70;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_545 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_546;
		L_546 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_544, L_545, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_547;
		L_547 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_543, L_546, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_548 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_549;
		L_549 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_547, L_548, NULL);
		V_70 = L_549;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_550 = (&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_551 = V_71;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_552 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_553;
		L_553 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_551, L_552, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_554;
		L_554 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_550, L_553, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_555 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_556;
		L_556 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_554, L_555, NULL);
		V_71 = L_556;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_557 = (&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_558 = V_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_559 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_560;
		L_560 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_558, L_559, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_561;
		L_561 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_557, L_560, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_562 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_563;
		L_563 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_561, L_562, NULL);
		V_72 = L_563;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_564 = (&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_565 = V_73;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_566 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_567;
		L_567 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_565, L_566, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_568;
		L_568 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_564, L_567, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_569 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_570;
		L_570 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_568, L_569, NULL);
		V_73 = L_570;
	}

IL_10df:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_571 = ___textInfo1;
		NullCheck(L_571);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_572 = L_571->___textElementInfo_10;
		int32_t L_573 = __this->___m_CharacterCount_48;
		NullCheck(L_572);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_574 = V_71;
		((L_572)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_573)))->___bottomLeft_19 = L_574;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_575 = ___textInfo1;
		NullCheck(L_575);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_576 = L_575->___textElementInfo_10;
		int32_t L_577 = __this->___m_CharacterCount_48;
		NullCheck(L_576);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_578 = V_70;
		((L_576)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_577)))->___topLeft_18 = L_578;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_579 = ___textInfo1;
		NullCheck(L_579);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_580 = L_579->___textElementInfo_10;
		int32_t L_581 = __this->___m_CharacterCount_48;
		NullCheck(L_580);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_582 = V_72;
		((L_580)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_581)))->___topRight_20 = L_582;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_583 = ___textInfo1;
		NullCheck(L_583);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_584 = L_583->___textElementInfo_10;
		int32_t L_585 = __this->___m_CharacterCount_48;
		NullCheck(L_584);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_586 = V_73;
		((L_584)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_585)))->___bottomRight_21 = L_586;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_587 = ___textInfo1;
		NullCheck(L_587);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_588 = L_587->___textElementInfo_10;
		int32_t L_589 = __this->___m_CharacterCount_48;
		NullCheck(L_588);
		float L_590 = __this->___m_XAdvance_43;
		((L_588)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_589)))->___origin_22 = L_590;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_591 = ___textInfo1;
		NullCheck(L_591);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_592 = L_591->___textElementInfo_10;
		int32_t L_593 = __this->___m_CharacterCount_48;
		NullCheck(L_592);
		float L_594 = V_69;
		float L_595 = __this->___m_LineOffset_39;
		float L_596 = __this->___m_BaselineOffset_25;
		((L_592)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_593)))->___baseLine_24 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_594, L_595)), L_596));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_597 = ___textInfo1;
		NullCheck(L_597);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_598 = L_597->___textElementInfo_10;
		int32_t L_599 = __this->___m_CharacterCount_48;
		NullCheck(L_598);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_600 = V_72;
		float L_601 = L_600.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_602 = V_71;
		float L_603 = L_602.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_604 = V_70;
		float L_605 = L_604.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_606 = V_71;
		float L_607 = L_606.___y_3;
		((L_598)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_599)))->___aspectRatio_27 = ((float)(((float)il2cpp_codegen_subtract(L_601, L_603))/((float)il2cpp_codegen_subtract(L_605, L_607))));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_608 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_608);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_609;
		L_609 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_608, NULL);
		V_57 = L_609;
		float L_610;
		L_610 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD((&V_57), NULL);
		uint8_t L_611 = __this->___m_TextElementType_71;
		G_B99_0 = L_610;
		if ((((int32_t)L_611) == ((int32_t)1)))
		{
			G_B100_0 = L_610;
			goto IL_11eb;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_612 = ___textInfo1;
		NullCheck(L_612);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_613 = L_612->___textElementInfo_10;
		int32_t L_614 = __this->___m_CharacterCount_48;
		NullCheck(L_613);
		float L_615 = ((L_613)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_614)))->___scale_28;
		G_B101_0 = L_615;
		G_B101_1 = G_B99_0;
		goto IL_11ef;
	}

IL_11eb:
	{
		float L_616 = V_2;
		float L_617 = V_63;
		G_B101_0 = ((float)(L_616/L_617));
		G_B101_1 = G_B100_0;
	}

IL_11ef:
	{
		float L_618 = __this->___m_BaselineOffset_25;
		V_74 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(G_B101_1, G_B101_0)), L_618));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_619 = ___textInfo1;
		NullCheck(L_619);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_620 = L_619->___textElementInfo_10;
		int32_t L_621 = __this->___m_CharacterCount_48;
		NullCheck(L_620);
		float L_622 = V_74;
		float L_623 = __this->___m_LineOffset_39;
		((L_620)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_621)))->___ascender_23 = ((float)il2cpp_codegen_subtract(L_622, L_623));
		float L_624 = V_74;
		float L_625 = __this->___m_MaxLineAscender_53;
		G_B102_0 = __this;
		if ((((float)L_624) > ((float)L_625)))
		{
			G_B103_0 = __this;
			goto IL_122b;
		}
	}
	{
		float L_626 = __this->___m_MaxLineAscender_53;
		G_B104_0 = L_626;
		G_B104_1 = G_B102_0;
		goto IL_122d;
	}

IL_122b:
	{
		float L_627 = V_74;
		G_B104_0 = L_627;
		G_B104_1 = G_B103_0;
	}

IL_122d:
	{
		NullCheck(G_B104_1);
		G_B104_1->___m_MaxLineAscender_53 = G_B104_0;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_628 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_628);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_629;
		L_629 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_628, NULL);
		V_57 = L_629;
		float L_630;
		L_630 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3((&V_57), NULL);
		uint8_t L_631 = __this->___m_TextElementType_71;
		G_B105_0 = L_630;
		if ((((int32_t)L_631) == ((int32_t)1)))
		{
			G_B106_0 = L_630;
			goto IL_1267;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_632 = ___textInfo1;
		NullCheck(L_632);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_633 = L_632->___textElementInfo_10;
		int32_t L_634 = __this->___m_CharacterCount_48;
		NullCheck(L_633);
		float L_635 = ((L_633)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_634)))->___scale_28;
		G_B107_0 = L_635;
		G_B107_1 = G_B105_0;
		goto IL_126b;
	}

IL_1267:
	{
		float L_636 = V_2;
		float L_637 = V_63;
		G_B107_0 = ((float)(L_636/L_637));
		G_B107_1 = G_B106_0;
	}

IL_126b:
	{
		float L_638 = __this->___m_BaselineOffset_25;
		V_75 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(G_B107_1, G_B107_0)), L_638));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_639 = ___textInfo1;
		NullCheck(L_639);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_640 = L_639->___textElementInfo_10;
		int32_t L_641 = __this->___m_CharacterCount_48;
		NullCheck(L_640);
		float L_642 = V_75;
		float L_643 = __this->___m_LineOffset_39;
		float L_644 = ((float)il2cpp_codegen_subtract(L_642, L_643));
		V_58 = L_644;
		((L_640)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_641)))->___descender_25 = L_644;
		float L_645 = V_58;
		V_76 = L_645;
		float L_646 = V_75;
		float L_647 = __this->___m_MaxLineDescender_54;
		G_B108_0 = __this;
		if ((((float)L_646) < ((float)L_647)))
		{
			G_B109_0 = __this;
			goto IL_12ae;
		}
	}
	{
		float L_648 = __this->___m_MaxLineDescender_54;
		G_B110_0 = L_648;
		G_B110_1 = G_B108_0;
		goto IL_12b0;
	}

IL_12ae:
	{
		float L_649 = V_75;
		G_B110_0 = L_649;
		G_B110_1 = G_B109_0;
	}

IL_12b0:
	{
		NullCheck(G_B110_1);
		G_B110_1->___m_MaxLineDescender_54 = G_B110_0;
		int32_t L_650 = __this->___m_FontStyleInternal_19;
		if ((((int32_t)((int32_t)((int32_t)L_650&((int32_t)256)))) == ((int32_t)((int32_t)256))))
		{
			goto IL_12dd;
		}
	}
	{
		int32_t L_651 = __this->___m_FontStyleInternal_19;
		G_B113_0 = ((((int32_t)((int32_t)((int32_t)L_651&((int32_t)128)))) == ((int32_t)((int32_t)128)))? 1 : 0);
		goto IL_12de;
	}

IL_12dd:
	{
		G_B113_0 = 1;
	}

IL_12de:
	{
		V_126 = (bool)G_B113_0;
		bool L_652 = V_126;
		if (!L_652)
		{
			goto IL_136d;
		}
	}
	{
		float L_653 = V_74;
		float L_654 = __this->___m_BaselineOffset_25;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_655 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_655);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_656;
		L_656 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_655, NULL);
		V_57 = L_656;
		float L_657;
		L_657 = FaceInfo_get_subscriptSize_mF6264BFB215FDE6C94A45D2F8FC946ADFCDD2E31((&V_57), NULL);
		V_127 = ((float)(((float)il2cpp_codegen_subtract(L_653, L_654))/L_657));
		float L_658 = __this->___m_MaxLineAscender_53;
		V_74 = L_658;
		float L_659 = V_127;
		float L_660 = __this->___m_MaxLineAscender_53;
		G_B115_0 = __this;
		if ((((float)L_659) > ((float)L_660)))
		{
			G_B116_0 = __this;
			goto IL_1323;
		}
	}
	{
		float L_661 = __this->___m_MaxLineAscender_53;
		G_B117_0 = L_661;
		G_B117_1 = G_B115_0;
		goto IL_1325;
	}

IL_1323:
	{
		float L_662 = V_127;
		G_B117_0 = L_662;
		G_B117_1 = G_B116_0;
	}

IL_1325:
	{
		NullCheck(G_B117_1);
		G_B117_1->___m_MaxLineAscender_53 = G_B117_0;
		float L_663 = V_75;
		float L_664 = __this->___m_BaselineOffset_25;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_665 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_665);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_666;
		L_666 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_665, NULL);
		V_57 = L_666;
		float L_667;
		L_667 = FaceInfo_get_subscriptSize_mF6264BFB215FDE6C94A45D2F8FC946ADFCDD2E31((&V_57), NULL);
		V_128 = ((float)(((float)il2cpp_codegen_subtract(L_663, L_664))/L_667));
		float L_668 = __this->___m_MaxLineDescender_54;
		V_75 = L_668;
		float L_669 = V_128;
		float L_670 = __this->___m_MaxLineDescender_54;
		G_B118_0 = __this;
		if ((((float)L_669) < ((float)L_670)))
		{
			G_B119_0 = __this;
			goto IL_1365;
		}
	}
	{
		float L_671 = __this->___m_MaxLineDescender_54;
		G_B120_0 = L_671;
		G_B120_1 = G_B118_0;
		goto IL_1367;
	}

IL_1365:
	{
		float L_672 = V_128;
		G_B120_0 = L_672;
		G_B120_1 = G_B119_0;
	}

IL_1367:
	{
		NullCheck(G_B120_1);
		G_B120_1->___m_MaxLineDescender_54 = G_B120_0;
	}

IL_136d:
	{
		int32_t L_673 = __this->___m_LineNumber_55;
		if (!L_673)
		{
			goto IL_137d;
		}
	}
	{
		bool L_674 = __this->___m_IsNewPage_66;
		G_B124_0 = ((int32_t)(L_674));
		goto IL_137e;
	}

IL_137d:
	{
		G_B124_0 = 1;
	}

IL_137e:
	{
		V_129 = (bool)G_B124_0;
		bool L_675 = V_129;
		if (!L_675)
		{
			goto IL_13ca;
		}
	}
	{
		float L_676 = __this->___m_MaxAscender_64;
		float L_677 = V_74;
		G_B126_0 = __this;
		if ((((float)L_676) > ((float)L_677)))
		{
			G_B127_0 = __this;
			goto IL_1394;
		}
	}
	{
		float L_678 = V_74;
		G_B128_0 = L_678;
		G_B128_1 = G_B126_0;
		goto IL_139a;
	}

IL_1394:
	{
		float L_679 = __this->___m_MaxAscender_64;
		G_B128_0 = L_679;
		G_B128_1 = G_B127_0;
	}

IL_139a:
	{
		NullCheck(G_B128_1);
		G_B128_1->___m_MaxAscender_64 = G_B128_0;
		float L_680 = __this->___m_MaxCapHeight_63;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_681 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_681);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_682;
		L_682 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_681, NULL);
		V_57 = L_682;
		float L_683;
		L_683 = FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88((&V_57), NULL);
		float L_684 = V_2;
		float L_685 = V_63;
		float L_686;
		L_686 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_680, ((float)(((float)il2cpp_codegen_multiply(L_683, L_684))/L_685)), NULL);
		__this->___m_MaxCapHeight_63 = L_686;
	}

IL_13ca:
	{
		float L_687 = __this->___m_LineOffset_39;
		V_130 = (bool)((((float)L_687) == ((float)(0.0f)))? 1 : 0);
		bool L_688 = V_130;
		if (!L_688)
		{
			goto IL_13eb;
		}
	}
	{
		float L_689 = V_24;
		float L_690 = V_74;
		if ((((float)L_689) > ((float)L_690)))
		{
			goto IL_13e7;
		}
	}
	{
		float L_691 = V_74;
		G_B133_0 = L_691;
		goto IL_13e9;
	}

IL_13e7:
	{
		float L_692 = V_24;
		G_B133_0 = L_692;
	}

IL_13e9:
	{
		V_24 = G_B133_0;
	}

IL_13eb:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_693 = ___textInfo1;
		NullCheck(L_693);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_694 = L_693->___textElementInfo_10;
		int32_t L_695 = __this->___m_CharacterCount_48;
		NullCheck(L_694);
		((L_694)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_695)))->___isVisible_34 = (bool)0;
		int32_t L_696 = V_60;
		if ((((int32_t)L_696) == ((int32_t)((int32_t)9))))
		{
			goto IL_1438;
		}
	}
	{
		int32_t L_697 = V_60;
		if ((((int32_t)L_697) == ((int32_t)((int32_t)160))))
		{
			goto IL_1438;
		}
	}
	{
		int32_t L_698 = V_60;
		if ((((int32_t)L_698) == ((int32_t)((int32_t)8199))))
		{
			goto IL_1438;
		}
	}
	{
		int32_t L_699 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_700;
		L_700 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_699), NULL);
		if (L_700)
		{
			goto IL_142d;
		}
	}
	{
		int32_t L_701 = V_60;
		if ((!(((uint32_t)L_701) == ((uint32_t)((int32_t)8203)))))
		{
			goto IL_1438;
		}
	}

IL_142d:
	{
		uint8_t L_702 = __this->___m_TextElementType_71;
		G_B141_0 = ((((int32_t)L_702) == ((int32_t)2))? 1 : 0);
		goto IL_1439;
	}

IL_1438:
	{
		G_B141_0 = 1;
	}

IL_1439:
	{
		V_131 = (bool)G_B141_0;
		bool L_703 = V_131;
		if (!L_703)
		{
			goto IL_1ff9;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_704 = ___textInfo1;
		NullCheck(L_704);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_705 = L_704->___textElementInfo_10;
		int32_t L_706 = __this->___m_CharacterCount_48;
		NullCheck(L_705);
		((L_705)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_706)))->___isVisible_34 = (bool)1;
		float L_707 = __this->___m_Width_61;
		if ((!(((float)L_707) == ((float)(-1.0f)))))
		{
			goto IL_147f;
		}
	}
	{
		float L_708 = V_20;
		float L_709 = __this->___m_MarginLeft_59;
		float L_710 = __this->___m_MarginRight_60;
		G_B145_0 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_708, (9.99999975E-05f))), L_709)), L_710));
		goto IL_14a0;
	}

IL_147f:
	{
		float L_711 = V_20;
		float L_712 = __this->___m_MarginLeft_59;
		float L_713 = __this->___m_MarginRight_60;
		float L_714 = __this->___m_Width_61;
		float L_715;
		L_715 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_711, (9.99999975E-05f))), L_712)), L_713)), L_714, NULL);
		G_B145_0 = L_715;
	}

IL_14a0:
	{
		V_22 = G_B145_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_716 = ___textInfo1;
		NullCheck(L_716);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_717 = L_716->___lineInfo_13;
		int32_t L_718 = __this->___m_LineNumber_55;
		NullCheck(L_717);
		float L_719 = __this->___m_MarginLeft_59;
		((L_717)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_718)))->___marginLeft_17 = L_719;
		int32_t L_720 = __this->___m_LineJustification_23;
		if ((((int32_t)((int32_t)((int32_t)L_720&((int32_t)16)))) == ((int32_t)((int32_t)16))))
		{
			goto IL_14d8;
		}
	}
	{
		int32_t L_721 = __this->___m_LineJustification_23;
		G_B148_0 = ((((int32_t)((int32_t)((int32_t)L_721&8))) == ((int32_t)8))? 1 : 0);
		goto IL_14d9;
	}

IL_14d8:
	{
		G_B148_0 = 1;
	}

IL_14d9:
	{
		V_132 = (bool)G_B148_0;
		float L_722 = __this->___m_XAdvance_43;
		float L_723;
		L_723 = fabsf(L_722);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_724 = ___generationSettings0;
		NullCheck(L_724);
		bool L_725 = L_724->___isRightToLeft_24;
		G_B149_0 = L_723;
		if (!L_725)
		{
			G_B150_0 = L_723;
			goto IL_14f5;
		}
	}
	{
		G_B151_0 = (0.0f);
		G_B151_1 = G_B149_0;
		goto IL_150e;
	}

IL_14f5:
	{
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_726 = __this->___m_CachedTextElement_75;
		NullCheck(L_726);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_727;
		L_727 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_726, NULL);
		NullCheck(L_727);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_728;
		L_728 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_727, NULL);
		V_94 = L_728;
		float L_729;
		L_729 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_94), NULL);
		G_B151_0 = L_729;
		G_B151_1 = G_B150_0;
	}

IL_150e:
	{
		float L_730 = __this->___m_CharWidthAdjDelta_77;
		int32_t L_731 = V_60;
		G_B152_0 = ((float)il2cpp_codegen_multiply(G_B151_0, ((float)il2cpp_codegen_subtract((1.0f), L_730))));
		G_B152_1 = G_B151_1;
		if ((!(((uint32_t)L_731) == ((uint32_t)((int32_t)173)))))
		{
			G_B153_0 = ((float)il2cpp_codegen_multiply(G_B151_0, ((float)il2cpp_codegen_subtract((1.0f), L_730))));
			G_B153_1 = G_B151_1;
			goto IL_1528;
		}
	}
	{
		float L_732 = V_64;
		G_B154_0 = L_732;
		G_B154_1 = G_B152_0;
		G_B154_2 = G_B152_1;
		goto IL_1529;
	}

IL_1528:
	{
		float L_733 = V_2;
		G_B154_0 = L_733;
		G_B154_1 = G_B153_0;
		G_B154_2 = G_B153_1;
	}

IL_1529:
	{
		V_133 = ((float)il2cpp_codegen_add(G_B154_2, ((float)il2cpp_codegen_multiply(G_B154_1, G_B154_0))));
		float L_734 = V_133;
		float L_735 = V_22;
		bool L_736 = V_132;
		G_B155_0 = L_735;
		G_B155_1 = L_734;
		if (L_736)
		{
			G_B156_0 = L_735;
			G_B156_1 = L_734;
			goto IL_153c;
		}
	}
	{
		G_B157_0 = (1.0f);
		G_B157_1 = G_B155_0;
		G_B157_2 = G_B155_1;
		goto IL_1541;
	}

IL_153c:
	{
		G_B157_0 = (1.04999995f);
		G_B157_1 = G_B156_0;
		G_B157_2 = G_B156_1;
	}

IL_1541:
	{
		V_134 = (bool)((((float)G_B157_2) > ((float)((float)il2cpp_codegen_multiply(G_B157_1, G_B157_0))))? 1 : 0);
		bool L_737 = V_134;
		if (!L_737)
		{
			goto IL_1ebe;
		}
	}
	{
		int32_t L_738 = __this->___m_CharacterCount_48;
		V_18 = ((int32_t)il2cpp_codegen_subtract(L_738, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_739 = ___generationSettings0;
		NullCheck(L_739);
		bool L_740 = L_739->___wordWrap_12;
		if (!L_740)
		{
			goto IL_1573;
		}
	}
	{
		int32_t L_741 = __this->___m_CharacterCount_48;
		int32_t L_742 = __this->___m_FirstCharacterOfLine_49;
		G_B161_0 = ((((int32_t)((((int32_t)L_741) == ((int32_t)L_742))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_1574;
	}

IL_1573:
	{
		G_B161_0 = 0;
	}

IL_1574:
	{
		V_135 = (bool)G_B161_0;
		bool L_743 = V_135;
		if (!L_743)
		{
			goto IL_1bee;
		}
	}
	{
		int32_t L_744 = V_30;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_745 = (&__this->___m_SavedWordWrapState_68);
		int32_t L_746 = L_745->___previousWordBreak_0;
		bool L_747 = V_27;
		V_138 = (bool)((int32_t)(((((int32_t)L_744) == ((int32_t)L_746))? 1 : 0)|(int32_t)L_747));
		bool L_748 = V_138;
		if (!L_748)
		{
			goto IL_16b2;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_749 = ___generationSettings0;
		NullCheck(L_749);
		bool L_750 = L_749->___autoSize_19;
		if (!L_750)
		{
			goto IL_15b2;
		}
	}
	{
		float L_751 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_752 = ___generationSettings0;
		NullCheck(L_752);
		float L_753 = L_752->___fontSizeMin_20;
		G_B166_0 = ((((float)L_751) > ((float)L_753))? 1 : 0);
		goto IL_15b3;
	}

IL_15b2:
	{
		G_B166_0 = 0;
	}

IL_15b3:
	{
		V_139 = (bool)G_B166_0;
		bool L_754 = V_139;
		if (!L_754)
		{
			goto IL_1684;
		}
	}
	{
		float L_755 = __this->___m_CharWidthAdjDelta_77;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_756 = ___generationSettings0;
		NullCheck(L_756);
		float L_757 = L_756->___charWidthMaxAdj_44;
		V_140 = (bool)((((float)L_755) < ((float)((float)(L_757/(100.0f)))))? 1 : 0);
		bool L_758 = V_140;
		if (!L_758)
		{
			goto IL_15ff;
		}
	}
	{
		__this->___m_LoopCountA_70 = 0;
		float L_759 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_CharWidthAdjDelta_77 = ((float)il2cpp_codegen_add(L_759, (0.00999999978f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_760 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_761 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_760, L_761, NULL);
		goto IL_6c5c;
	}

IL_15ff:
	{
		float L_762 = __this->___m_FontSize_15;
		__this->___m_MaxFontSize_79 = L_762;
		float L_763 = __this->___m_FontSize_15;
		float L_764 = __this->___m_FontSize_15;
		float L_765 = __this->___m_MinFontSize_80;
		float L_766;
		L_766 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_764, L_765))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_subtract(L_763, L_766));
		float L_767 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_768 = ___generationSettings0;
		NullCheck(L_768);
		float L_769 = L_768->___fontSizeMin_20;
		float L_770;
		L_770 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_767, L_769, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_770, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_771 = __this->___m_LoopCountA_70;
		V_141 = (bool)((((int32_t)L_771) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_772 = V_141;
		if (!L_772)
		{
			goto IL_1676;
		}
	}
	{
		goto IL_6c5c;
	}

IL_1676:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_773 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_774 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_773, L_774, NULL);
		goto IL_6c5c;
	}

IL_1684:
	{
		bool L_775 = __this->___m_IsCharacterWrappingEnabled_81;
		V_142 = (bool)((((int32_t)L_775) == ((int32_t)0))? 1 : 0);
		bool L_776 = V_142;
		if (!L_776)
		{
			goto IL_16ae;
		}
	}
	{
		bool L_777 = V_28;
		V_143 = (bool)((((int32_t)L_777) == ((int32_t)0))? 1 : 0);
		bool L_778 = V_143;
		if (!L_778)
		{
			goto IL_16a4;
		}
	}
	{
		V_28 = (bool)1;
		goto IL_16ab;
	}

IL_16a4:
	{
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)1;
	}

IL_16ab:
	{
		goto IL_16b1;
	}

IL_16ae:
	{
		V_29 = (bool)1;
	}

IL_16b1:
	{
	}

IL_16b2:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_779 = (&__this->___m_SavedWordWrapState_68);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_780 = ___textInfo1;
		int32_t L_781;
		L_781 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_779, L_780, NULL);
		V_59 = L_781;
		int32_t L_782 = V_59;
		V_30 = L_782;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_783 = __this->___m_CharBuffer_4;
		int32_t L_784 = V_59;
		NullCheck(L_783);
		int32_t L_785 = L_784;
		int32_t L_786 = (L_783)->GetAt(static_cast<il2cpp_array_size_t>(L_785));
		V_144 = (bool)((((int32_t)L_786) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_787 = V_144;
		if (!L_787)
		{
			goto IL_16f5;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_788 = __this->___m_CharBuffer_4;
		int32_t L_789 = V_59;
		NullCheck(L_788);
		(L_788)->SetAt(static_cast<il2cpp_array_size_t>(L_789), (int32_t)((int32_t)45));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_790 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_791 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_790, L_791, NULL);
		goto IL_6c5c;
	}

IL_16f5:
	{
		int32_t L_792 = __this->___m_LineNumber_55;
		if ((((int32_t)L_792) <= ((int32_t)0)))
		{
			goto IL_1729;
		}
	}
	{
		float L_793 = __this->___m_MaxLineAscender_53;
		float L_794 = __this->___m_StartOfLineAscender_82;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_795;
		L_795 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(L_793, L_794, NULL);
		if (L_795)
		{
			goto IL_1729;
		}
	}
	{
		float L_796 = __this->___m_LineHeight_40;
		if ((!(((float)L_796) == ((float)(-32767.0f)))))
		{
			goto IL_1729;
		}
	}
	{
		bool L_797 = __this->___m_IsNewPage_66;
		G_B186_0 = ((((int32_t)L_797) == ((int32_t)0))? 1 : 0);
		goto IL_172a;
	}

IL_1729:
	{
		G_B186_0 = 0;
	}

IL_172a:
	{
		V_145 = (bool)G_B186_0;
		bool L_798 = V_145;
		if (!L_798)
		{
			goto IL_1787;
		}
	}
	{
		float L_799 = __this->___m_MaxLineAscender_53;
		float L_800 = __this->___m_StartOfLineAscender_82;
		V_146 = ((float)il2cpp_codegen_subtract(L_799, L_800));
		int32_t L_801 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_802 = __this->___m_CharacterCount_48;
		float L_803 = V_146;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_804 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_801, L_802, L_803, L_804, NULL);
		float L_805 = __this->___m_LineOffset_39;
		float L_806 = V_146;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_805, L_806));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_807 = (&__this->___m_SavedWordWrapState_68);
		float L_808 = __this->___m_LineOffset_39;
		L_807->___lineOffset_26 = L_808;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_809 = (&__this->___m_SavedWordWrapState_68);
		float L_810 = __this->___m_MaxLineAscender_53;
		L_809->___previousLineAscender_15 = L_810;
	}

IL_1787:
	{
		__this->___m_IsNewPage_66 = (bool)0;
		float L_811 = __this->___m_MaxLineAscender_53;
		float L_812 = __this->___m_LineOffset_39;
		V_136 = ((float)il2cpp_codegen_subtract(L_811, L_812));
		float L_813 = __this->___m_MaxLineDescender_54;
		float L_814 = __this->___m_LineOffset_39;
		V_137 = ((float)il2cpp_codegen_subtract(L_813, L_814));
		float L_815 = __this->___m_MaxDescender_65;
		float L_816 = V_137;
		G_B189_0 = __this;
		if ((((float)L_815) < ((float)L_816)))
		{
			G_B190_0 = __this;
			goto IL_17bb;
		}
	}
	{
		float L_817 = V_137;
		G_B191_0 = L_817;
		G_B191_1 = G_B189_0;
		goto IL_17c1;
	}

IL_17bb:
	{
		float L_818 = __this->___m_MaxDescender_65;
		G_B191_0 = L_818;
		G_B191_1 = G_B190_0;
	}

IL_17c1:
	{
		NullCheck(G_B191_1);
		G_B191_1->___m_MaxDescender_65 = G_B191_0;
		bool L_819 = V_26;
		V_147 = (bool)((((int32_t)L_819) == ((int32_t)0))? 1 : 0);
		bool L_820 = V_147;
		if (!L_820)
		{
			goto IL_17d9;
		}
	}
	{
		float L_821 = __this->___m_MaxDescender_65;
		V_25 = L_821;
	}

IL_17d9:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_822 = ___generationSettings0;
		NullCheck(L_822);
		bool L_823 = L_822->___useMaxVisibleDescender_36;
		if (!L_823)
		{
			goto IL_1805;
		}
	}
	{
		int32_t L_824 = __this->___m_CharacterCount_48;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_825 = ___generationSettings0;
		NullCheck(L_825);
		int32_t L_826 = L_825->___maxVisibleCharacters_32;
		if ((((int32_t)L_824) >= ((int32_t)L_826)))
		{
			goto IL_1802;
		}
	}
	{
		int32_t L_827 = __this->___m_LineNumber_55;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_828 = ___generationSettings0;
		NullCheck(L_828);
		int32_t L_829 = L_828->___maxVisibleLines_34;
		G_B197_0 = ((((int32_t)((((int32_t)L_827) < ((int32_t)L_829))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_1803;
	}

IL_1802:
	{
		G_B197_0 = 1;
	}

IL_1803:
	{
		G_B199_0 = G_B197_0;
		goto IL_1806;
	}

IL_1805:
	{
		G_B199_0 = 0;
	}

IL_1806:
	{
		V_148 = (bool)G_B199_0;
		bool L_830 = V_148;
		if (!L_830)
		{
			goto IL_180f;
		}
	}
	{
		V_26 = (bool)1;
	}

IL_180f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_831 = ___textInfo1;
		NullCheck(L_831);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_832 = L_831->___lineInfo_13;
		int32_t L_833 = __this->___m_LineNumber_55;
		NullCheck(L_832);
		int32_t L_834 = __this->___m_FirstCharacterOfLine_49;
		((L_832)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_833)))->___firstCharacterIndex_6 = L_834;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_835 = ___textInfo1;
		NullCheck(L_835);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_836 = L_835->___lineInfo_13;
		int32_t L_837 = __this->___m_LineNumber_55;
		NullCheck(L_836);
		int32_t L_838 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_839 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B202_0 = __this;
		G_B202_1 = ((L_836)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_837)));
		if ((((int32_t)L_838) > ((int32_t)L_839)))
		{
			G_B203_0 = __this;
			G_B203_1 = ((L_836)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_837)));
			goto IL_1853;
		}
	}
	{
		int32_t L_840 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B204_0 = L_840;
		G_B204_1 = G_B202_0;
		G_B204_2 = G_B202_1;
		goto IL_1859;
	}

IL_1853:
	{
		int32_t L_841 = __this->___m_FirstCharacterOfLine_49;
		G_B204_0 = L_841;
		G_B204_1 = G_B203_0;
		G_B204_2 = G_B203_1;
	}

IL_1859:
	{
		int32_t L_842 = G_B204_0;
		V_149 = L_842;
		NullCheck(G_B204_1);
		G_B204_1->___m_FirstVisibleCharacterOfLine_51 = L_842;
		int32_t L_843 = V_149;
		G_B204_2->___firstVisibleCharacterIndex_7 = L_843;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_844 = ___textInfo1;
		NullCheck(L_844);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_845 = L_844->___lineInfo_13;
		int32_t L_846 = __this->___m_LineNumber_55;
		NullCheck(L_845);
		int32_t L_847 = __this->___m_CharacterCount_48;
		G_B205_0 = __this;
		G_B205_1 = ((L_845)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_846)));
		if ((((int32_t)((int32_t)il2cpp_codegen_subtract(L_847, 1))) > ((int32_t)0)))
		{
			G_B206_0 = __this;
			G_B206_1 = ((L_845)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_846)));
			goto IL_1888;
		}
	}
	{
		G_B207_0 = 0;
		G_B207_1 = G_B205_0;
		G_B207_2 = G_B205_1;
		goto IL_1890;
	}

IL_1888:
	{
		int32_t L_848 = __this->___m_CharacterCount_48;
		G_B207_0 = ((int32_t)il2cpp_codegen_subtract(L_848, 1));
		G_B207_1 = G_B206_0;
		G_B207_2 = G_B206_1;
	}

IL_1890:
	{
		int32_t L_849 = G_B207_0;
		V_149 = L_849;
		NullCheck(G_B207_1);
		G_B207_1->___m_LastCharacterOfLine_50 = L_849;
		int32_t L_850 = V_149;
		G_B207_2->___lastCharacterIndex_8 = L_850;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_851 = ___textInfo1;
		NullCheck(L_851);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_852 = L_851->___lineInfo_13;
		int32_t L_853 = __this->___m_LineNumber_55;
		NullCheck(L_852);
		int32_t L_854 = __this->___m_LastVisibleCharacterOfLine_52;
		int32_t L_855 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B208_0 = __this;
		G_B208_1 = ((L_852)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_853)));
		if ((((int32_t)L_854) < ((int32_t)L_855)))
		{
			G_B209_0 = __this;
			G_B209_1 = ((L_852)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_853)));
			goto IL_18c7;
		}
	}
	{
		int32_t L_856 = __this->___m_LastVisibleCharacterOfLine_52;
		G_B210_0 = L_856;
		G_B210_1 = G_B208_0;
		G_B210_2 = G_B208_1;
		goto IL_18cd;
	}

IL_18c7:
	{
		int32_t L_857 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B210_0 = L_857;
		G_B210_1 = G_B209_0;
		G_B210_2 = G_B209_1;
	}

IL_18cd:
	{
		int32_t L_858 = G_B210_0;
		V_149 = L_858;
		NullCheck(G_B210_1);
		G_B210_1->___m_LastVisibleCharacterOfLine_52 = L_858;
		int32_t L_859 = V_149;
		G_B210_2->___lastVisibleCharacterIndex_9 = L_859;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_860 = ___textInfo1;
		NullCheck(L_860);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_861 = L_860->___lineInfo_13;
		int32_t L_862 = __this->___m_LineNumber_55;
		NullCheck(L_861);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_863 = ___textInfo1;
		NullCheck(L_863);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_864 = L_863->___lineInfo_13;
		int32_t L_865 = __this->___m_LineNumber_55;
		NullCheck(L_864);
		int32_t L_866 = ((L_864)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_865)))->___lastCharacterIndex_8;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_867 = ___textInfo1;
		NullCheck(L_867);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_868 = L_867->___lineInfo_13;
		int32_t L_869 = __this->___m_LineNumber_55;
		NullCheck(L_868);
		int32_t L_870 = ((L_868)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_869)))->___firstCharacterIndex_6;
		((L_861)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_862)))->___characterCount_1 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_866, L_870)), 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_871 = ___textInfo1;
		NullCheck(L_871);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_872 = L_871->___lineInfo_13;
		int32_t L_873 = __this->___m_LineNumber_55;
		NullCheck(L_872);
		int32_t L_874 = __this->___m_LineVisibleCharacterCount_56;
		((L_872)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_873)))->___visibleCharacterCount_2 = L_874;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_875 = ___textInfo1;
		NullCheck(L_875);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_876 = L_875->___lineInfo_13;
		int32_t L_877 = __this->___m_LineNumber_55;
		NullCheck(L_876);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_878 = (&((L_876)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_877)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_879 = ___textInfo1;
		NullCheck(L_879);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_880 = L_879->___textElementInfo_10;
		int32_t L_881 = __this->___m_FirstVisibleCharacterOfLine_51;
		NullCheck(L_880);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_882 = (&((L_880)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_881)))->___bottomLeft_19);
		float L_883 = L_882->___x_2;
		float L_884 = V_137;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_885;
		memset((&L_885), 0, sizeof(L_885));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_885), L_883, L_884, /*hidden argument*/NULL);
		L_878->___min_0 = L_885;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_886 = ___textInfo1;
		NullCheck(L_886);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_887 = L_886->___lineInfo_13;
		int32_t L_888 = __this->___m_LineNumber_55;
		NullCheck(L_887);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_889 = (&((L_887)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_888)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_890 = ___textInfo1;
		NullCheck(L_890);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_891 = L_890->___textElementInfo_10;
		int32_t L_892 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_891);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_893 = (&((L_891)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_892)))->___topRight_20);
		float L_894 = L_893->___x_2;
		float L_895 = V_136;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_896;
		memset((&L_896), 0, sizeof(L_896));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_896), L_894, L_895, /*hidden argument*/NULL);
		L_889->___max_1 = L_896;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_897 = ___textInfo1;
		NullCheck(L_897);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_898 = L_897->___lineInfo_13;
		int32_t L_899 = __this->___m_LineNumber_55;
		NullCheck(L_898);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_900 = ___textInfo1;
		NullCheck(L_900);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_901 = L_900->___lineInfo_13;
		int32_t L_902 = __this->___m_LineNumber_55;
		NullCheck(L_901);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_903 = (&((L_901)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_902)))->___lineExtents_20);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_904 = (&L_903->___max_1);
		float L_905 = L_904->___x_0;
		((L_898)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_899)))->___length_10 = L_905;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_906 = ___textInfo1;
		NullCheck(L_906);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_907 = L_906->___lineInfo_13;
		int32_t L_908 = __this->___m_LineNumber_55;
		NullCheck(L_907);
		float L_909 = V_22;
		((L_907)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_908)))->___width_16 = L_909;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_910 = ___textInfo1;
		NullCheck(L_910);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_911 = L_910->___lineInfo_13;
		int32_t L_912 = __this->___m_LineNumber_55;
		NullCheck(L_911);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_913 = ___textInfo1;
		NullCheck(L_913);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_914 = L_913->___textElementInfo_10;
		int32_t L_915 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_914);
		float L_916 = ((L_914)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_915)))->___xAdvance_26;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_917 = ___generationSettings0;
		NullCheck(L_917);
		float L_918 = L_917->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_919 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_919);
		float L_920;
		L_920 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_919, NULL);
		float L_921 = V_2;
		float L_922 = __this->___m_CSpacing_41;
		((L_911)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_912)))->___maxAdvance_15 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_916, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_918, L_920)), L_921)))), L_922));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_923 = ___textInfo1;
		NullCheck(L_923);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_924 = L_923->___lineInfo_13;
		int32_t L_925 = __this->___m_LineNumber_55;
		NullCheck(L_924);
		float L_926 = __this->___m_LineOffset_39;
		((L_924)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_925)))->___baseline_13 = ((float)il2cpp_codegen_subtract((0.0f), L_926));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_927 = ___textInfo1;
		NullCheck(L_927);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_928 = L_927->___lineInfo_13;
		int32_t L_929 = __this->___m_LineNumber_55;
		NullCheck(L_928);
		float L_930 = V_136;
		((L_928)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_929)))->___ascender_12 = L_930;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_931 = ___textInfo1;
		NullCheck(L_931);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_932 = L_931->___lineInfo_13;
		int32_t L_933 = __this->___m_LineNumber_55;
		NullCheck(L_932);
		float L_934 = V_137;
		((L_932)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_933)))->___descender_14 = L_934;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_935 = ___textInfo1;
		NullCheck(L_935);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_936 = L_935->___lineInfo_13;
		int32_t L_937 = __this->___m_LineNumber_55;
		NullCheck(L_936);
		float L_938 = V_136;
		float L_939 = V_137;
		float L_940 = V_14;
		float L_941 = V_1;
		((L_936)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_937)))->___lineHeight_11 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_938, L_939)), ((float)il2cpp_codegen_multiply(L_940, L_941))));
		int32_t L_942 = __this->___m_CharacterCount_48;
		__this->___m_FirstCharacterOfLine_49 = L_942;
		__this->___m_LineVisibleCharacterCount_56 = 0;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_943 = (&__this->___m_SavedLineState_69);
		int32_t L_944 = V_59;
		int32_t L_945 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_946 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_943, L_944, ((int32_t)il2cpp_codegen_subtract(L_945, 1)), L_946, NULL);
		int32_t L_947 = __this->___m_LineNumber_55;
		__this->___m_LineNumber_55 = ((int32_t)il2cpp_codegen_add(L_947, 1));
		V_15 = (bool)1;
		V_27 = (bool)1;
		int32_t L_948 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_949 = ___textInfo1;
		NullCheck(L_949);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_950 = L_949->___lineInfo_13;
		NullCheck(L_950);
		V_150 = (bool)((((int32_t)((((int32_t)L_948) < ((int32_t)((int32_t)(((RuntimeArray*)L_950)->max_length))))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_951 = V_150;
		if (!L_951)
		{
			goto IL_1b24;
		}
	}
	{
		int32_t L_952 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_953 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85(L_952, L_953, NULL);
	}

IL_1b24:
	{
		float L_954 = __this->___m_LineHeight_40;
		V_151 = (bool)((((float)L_954) == ((float)(-32767.0f)))? 1 : 0);
		bool L_955 = V_151;
		if (!L_955)
		{
			goto IL_1ba5;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_956 = ___textInfo1;
		NullCheck(L_956);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_957 = L_956->___textElementInfo_10;
		int32_t L_958 = __this->___m_CharacterCount_48;
		NullCheck(L_957);
		float L_959 = ((L_957)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_958)))->___ascender_23;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_960 = ___textInfo1;
		NullCheck(L_960);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_961 = L_960->___textElementInfo_10;
		int32_t L_962 = __this->___m_CharacterCount_48;
		NullCheck(L_961);
		float L_963 = ((L_961)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_962)))->___baseLine_24;
		V_152 = ((float)il2cpp_codegen_subtract(L_959, L_963));
		float L_964 = __this->___m_MaxLineDescender_54;
		float L_965 = V_152;
		float L_966 = V_14;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_967 = ___generationSettings0;
		NullCheck(L_967);
		float L_968 = L_967->___lineSpacing_29;
		float L_969 = __this->___m_LineSpacingDelta_83;
		float L_970 = V_1;
		V_77 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_964)), L_965)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_966, L_968)), L_969)), L_970))));
		float L_971 = __this->___m_LineOffset_39;
		float L_972 = V_77;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_971, L_972));
		float L_973 = V_152;
		__this->___m_StartOfLineAscender_82 = L_973;
		goto IL_1bc1;
	}

IL_1ba5:
	{
		float L_974 = __this->___m_LineOffset_39;
		float L_975 = __this->___m_LineHeight_40;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_976 = ___generationSettings0;
		NullCheck(L_976);
		float L_977 = L_976->___lineSpacing_29;
		float L_978 = V_1;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_974, ((float)il2cpp_codegen_add(L_975, ((float)il2cpp_codegen_multiply(L_977, L_978))))));
	}

IL_1bc1:
	{
		__this->___m_MaxLineAscender_53 = (-32767.0f);
		__this->___m_MaxLineDescender_54 = (32767.0f);
		float L_979 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add((0.0f), L_979));
		goto IL_329d;
	}

IL_1bee:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_980 = ___generationSettings0;
		NullCheck(L_980);
		bool L_981 = L_980->___autoSize_19;
		if (!L_981)
		{
			goto IL_1c06;
		}
	}
	{
		float L_982 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_983 = ___generationSettings0;
		NullCheck(L_983);
		float L_984 = L_983->___fontSizeMin_20;
		G_B219_0 = ((((float)L_982) > ((float)L_984))? 1 : 0);
		goto IL_1c07;
	}

IL_1c06:
	{
		G_B219_0 = 0;
	}

IL_1c07:
	{
		V_153 = (bool)G_B219_0;
		bool L_985 = V_153;
		if (!L_985)
		{
			goto IL_1cd8;
		}
	}
	{
		float L_986 = __this->___m_CharWidthAdjDelta_77;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_987 = ___generationSettings0;
		NullCheck(L_987);
		float L_988 = L_987->___charWidthMaxAdj_44;
		V_154 = (bool)((((float)L_986) < ((float)((float)(L_988/(100.0f)))))? 1 : 0);
		bool L_989 = V_154;
		if (!L_989)
		{
			goto IL_1c53;
		}
	}
	{
		__this->___m_LoopCountA_70 = 0;
		float L_990 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_CharWidthAdjDelta_77 = ((float)il2cpp_codegen_add(L_990, (0.00999999978f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_991 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_992 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_991, L_992, NULL);
		goto IL_6c5c;
	}

IL_1c53:
	{
		float L_993 = __this->___m_FontSize_15;
		__this->___m_MaxFontSize_79 = L_993;
		float L_994 = __this->___m_FontSize_15;
		float L_995 = __this->___m_FontSize_15;
		float L_996 = __this->___m_MinFontSize_80;
		float L_997;
		L_997 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_995, L_996))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_subtract(L_994, L_997));
		float L_998 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_999 = ___generationSettings0;
		NullCheck(L_999);
		float L_1000 = L_999->___fontSizeMin_20;
		float L_1001;
		L_1001 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_998, L_1000, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1001, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_1002 = __this->___m_LoopCountA_70;
		V_155 = (bool)((((int32_t)L_1002) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_1003 = V_155;
		if (!L_1003)
		{
			goto IL_1cca;
		}
	}
	{
		goto IL_6c5c;
	}

IL_1cca:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1004 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1005 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1004, L_1005, NULL);
		goto IL_6c5c;
	}

IL_1cd8:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1006 = ___generationSettings0;
		NullCheck(L_1006);
		int32_t L_1007 = L_1006->___overflowMode_11;
		V_157 = L_1007;
		int32_t L_1008 = V_157;
		V_156 = L_1008;
		int32_t L_1009 = V_156;
		switch (L_1009)
		{
			case 0:
			{
				goto IL_1d0c;
			}
			case 1:
			{
				goto IL_1d24;
			}
			case 2:
			{
				goto IL_1e5f;
			}
			case 3:
			{
				goto IL_1e8f;
			}
			case 4:
			{
				goto IL_1e77;
			}
			case 5:
			{
				goto IL_1ebd;
			}
			case 6:
			{
				goto IL_1ebb;
			}
		}
	}
	{
		goto IL_1ebd;
	}

IL_1d0c:
	{
		bool L_1010 = __this->___m_IsMaskingEnabled_84;
		V_158 = L_1010;
		bool L_1011 = V_158;
		if (!L_1011)
		{
			goto IL_1d1f;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_1d1f:
	{
		goto IL_1ebd;
	}

IL_1d24:
	{
		bool L_1012 = __this->___m_IsMaskingEnabled_84;
		V_159 = L_1012;
		bool L_1013 = V_159;
		if (!L_1013)
		{
			goto IL_1d37;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_1d37:
	{
		int32_t L_1014 = __this->___m_CharacterCount_48;
		V_160 = (bool)((((int32_t)L_1014) < ((int32_t)1))? 1 : 0);
		bool L_1015 = V_160;
		if (!L_1015)
		{
			goto IL_1d63;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1016 = ___textInfo1;
		NullCheck(L_1016);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1017 = L_1016->___textElementInfo_10;
		int32_t L_1018 = __this->___m_CharacterCount_48;
		NullCheck(L_1017);
		((L_1017)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1018)))->___isVisible_34 = (bool)0;
		goto IL_1ebd;
	}

IL_1d63:
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1019 = __this->___m_CharBuffer_4;
		int32_t L_1020 = V_59;
		NullCheck(L_1019);
		(L_1019)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1020, 1))), (int32_t)((int32_t)8230));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1021 = __this->___m_CharBuffer_4;
		int32_t L_1022 = V_59;
		NullCheck(L_1021);
		(L_1021)->SetAt(static_cast<il2cpp_array_size_t>(L_1022), (int32_t)0);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1023 = (&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1024 = L_1023->___character_0;
		V_161 = (bool)((!(((RuntimeObject*)(Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC*)L_1024) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_1025 = V_161;
		if (!L_1025)
		{
			goto IL_1e25;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1026 = ___textInfo1;
		NullCheck(L_1026);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1027 = L_1026->___textElementInfo_10;
		int32_t L_1028 = V_18;
		NullCheck(L_1027);
		((L_1027)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1028)))->___character_0 = ((int32_t)8230);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1029 = ___textInfo1;
		NullCheck(L_1029);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1030 = L_1029->___textElementInfo_10;
		int32_t L_1031 = V_18;
		NullCheck(L_1030);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1032 = (&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1033 = L_1032->___character_0;
		((L_1030)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1031)))->___textElement_3 = L_1033;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1030)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1031)))->___textElement_3), (void*)L_1033);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1034 = ___textInfo1;
		NullCheck(L_1034);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1035 = L_1034->___textElementInfo_10;
		int32_t L_1036 = V_18;
		NullCheck(L_1035);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1037 = __this->___m_MaterialReferences_85;
		NullCheck(L_1037);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1038 = ((L_1037)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___fontAsset_1;
		((L_1035)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1036)))->___fontAsset_4 = L_1038;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1035)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1036)))->___fontAsset_4), (void*)L_1038);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1039 = ___textInfo1;
		NullCheck(L_1039);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1040 = L_1039->___textElementInfo_10;
		int32_t L_1041 = V_18;
		NullCheck(L_1040);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1042 = __this->___m_MaterialReferences_85;
		NullCheck(L_1042);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_1043 = ((L_1042)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___material_3;
		((L_1040)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1041)))->___material_7 = L_1043;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1040)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1041)))->___material_7), (void*)L_1043);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1044 = ___textInfo1;
		NullCheck(L_1044);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1045 = L_1044->___textElementInfo_10;
		int32_t L_1046 = V_18;
		NullCheck(L_1045);
		((L_1045)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1046)))->___materialReferenceIndex_8 = 0;
		goto IL_1e47;
	}

IL_1e25:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1047 = ___generationSettings0;
		NullCheck(L_1047);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1048 = L_1047->___fontAsset_4;
		NullCheck(L_1048);
		String_t* L_1049;
		L_1049 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_1048, NULL);
		String_t* L_1050;
		L_1050 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(_stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D, L_1049, _stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9(L_1050, NULL);
	}

IL_1e47:
	{
		int32_t L_1051 = V_18;
		__this->___m_TotalCharacterCount_13 = ((int32_t)il2cpp_codegen_add(L_1051, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1052 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1053 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1052, L_1053, NULL);
		goto IL_6c5c;
	}

IL_1e5f:
	{
		bool L_1054 = __this->___m_IsMaskingEnabled_84;
		V_162 = (bool)((((int32_t)L_1054) == ((int32_t)0))? 1 : 0);
		bool L_1055 = V_162;
		if (!L_1055)
		{
			goto IL_1e75;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_1e75:
	{
		goto IL_1ebd;
	}

IL_1e77:
	{
		bool L_1056 = __this->___m_IsMaskingEnabled_84;
		V_163 = (bool)((((int32_t)L_1056) == ((int32_t)0))? 1 : 0);
		bool L_1057 = V_163;
		if (!L_1057)
		{
			goto IL_1e8d;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_1e8d:
	{
		goto IL_1ebd;
	}

IL_1e8f:
	{
		bool L_1058 = __this->___m_IsMaskingEnabled_84;
		V_164 = L_1058;
		bool L_1059 = V_164;
		if (!L_1059)
		{
			goto IL_1ea2;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_1ea2:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1060 = ___textInfo1;
		NullCheck(L_1060);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1061 = L_1060->___textElementInfo_10;
		int32_t L_1062 = __this->___m_CharacterCount_48;
		NullCheck(L_1061);
		((L_1061)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1062)))->___isVisible_34 = (bool)0;
		goto IL_1ebd;
	}

IL_1ebb:
	{
		goto IL_1ebd;
	}

IL_1ebd:
	{
	}

IL_1ebe:
	{
		int32_t L_1063 = V_60;
		if ((((int32_t)L_1063) == ((int32_t)((int32_t)9))))
		{
			goto IL_1ed8;
		}
	}
	{
		int32_t L_1064 = V_60;
		if ((((int32_t)L_1064) == ((int32_t)((int32_t)160))))
		{
			goto IL_1ed8;
		}
	}
	{
		int32_t L_1065 = V_60;
		G_B253_0 = ((((int32_t)L_1065) == ((int32_t)((int32_t)8199)))? 1 : 0);
		goto IL_1ed9;
	}

IL_1ed8:
	{
		G_B253_0 = 1;
	}

IL_1ed9:
	{
		V_165 = (bool)G_B253_0;
		bool L_1066 = V_165;
		if (!L_1066)
		{
			goto IL_1f34;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1067 = ___textInfo1;
		NullCheck(L_1067);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1068 = L_1067->___textElementInfo_10;
		int32_t L_1069 = __this->___m_CharacterCount_48;
		NullCheck(L_1068);
		((L_1068)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1069)))->___isVisible_34 = (bool)0;
		int32_t L_1070 = __this->___m_CharacterCount_48;
		__this->___m_LastVisibleCharacterOfLine_52 = L_1070;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1071 = ___textInfo1;
		NullCheck(L_1071);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1072 = L_1071->___lineInfo_13;
		int32_t L_1073 = __this->___m_LineNumber_55;
		NullCheck(L_1072);
		int32_t* L_1074 = (&((L_1072)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1073)))->___spaceCount_3);
		int32_t* L_1075 = L_1074;
		int32_t L_1076 = *((int32_t*)L_1075);
		*((int32_t*)L_1075) = (int32_t)((int32_t)il2cpp_codegen_add(L_1076, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1077 = ___textInfo1;
		V_166 = L_1077;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1078 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1079 = V_166;
		NullCheck(L_1079);
		int32_t L_1080 = L_1079->___spaceCount_4;
		NullCheck(L_1078);
		L_1078->___spaceCount_4 = ((int32_t)il2cpp_codegen_add(L_1080, 1));
		goto IL_1f91;
	}

IL_1f34:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1081 = ___generationSettings0;
		NullCheck(L_1081);
		bool L_1082 = L_1081->___overrideRichTextColors_17;
		V_168 = L_1082;
		bool L_1083 = V_168;
		if (!L_1083)
		{
			goto IL_1f4b;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1084 = __this->___m_FontColor32_27;
		V_167 = L_1084;
		goto IL_1f53;
	}

IL_1f4b:
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1085 = __this->___m_HtmlColor_28;
		V_167 = L_1085;
	}

IL_1f53:
	{
		uint8_t L_1086 = __this->___m_TextElementType_71;
		V_169 = (bool)((((int32_t)L_1086) == ((int32_t)1))? 1 : 0);
		bool L_1087 = V_169;
		if (!L_1087)
		{
			goto IL_1f74;
		}
	}
	{
		float L_1088 = V_3;
		float L_1089 = V_68;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1090 = V_167;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1091 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1092 = ___textInfo1;
		TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09(__this, L_1088, L_1089, L_1090, L_1091, L_1092, NULL);
		goto IL_1f90;
	}

IL_1f74:
	{
		uint8_t L_1093 = __this->___m_TextElementType_71;
		V_170 = (bool)((((int32_t)L_1093) == ((int32_t)2))? 1 : 0);
		bool L_1094 = V_170;
		if (!L_1094)
		{
			goto IL_1f90;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1095 = V_167;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1096 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1097 = ___textInfo1;
		TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5(__this, L_1095, L_1096, L_1097, NULL);
	}

IL_1f90:
	{
	}

IL_1f91:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1098 = ___textInfo1;
		NullCheck(L_1098);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1099 = L_1098->___textElementInfo_10;
		int32_t L_1100 = __this->___m_CharacterCount_48;
		NullCheck(L_1099);
		bool L_1101 = ((L_1099)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1100)))->___isVisible_34;
		if (!L_1101)
		{
			goto IL_1fb7;
		}
	}
	{
		int32_t L_1102 = V_60;
		G_B266_0 = ((((int32_t)((((int32_t)L_1102) == ((int32_t)((int32_t)173)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_1fb8;
	}

IL_1fb7:
	{
		G_B266_0 = 0;
	}

IL_1fb8:
	{
		V_171 = (bool)G_B266_0;
		bool L_1103 = V_171;
		if (!L_1103)
		{
			goto IL_1ff3;
		}
	}
	{
		bool L_1104 = V_15;
		V_172 = L_1104;
		bool L_1105 = V_172;
		if (!L_1105)
		{
			goto IL_1fd8;
		}
	}
	{
		V_15 = (bool)0;
		int32_t L_1106 = __this->___m_CharacterCount_48;
		__this->___m_FirstVisibleCharacterOfLine_51 = L_1106;
	}

IL_1fd8:
	{
		int32_t L_1107 = __this->___m_LineVisibleCharacterCount_56;
		__this->___m_LineVisibleCharacterCount_56 = ((int32_t)il2cpp_codegen_add(L_1107, 1));
		int32_t L_1108 = __this->___m_CharacterCount_48;
		__this->___m_LastVisibleCharacterOfLine_52 = L_1108;
	}

IL_1ff3:
	{
		goto IL_2088;
	}

IL_1ff9:
	{
		int32_t L_1109 = V_60;
		if ((((int32_t)L_1109) == ((int32_t)((int32_t)10))))
		{
			goto IL_200a;
		}
	}
	{
		int32_t L_1110 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1111;
		L_1111 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(((int32_t)(uint16_t)L_1110), NULL);
		if (!L_1111)
		{
			goto IL_202a;
		}
	}

IL_200a:
	{
		int32_t L_1112 = V_60;
		if ((((int32_t)L_1112) == ((int32_t)((int32_t)173))))
		{
			goto IL_202a;
		}
	}
	{
		int32_t L_1113 = V_60;
		if ((((int32_t)L_1113) == ((int32_t)((int32_t)8203))))
		{
			goto IL_202a;
		}
	}
	{
		int32_t L_1114 = V_60;
		G_B277_0 = ((((int32_t)((((int32_t)L_1114) == ((int32_t)((int32_t)8288)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_202b;
	}

IL_202a:
	{
		G_B277_0 = 0;
	}

IL_202b:
	{
		V_173 = (bool)G_B277_0;
		bool L_1115 = V_173;
		if (!L_1115)
		{
			goto IL_2087;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1116 = ___textInfo1;
		NullCheck(L_1116);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1117 = L_1116->___lineInfo_13;
		int32_t L_1118 = __this->___m_LineNumber_55;
		NullCheck(L_1117);
		int32_t* L_1119 = (&((L_1117)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1118)))->___spaceCount_3);
		int32_t* L_1120 = L_1119;
		int32_t L_1121 = *((int32_t*)L_1120);
		*((int32_t*)L_1120) = (int32_t)((int32_t)il2cpp_codegen_add(L_1121, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1122 = ___textInfo1;
		V_166 = L_1122;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1123 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1124 = V_166;
		NullCheck(L_1124);
		int32_t L_1125 = L_1124->___spaceCount_4;
		NullCheck(L_1123);
		L_1123->___spaceCount_4 = ((int32_t)il2cpp_codegen_add(L_1125, 1));
		int32_t L_1126 = V_60;
		V_174 = (bool)((((int32_t)L_1126) == ((int32_t)((int32_t)160)))? 1 : 0);
		bool L_1127 = V_174;
		if (!L_1127)
		{
			goto IL_2086;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1128 = ___textInfo1;
		NullCheck(L_1128);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1129 = L_1128->___lineInfo_13;
		int32_t L_1130 = __this->___m_LineNumber_55;
		NullCheck(L_1129);
		((L_1129)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1130)))->___controlCharacterCount_0 = 1;
	}

IL_2086:
	{
	}

IL_2087:
	{
	}

IL_2088:
	{
		int32_t L_1131 = __this->___m_LineNumber_55;
		if ((((int32_t)L_1131) <= ((int32_t)0)))
		{
			goto IL_20bc;
		}
	}
	{
		float L_1132 = __this->___m_MaxLineAscender_53;
		float L_1133 = __this->___m_StartOfLineAscender_82;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_1134;
		L_1134 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(L_1132, L_1133, NULL);
		if (L_1134)
		{
			goto IL_20bc;
		}
	}
	{
		float L_1135 = __this->___m_LineHeight_40;
		if ((!(((float)L_1135) == ((float)(-32767.0f)))))
		{
			goto IL_20bc;
		}
	}
	{
		bool L_1136 = __this->___m_IsNewPage_66;
		G_B287_0 = ((((int32_t)L_1136) == ((int32_t)0))? 1 : 0);
		goto IL_20bd;
	}

IL_20bc:
	{
		G_B287_0 = 0;
	}

IL_20bd:
	{
		V_175 = (bool)G_B287_0;
		bool L_1137 = V_175;
		if (!L_1137)
		{
			goto IL_2130;
		}
	}
	{
		float L_1138 = __this->___m_MaxLineAscender_53;
		float L_1139 = __this->___m_StartOfLineAscender_82;
		V_176 = ((float)il2cpp_codegen_subtract(L_1138, L_1139));
		int32_t L_1140 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_1141 = __this->___m_CharacterCount_48;
		float L_1142 = V_176;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1143 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_1140, L_1141, L_1142, L_1143, NULL);
		float L_1144 = V_76;
		float L_1145 = V_176;
		V_76 = ((float)il2cpp_codegen_subtract(L_1144, L_1145));
		float L_1146 = __this->___m_LineOffset_39;
		float L_1147 = V_176;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1146, L_1147));
		float L_1148 = __this->___m_StartOfLineAscender_82;
		float L_1149 = V_176;
		__this->___m_StartOfLineAscender_82 = ((float)il2cpp_codegen_add(L_1148, L_1149));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1150 = (&__this->___m_SavedWordWrapState_68);
		float L_1151 = __this->___m_LineOffset_39;
		L_1150->___lineOffset_26 = L_1151;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1152 = (&__this->___m_SavedWordWrapState_68);
		float L_1153 = __this->___m_StartOfLineAscender_82;
		L_1152->___previousLineAscender_15 = L_1153;
	}

IL_2130:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1154 = ___textInfo1;
		NullCheck(L_1154);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1155 = L_1154->___textElementInfo_10;
		int32_t L_1156 = __this->___m_CharacterCount_48;
		NullCheck(L_1155);
		int32_t L_1157 = __this->___m_LineNumber_55;
		((L_1155)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1156)))->___lineNumber_11 = L_1157;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1158 = ___textInfo1;
		NullCheck(L_1158);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1159 = L_1158->___textElementInfo_10;
		int32_t L_1160 = __this->___m_CharacterCount_48;
		NullCheck(L_1159);
		int32_t L_1161 = __this->___m_PageNumber_58;
		((L_1159)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1160)))->___pageNumber_12 = L_1161;
		int32_t L_1162 = V_60;
		if ((((int32_t)L_1162) == ((int32_t)((int32_t)10))))
		{
			goto IL_217d;
		}
	}
	{
		int32_t L_1163 = V_60;
		if ((((int32_t)L_1163) == ((int32_t)((int32_t)13))))
		{
			goto IL_217d;
		}
	}
	{
		int32_t L_1164 = V_60;
		if ((!(((uint32_t)L_1164) == ((uint32_t)((int32_t)8230)))))
		{
			goto IL_2198;
		}
	}

IL_217d:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1165 = ___textInfo1;
		NullCheck(L_1165);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1166 = L_1165->___lineInfo_13;
		int32_t L_1167 = __this->___m_LineNumber_55;
		NullCheck(L_1166);
		int32_t L_1168 = ((L_1166)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1167)))->___characterCount_1;
		G_B294_0 = ((((int32_t)L_1168) == ((int32_t)1))? 1 : 0);
		goto IL_2199;
	}

IL_2198:
	{
		G_B294_0 = 1;
	}

IL_2199:
	{
		V_177 = (bool)G_B294_0;
		bool L_1169 = V_177;
		if (!L_1169)
		{
			goto IL_21bb;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1170 = ___textInfo1;
		NullCheck(L_1170);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1171 = L_1170->___lineInfo_13;
		int32_t L_1172 = __this->___m_LineNumber_55;
		NullCheck(L_1171);
		int32_t L_1173 = __this->___m_LineJustification_23;
		((L_1171)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1172)))->___alignment_19 = L_1173;
	}

IL_21bb:
	{
		float L_1174 = __this->___m_MaxAscender_64;
		float L_1175 = V_76;
		float L_1176 = V_21;
		V_178 = (bool)((((float)((float)il2cpp_codegen_subtract(L_1174, L_1175))) > ((float)((float)il2cpp_codegen_add(L_1176, (9.99999975E-05f)))))? 1 : 0);
		bool L_1177 = V_178;
		if (!L_1177)
		{
			goto IL_261d;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1178 = ___generationSettings0;
		NullCheck(L_1178);
		bool L_1179 = L_1178->___autoSize_19;
		if (!L_1179)
		{
			goto IL_21f9;
		}
	}
	{
		float L_1180 = __this->___m_LineSpacingDelta_83;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1181 = ___generationSettings0;
		NullCheck(L_1181);
		float L_1182 = L_1181->___lineSpacingMax_31;
		if ((!(((float)L_1180) > ((float)L_1182))))
		{
			goto IL_21f9;
		}
	}
	{
		int32_t L_1183 = __this->___m_LineNumber_55;
		G_B301_0 = ((((int32_t)L_1183) > ((int32_t)0))? 1 : 0);
		goto IL_21fa;
	}

IL_21f9:
	{
		G_B301_0 = 0;
	}

IL_21fa:
	{
		V_179 = (bool)G_B301_0;
		bool L_1184 = V_179;
		if (!L_1184)
		{
			goto IL_2228;
		}
	}
	{
		__this->___m_LoopCountA_70 = 0;
		float L_1185 = __this->___m_LineSpacingDelta_83;
		__this->___m_LineSpacingDelta_83 = ((float)il2cpp_codegen_subtract(L_1185, (1.0f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1186 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1187 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1186, L_1187, NULL);
		goto IL_6c5c;
	}

IL_2228:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1188 = ___generationSettings0;
		NullCheck(L_1188);
		bool L_1189 = L_1188->___autoSize_19;
		if (!L_1189)
		{
			goto IL_2240;
		}
	}
	{
		float L_1190 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1191 = ___generationSettings0;
		NullCheck(L_1191);
		float L_1192 = L_1191->___fontSizeMin_20;
		G_B306_0 = ((((float)L_1190) > ((float)L_1192))? 1 : 0);
		goto IL_2241;
	}

IL_2240:
	{
		G_B306_0 = 0;
	}

IL_2241:
	{
		V_180 = (bool)G_B306_0;
		bool L_1193 = V_180;
		if (!L_1193)
		{
			goto IL_22d0;
		}
	}
	{
		float L_1194 = __this->___m_FontSize_15;
		__this->___m_MaxFontSize_79 = L_1194;
		float L_1195 = __this->___m_FontSize_15;
		float L_1196 = __this->___m_FontSize_15;
		float L_1197 = __this->___m_MinFontSize_80;
		float L_1198;
		L_1198 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1196, L_1197))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_subtract(L_1195, L_1198));
		float L_1199 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1200 = ___generationSettings0;
		NullCheck(L_1200);
		float L_1201 = L_1200->___fontSizeMin_20;
		float L_1202;
		L_1202 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1199, L_1201, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1202, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_1203 = __this->___m_LoopCountA_70;
		V_181 = (bool)((((int32_t)L_1203) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_1204 = V_181;
		if (!L_1204)
		{
			goto IL_22c2;
		}
	}
	{
		goto IL_6c5c;
	}

IL_22c2:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1205 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1206 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1205, L_1206, NULL);
		goto IL_6c5c;
	}

IL_22d0:
	{
		int32_t L_1207 = __this->___m_FirstOverflowCharacterIndex_57;
		V_182 = (bool)((((int32_t)L_1207) == ((int32_t)(-1)))? 1 : 0);
		bool L_1208 = V_182;
		if (!L_1208)
		{
			goto IL_22eb;
		}
	}
	{
		int32_t L_1209 = __this->___m_CharacterCount_48;
		__this->___m_FirstOverflowCharacterIndex_57 = L_1209;
	}

IL_22eb:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1210 = ___generationSettings0;
		NullCheck(L_1210);
		int32_t L_1211 = L_1210->___overflowMode_11;
		V_184 = L_1211;
		int32_t L_1212 = V_184;
		V_183 = L_1212;
		int32_t L_1213 = V_183;
		switch (L_1213)
		{
			case 0:
			{
				goto IL_231f;
			}
			case 1:
			{
				goto IL_2337;
			}
			case 2:
			{
				goto IL_247f;
			}
			case 3:
			{
				goto IL_24b5;
			}
			case 4:
			{
				goto IL_249a;
			}
			case 5:
			{
				goto IL_251a;
			}
			case 6:
			{
				goto IL_25da;
			}
		}
	}
	{
		goto IL_261c;
	}

IL_231f:
	{
		bool L_1214 = __this->___m_IsMaskingEnabled_84;
		V_185 = L_1214;
		bool L_1215 = V_185;
		if (!L_1215)
		{
			goto IL_2332;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_2332:
	{
		goto IL_261c;
	}

IL_2337:
	{
		bool L_1216 = __this->___m_IsMaskingEnabled_84;
		V_186 = L_1216;
		bool L_1217 = V_186;
		if (!L_1217)
		{
			goto IL_234a;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_234a:
	{
		int32_t L_1218 = __this->___m_LineNumber_55;
		V_187 = (bool)((((int32_t)L_1218) > ((int32_t)0))? 1 : 0);
		bool L_1219 = V_187;
		if (!L_1219)
		{
			goto IL_2479;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1220 = __this->___m_CharBuffer_4;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1221 = ___textInfo1;
		NullCheck(L_1221);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1222 = L_1221->___textElementInfo_10;
		int32_t L_1223 = V_18;
		NullCheck(L_1222);
		int32_t L_1224 = ((L_1222)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1223)))->___index_1;
		NullCheck(L_1220);
		(L_1220)->SetAt(static_cast<il2cpp_array_size_t>(L_1224), (int32_t)((int32_t)8230));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1225 = __this->___m_CharBuffer_4;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1226 = ___textInfo1;
		NullCheck(L_1226);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1227 = L_1226->___textElementInfo_10;
		int32_t L_1228 = V_18;
		NullCheck(L_1227);
		int32_t L_1229 = ((L_1227)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1228)))->___index_1;
		NullCheck(L_1225);
		(L_1225)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_1229, 1))), (int32_t)0);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1230 = (&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1231 = L_1230->___character_0;
		V_188 = (bool)((!(((RuntimeObject*)(Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC*)L_1231) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_1232 = V_188;
		if (!L_1232)
		{
			goto IL_243f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1233 = ___textInfo1;
		NullCheck(L_1233);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1234 = L_1233->___textElementInfo_10;
		int32_t L_1235 = V_18;
		NullCheck(L_1234);
		((L_1234)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1235)))->___character_0 = ((int32_t)8230);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1236 = ___textInfo1;
		NullCheck(L_1236);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1237 = L_1236->___textElementInfo_10;
		int32_t L_1238 = V_18;
		NullCheck(L_1237);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1239 = (&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1240 = L_1239->___character_0;
		((L_1237)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1238)))->___textElement_3 = L_1240;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1237)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1238)))->___textElement_3), (void*)L_1240);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1241 = ___textInfo1;
		NullCheck(L_1241);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1242 = L_1241->___textElementInfo_10;
		int32_t L_1243 = V_18;
		NullCheck(L_1242);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1244 = __this->___m_MaterialReferences_85;
		NullCheck(L_1244);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1245 = ((L_1244)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___fontAsset_1;
		((L_1242)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1243)))->___fontAsset_4 = L_1245;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1242)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1243)))->___fontAsset_4), (void*)L_1245);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1246 = ___textInfo1;
		NullCheck(L_1246);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1247 = L_1246->___textElementInfo_10;
		int32_t L_1248 = V_18;
		NullCheck(L_1247);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1249 = __this->___m_MaterialReferences_85;
		NullCheck(L_1249);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_1250 = ((L_1249)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___material_3;
		((L_1247)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1248)))->___material_7 = L_1250;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1247)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1248)))->___material_7), (void*)L_1250);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1251 = ___textInfo1;
		NullCheck(L_1251);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1252 = L_1251->___textElementInfo_10;
		int32_t L_1253 = V_18;
		NullCheck(L_1252);
		((L_1252)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1253)))->___materialReferenceIndex_8 = 0;
		goto IL_2461;
	}

IL_243f:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1254 = ___generationSettings0;
		NullCheck(L_1254);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1255 = L_1254->___fontAsset_4;
		NullCheck(L_1255);
		String_t* L_1256;
		L_1256 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_1255, NULL);
		String_t* L_1257;
		L_1257 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(_stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D, L_1256, _stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9(L_1257, NULL);
	}

IL_2461:
	{
		int32_t L_1258 = V_18;
		__this->___m_TotalCharacterCount_13 = ((int32_t)il2cpp_codegen_add(L_1258, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1259 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1260 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1259, L_1260, NULL);
		goto IL_6c5c;
	}

IL_2479:
	{
		goto IL_261c;
	}

IL_247f:
	{
		bool L_1261 = __this->___m_IsMaskingEnabled_84;
		V_189 = (bool)((((int32_t)L_1261) == ((int32_t)0))? 1 : 0);
		bool L_1262 = V_189;
		if (!L_1262)
		{
			goto IL_2495;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_2495:
	{
		goto IL_261c;
	}

IL_249a:
	{
		bool L_1263 = __this->___m_IsMaskingEnabled_84;
		V_190 = (bool)((((int32_t)L_1263) == ((int32_t)0))? 1 : 0);
		bool L_1264 = V_190;
		if (!L_1264)
		{
			goto IL_24b0;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_24b0:
	{
		goto IL_261c;
	}

IL_24b5:
	{
		bool L_1265 = __this->___m_IsMaskingEnabled_84;
		V_191 = L_1265;
		bool L_1266 = V_191;
		if (!L_1266)
		{
			goto IL_24c8;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_24c8:
	{
		int32_t L_1267 = __this->___m_LineNumber_55;
		V_192 = (bool)((((int32_t)L_1267) > ((int32_t)0))? 1 : 0);
		bool L_1268 = V_192;
		if (!L_1268)
		{
			goto IL_250c;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1269 = __this->___m_CharBuffer_4;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1270 = ___textInfo1;
		NullCheck(L_1270);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1271 = L_1270->___textElementInfo_10;
		int32_t L_1272 = V_18;
		NullCheck(L_1271);
		int32_t L_1273 = ((L_1271)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1272)))->___index_1;
		NullCheck(L_1269);
		(L_1269)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_1273, 1))), (int32_t)0);
		int32_t L_1274 = V_18;
		__this->___m_TotalCharacterCount_13 = ((int32_t)il2cpp_codegen_add(L_1274, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1275 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1276 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1275, L_1276, NULL);
		goto IL_6c5c;
	}

IL_250c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1277 = ___textInfo1;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)0, L_1277, NULL);
		goto IL_6c5c;
	}

IL_251a:
	{
		bool L_1278 = __this->___m_IsMaskingEnabled_84;
		V_193 = L_1278;
		bool L_1279 = V_193;
		if (!L_1279)
		{
			goto IL_252d;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_252d:
	{
		int32_t L_1280 = V_60;
		if ((((int32_t)L_1280) == ((int32_t)((int32_t)13))))
		{
			goto IL_253b;
		}
	}
	{
		int32_t L_1281 = V_60;
		G_B341_0 = ((((int32_t)L_1281) == ((int32_t)((int32_t)10)))? 1 : 0);
		goto IL_253c;
	}

IL_253b:
	{
		G_B341_0 = 1;
	}

IL_253c:
	{
		V_194 = (bool)G_B341_0;
		bool L_1282 = V_194;
		if (!L_1282)
		{
			goto IL_2547;
		}
	}
	{
		goto IL_261c;
	}

IL_2547:
	{
		int32_t L_1283 = V_59;
		V_195 = (bool)((((int32_t)L_1283) == ((int32_t)0))? 1 : 0);
		bool L_1284 = V_195;
		if (!L_1284)
		{
			goto IL_2558;
		}
	}
	{
		goto IL_6c5c;
	}

IL_2558:
	{
		int32_t L_1285 = V_17;
		int32_t L_1286 = V_59;
		V_196 = (bool)((((int32_t)L_1285) == ((int32_t)L_1286))? 1 : 0);
		bool L_1287 = V_196;
		if (!L_1287)
		{
			goto IL_2570;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1288 = __this->___m_CharBuffer_4;
		int32_t L_1289 = V_59;
		NullCheck(L_1288);
		(L_1288)->SetAt(static_cast<il2cpp_array_size_t>(L_1289), (int32_t)0);
	}

IL_2570:
	{
		int32_t L_1290 = V_59;
		V_17 = L_1290;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1291 = (&__this->___m_SavedLineState_69);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1292 = ___textInfo1;
		int32_t L_1293;
		L_1293 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1291, L_1292, NULL);
		V_59 = L_1293;
		__this->___m_IsNewPage_66 = (bool)1;
		float L_1294 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add((0.0f), L_1294));
		__this->___m_LineOffset_39 = (0.0f);
		__this->___m_MaxAscender_64 = (0.0f);
		V_24 = (0.0f);
		int32_t L_1295 = __this->___m_LineNumber_55;
		__this->___m_LineNumber_55 = ((int32_t)il2cpp_codegen_add(L_1295, 1));
		int32_t L_1296 = __this->___m_PageNumber_58;
		__this->___m_PageNumber_58 = ((int32_t)il2cpp_codegen_add(L_1296, 1));
		goto IL_329d;
	}

IL_25da:
	{
		int32_t L_1297 = __this->___m_LineNumber_55;
		V_197 = (bool)((((int32_t)L_1297) > ((int32_t)0))? 1 : 0);
		bool L_1298 = V_197;
		if (!L_1298)
		{
			goto IL_260e;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1299 = __this->___m_CharBuffer_4;
		int32_t L_1300 = V_59;
		NullCheck(L_1299);
		(L_1299)->SetAt(static_cast<il2cpp_array_size_t>(L_1300), (int32_t)0);
		int32_t L_1301 = __this->___m_CharacterCount_48;
		__this->___m_TotalCharacterCount_13 = L_1301;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1302 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1303 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1302, L_1303, NULL);
		goto IL_6c5c;
	}

IL_260e:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1304 = ___textInfo1;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_1304, NULL);
		goto IL_6c5c;
	}

IL_261c:
	{
	}

IL_261d:
	{
		int32_t L_1305 = V_60;
		V_198 = (bool)((((int32_t)L_1305) == ((int32_t)((int32_t)9)))? 1 : 0);
		bool L_1306 = V_198;
		if (!L_1306)
		{
			goto IL_2685;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1307 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1307);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_1308;
		L_1308 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_1307, NULL);
		V_57 = L_1308;
		float L_1309;
		L_1309 = FaceInfo_get_tabWidth_mC6D9F42C40EDD767DE22050E4FBE3878AC96B161((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1310 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1310);
		uint8_t L_1311;
		L_1311 = FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE(L_1310, NULL);
		float L_1312 = V_2;
		V_199 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1309, ((float)L_1311))), L_1312));
		float L_1313 = __this->___m_XAdvance_43;
		float L_1314 = V_199;
		float L_1315;
		L_1315 = ceilf(((float)(L_1313/L_1314)));
		float L_1316 = V_199;
		V_200 = ((float)il2cpp_codegen_multiply(L_1315, L_1316));
		float L_1317 = V_200;
		float L_1318 = __this->___m_XAdvance_43;
		G_B354_0 = __this;
		if ((((float)L_1317) > ((float)L_1318)))
		{
			G_B355_0 = __this;
			goto IL_2678;
		}
	}
	{
		float L_1319 = __this->___m_XAdvance_43;
		float L_1320 = V_199;
		G_B356_0 = ((float)il2cpp_codegen_add(L_1319, L_1320));
		G_B356_1 = G_B354_0;
		goto IL_267a;
	}

IL_2678:
	{
		float L_1321 = V_200;
		G_B356_0 = L_1321;
		G_B356_1 = G_B355_0;
	}

IL_267a:
	{
		NullCheck(G_B356_1);
		G_B356_1->___m_XAdvance_43 = G_B356_0;
		goto IL_27ee;
	}

IL_2685:
	{
		float L_1322 = __this->___m_MonoSpacing_42;
		V_201 = (bool)((((int32_t)((((float)L_1322) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1323 = V_201;
		if (!L_1323)
		{
			goto IL_2712;
		}
	}
	{
		float L_1324 = __this->___m_XAdvance_43;
		float L_1325 = __this->___m_MonoSpacing_42;
		float L_1326 = V_67;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1327 = ___generationSettings0;
		NullCheck(L_1327);
		float L_1328 = L_1327->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1329 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1329);
		float L_1330;
		L_1330 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1329, NULL);
		float L_1331 = V_2;
		float L_1332 = __this->___m_CSpacing_41;
		float L_1333 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1324, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_1325, L_1326)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1328, L_1330)), L_1331)))), L_1332)), ((float)il2cpp_codegen_subtract((1.0f), L_1333))))));
		int32_t L_1334 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1335;
		L_1335 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_1334), NULL);
		if (L_1335)
		{
			goto IL_26f0;
		}
	}
	{
		int32_t L_1336 = V_60;
		G_B361_0 = ((((int32_t)L_1336) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_26f1;
	}

IL_26f0:
	{
		G_B361_0 = 1;
	}

IL_26f1:
	{
		V_202 = (bool)G_B361_0;
		bool L_1337 = V_202;
		if (!L_1337)
		{
			goto IL_270c;
		}
	}
	{
		float L_1338 = __this->___m_XAdvance_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1339 = ___generationSettings0;
		NullCheck(L_1339);
		float L_1340 = L_1339->___wordSpacing_28;
		float L_1341 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1338, ((float)il2cpp_codegen_multiply(L_1340, L_1341))));
	}

IL_270c:
	{
		goto IL_27ee;
	}

IL_2712:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1342 = ___generationSettings0;
		NullCheck(L_1342);
		bool L_1343 = L_1342->___isRightToLeft_24;
		V_203 = (bool)((((int32_t)L_1343) == ((int32_t)0))? 1 : 0);
		bool L_1344 = V_203;
		if (!L_1344)
		{
			goto IL_27d6;
		}
	}
	{
		V_204 = (1.0f);
		bool L_1345 = __this->___m_IsFxMatrixSet_38;
		V_205 = L_1345;
		bool L_1346 = V_205;
		if (!L_1346)
		{
			goto IL_2745;
		}
	}
	{
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_1347 = (&__this->___m_FxMatrix_78);
		float L_1348 = L_1347->___m00_0;
		V_204 = L_1348;
	}

IL_2745:
	{
		float L_1349 = __this->___m_XAdvance_43;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_1350 = __this->___m_CachedTextElement_75;
		NullCheck(L_1350);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_1351;
		L_1351 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_1350, NULL);
		NullCheck(L_1351);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_1352;
		L_1352 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_1351, NULL);
		V_94 = L_1352;
		float L_1353;
		L_1353 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_94), NULL);
		float L_1354 = V_204;
		float L_1355 = V_4;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1356 = ___generationSettings0;
		NullCheck(L_1356);
		float L_1357 = L_1356->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1358 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1358);
		float L_1359;
		L_1359 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1358, NULL);
		float L_1360;
		L_1360 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_65), NULL);
		float L_1361 = V_2;
		float L_1362 = __this->___m_CSpacing_41;
		float L_1363 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1349, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1353, L_1354)), L_1355)), L_1357)), L_1359)), L_1360)), L_1361)), L_1362)), ((float)il2cpp_codegen_subtract((1.0f), L_1363))))));
		int32_t L_1364 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1365;
		L_1365 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_1364), NULL);
		if (L_1365)
		{
			goto IL_27b7;
		}
	}
	{
		int32_t L_1366 = V_60;
		G_B370_0 = ((((int32_t)L_1366) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_27b8;
	}

IL_27b7:
	{
		G_B370_0 = 1;
	}

IL_27b8:
	{
		V_206 = (bool)G_B370_0;
		bool L_1367 = V_206;
		if (!L_1367)
		{
			goto IL_27d3;
		}
	}
	{
		float L_1368 = __this->___m_XAdvance_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1369 = ___generationSettings0;
		NullCheck(L_1369);
		float L_1370 = L_1369->___wordSpacing_28;
		float L_1371 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1368, ((float)il2cpp_codegen_multiply(L_1370, L_1371))));
	}

IL_27d3:
	{
		goto IL_27ee;
	}

IL_27d6:
	{
		float L_1372 = __this->___m_XAdvance_43;
		float L_1373;
		L_1373 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_65), NULL);
		float L_1374 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_subtract(L_1372, ((float)il2cpp_codegen_multiply(L_1373, L_1374))));
	}

IL_27ee:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1375 = ___textInfo1;
		NullCheck(L_1375);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1376 = L_1375->___textElementInfo_10;
		int32_t L_1377 = __this->___m_CharacterCount_48;
		NullCheck(L_1376);
		float L_1378 = __this->___m_XAdvance_43;
		((L_1376)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1377)))->___xAdvance_26 = L_1378;
		int32_t L_1379 = V_60;
		V_207 = (bool)((((int32_t)L_1379) == ((int32_t)((int32_t)13)))? 1 : 0);
		bool L_1380 = V_207;
		if (!L_1380)
		{
			goto IL_282a;
		}
	}
	{
		float L_1381 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add((0.0f), L_1381));
	}

IL_282a:
	{
		int32_t L_1382 = V_60;
		if ((((int32_t)L_1382) == ((int32_t)((int32_t)10))))
		{
			goto IL_283d;
		}
	}
	{
		int32_t L_1383 = __this->___m_CharacterCount_48;
		int32_t L_1384 = V_0;
		G_B379_0 = ((((int32_t)L_1383) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1384, 1))))? 1 : 0);
		goto IL_283e;
	}

IL_283d:
	{
		G_B379_0 = 1;
	}

IL_283e:
	{
		V_208 = (bool)G_B379_0;
		bool L_1385 = V_208;
		if (!L_1385)
		{
			goto IL_2ddc;
		}
	}
	{
		int32_t L_1386 = __this->___m_LineNumber_55;
		if ((((int32_t)L_1386) <= ((int32_t)0)))
		{
			goto IL_287c;
		}
	}
	{
		float L_1387 = __this->___m_MaxLineAscender_53;
		float L_1388 = __this->___m_StartOfLineAscender_82;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_1389;
		L_1389 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(L_1387, L_1388, NULL);
		if (L_1389)
		{
			goto IL_287c;
		}
	}
	{
		float L_1390 = __this->___m_LineHeight_40;
		if ((!(((float)L_1390) == ((float)(-32767.0f)))))
		{
			goto IL_287c;
		}
	}
	{
		bool L_1391 = __this->___m_IsNewPage_66;
		G_B385_0 = ((((int32_t)L_1391) == ((int32_t)0))? 1 : 0);
		goto IL_287d;
	}

IL_287c:
	{
		G_B385_0 = 0;
	}

IL_287d:
	{
		V_211 = (bool)G_B385_0;
		bool L_1392 = V_211;
		if (!L_1392)
		{
			goto IL_28b8;
		}
	}
	{
		float L_1393 = __this->___m_MaxLineAscender_53;
		float L_1394 = __this->___m_StartOfLineAscender_82;
		V_212 = ((float)il2cpp_codegen_subtract(L_1393, L_1394));
		int32_t L_1395 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_1396 = __this->___m_CharacterCount_48;
		float L_1397 = V_212;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1398 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_1395, L_1396, L_1397, L_1398, NULL);
		float L_1399 = __this->___m_LineOffset_39;
		float L_1400 = V_212;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1399, L_1400));
	}

IL_28b8:
	{
		__this->___m_IsNewPage_66 = (bool)0;
		float L_1401 = __this->___m_MaxLineAscender_53;
		float L_1402 = __this->___m_LineOffset_39;
		V_209 = ((float)il2cpp_codegen_subtract(L_1401, L_1402));
		float L_1403 = __this->___m_MaxLineDescender_54;
		float L_1404 = __this->___m_LineOffset_39;
		V_210 = ((float)il2cpp_codegen_subtract(L_1403, L_1404));
		float L_1405 = __this->___m_MaxDescender_65;
		float L_1406 = V_210;
		G_B388_0 = __this;
		if ((((float)L_1405) < ((float)L_1406)))
		{
			G_B389_0 = __this;
			goto IL_28ec;
		}
	}
	{
		float L_1407 = V_210;
		G_B390_0 = L_1407;
		G_B390_1 = G_B388_0;
		goto IL_28f2;
	}

IL_28ec:
	{
		float L_1408 = __this->___m_MaxDescender_65;
		G_B390_0 = L_1408;
		G_B390_1 = G_B389_0;
	}

IL_28f2:
	{
		NullCheck(G_B390_1);
		G_B390_1->___m_MaxDescender_65 = G_B390_0;
		bool L_1409 = V_26;
		V_213 = (bool)((((int32_t)L_1409) == ((int32_t)0))? 1 : 0);
		bool L_1410 = V_213;
		if (!L_1410)
		{
			goto IL_290a;
		}
	}
	{
		float L_1411 = __this->___m_MaxDescender_65;
		V_25 = L_1411;
	}

IL_290a:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1412 = ___generationSettings0;
		NullCheck(L_1412);
		bool L_1413 = L_1412->___useMaxVisibleDescender_36;
		if (!L_1413)
		{
			goto IL_2936;
		}
	}
	{
		int32_t L_1414 = __this->___m_CharacterCount_48;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1415 = ___generationSettings0;
		NullCheck(L_1415);
		int32_t L_1416 = L_1415->___maxVisibleCharacters_32;
		if ((((int32_t)L_1414) >= ((int32_t)L_1416)))
		{
			goto IL_2933;
		}
	}
	{
		int32_t L_1417 = __this->___m_LineNumber_55;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1418 = ___generationSettings0;
		NullCheck(L_1418);
		int32_t L_1419 = L_1418->___maxVisibleLines_34;
		G_B396_0 = ((((int32_t)((((int32_t)L_1417) < ((int32_t)L_1419))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2934;
	}

IL_2933:
	{
		G_B396_0 = 1;
	}

IL_2934:
	{
		G_B398_0 = G_B396_0;
		goto IL_2937;
	}

IL_2936:
	{
		G_B398_0 = 0;
	}

IL_2937:
	{
		V_214 = (bool)G_B398_0;
		bool L_1420 = V_214;
		if (!L_1420)
		{
			goto IL_2940;
		}
	}
	{
		V_26 = (bool)1;
	}

IL_2940:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1421 = ___textInfo1;
		NullCheck(L_1421);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1422 = L_1421->___lineInfo_13;
		int32_t L_1423 = __this->___m_LineNumber_55;
		NullCheck(L_1422);
		int32_t L_1424 = __this->___m_FirstCharacterOfLine_49;
		((L_1422)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1423)))->___firstCharacterIndex_6 = L_1424;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1425 = ___textInfo1;
		NullCheck(L_1425);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1426 = L_1425->___lineInfo_13;
		int32_t L_1427 = __this->___m_LineNumber_55;
		NullCheck(L_1426);
		int32_t L_1428 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_1429 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B401_0 = __this;
		G_B401_1 = ((L_1426)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1427)));
		if ((((int32_t)L_1428) > ((int32_t)L_1429)))
		{
			G_B402_0 = __this;
			G_B402_1 = ((L_1426)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1427)));
			goto IL_2984;
		}
	}
	{
		int32_t L_1430 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B403_0 = L_1430;
		G_B403_1 = G_B401_0;
		G_B403_2 = G_B401_1;
		goto IL_298a;
	}

IL_2984:
	{
		int32_t L_1431 = __this->___m_FirstCharacterOfLine_49;
		G_B403_0 = L_1431;
		G_B403_1 = G_B402_0;
		G_B403_2 = G_B402_1;
	}

IL_298a:
	{
		int32_t L_1432 = G_B403_0;
		V_149 = L_1432;
		NullCheck(G_B403_1);
		G_B403_1->___m_FirstVisibleCharacterOfLine_51 = L_1432;
		int32_t L_1433 = V_149;
		G_B403_2->___firstVisibleCharacterIndex_7 = L_1433;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1434 = ___textInfo1;
		NullCheck(L_1434);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1435 = L_1434->___lineInfo_13;
		int32_t L_1436 = __this->___m_LineNumber_55;
		NullCheck(L_1435);
		int32_t L_1437 = __this->___m_CharacterCount_48;
		int32_t L_1438 = L_1437;
		V_149 = L_1438;
		__this->___m_LastCharacterOfLine_50 = L_1438;
		int32_t L_1439 = V_149;
		((L_1435)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1436)))->___lastCharacterIndex_8 = L_1439;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1440 = ___textInfo1;
		NullCheck(L_1440);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1441 = L_1440->___lineInfo_13;
		int32_t L_1442 = __this->___m_LineNumber_55;
		NullCheck(L_1441);
		int32_t L_1443 = __this->___m_LastVisibleCharacterOfLine_52;
		int32_t L_1444 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B404_0 = __this;
		G_B404_1 = ((L_1441)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1442)));
		if ((((int32_t)L_1443) < ((int32_t)L_1444)))
		{
			G_B405_0 = __this;
			G_B405_1 = ((L_1441)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1442)));
			goto IL_29e8;
		}
	}
	{
		int32_t L_1445 = __this->___m_LastVisibleCharacterOfLine_52;
		G_B406_0 = L_1445;
		G_B406_1 = G_B404_0;
		G_B406_2 = G_B404_1;
		goto IL_29ee;
	}

IL_29e8:
	{
		int32_t L_1446 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B406_0 = L_1446;
		G_B406_1 = G_B405_0;
		G_B406_2 = G_B405_1;
	}

IL_29ee:
	{
		int32_t L_1447 = G_B406_0;
		V_149 = L_1447;
		NullCheck(G_B406_1);
		G_B406_1->___m_LastVisibleCharacterOfLine_52 = L_1447;
		int32_t L_1448 = V_149;
		G_B406_2->___lastVisibleCharacterIndex_9 = L_1448;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1449 = ___textInfo1;
		NullCheck(L_1449);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1450 = L_1449->___lineInfo_13;
		int32_t L_1451 = __this->___m_LineNumber_55;
		NullCheck(L_1450);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1452 = ___textInfo1;
		NullCheck(L_1452);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1453 = L_1452->___lineInfo_13;
		int32_t L_1454 = __this->___m_LineNumber_55;
		NullCheck(L_1453);
		int32_t L_1455 = ((L_1453)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1454)))->___lastCharacterIndex_8;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1456 = ___textInfo1;
		NullCheck(L_1456);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1457 = L_1456->___lineInfo_13;
		int32_t L_1458 = __this->___m_LineNumber_55;
		NullCheck(L_1457);
		int32_t L_1459 = ((L_1457)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1458)))->___firstCharacterIndex_6;
		((L_1450)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1451)))->___characterCount_1 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_1455, L_1459)), 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1460 = ___textInfo1;
		NullCheck(L_1460);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1461 = L_1460->___lineInfo_13;
		int32_t L_1462 = __this->___m_LineNumber_55;
		NullCheck(L_1461);
		int32_t L_1463 = __this->___m_LineVisibleCharacterCount_56;
		((L_1461)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1462)))->___visibleCharacterCount_2 = L_1463;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1464 = ___textInfo1;
		NullCheck(L_1464);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1465 = L_1464->___lineInfo_13;
		int32_t L_1466 = __this->___m_LineNumber_55;
		NullCheck(L_1465);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1467 = (&((L_1465)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1466)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1468 = ___textInfo1;
		NullCheck(L_1468);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1469 = L_1468->___textElementInfo_10;
		int32_t L_1470 = __this->___m_FirstVisibleCharacterOfLine_51;
		NullCheck(L_1469);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1471 = (&((L_1469)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1470)))->___bottomLeft_19);
		float L_1472 = L_1471->___x_2;
		float L_1473 = V_210;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1474;
		memset((&L_1474), 0, sizeof(L_1474));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_1474), L_1472, L_1473, /*hidden argument*/NULL);
		L_1467->___min_0 = L_1474;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1475 = ___textInfo1;
		NullCheck(L_1475);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1476 = L_1475->___lineInfo_13;
		int32_t L_1477 = __this->___m_LineNumber_55;
		NullCheck(L_1476);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1478 = (&((L_1476)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1477)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1479 = ___textInfo1;
		NullCheck(L_1479);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1480 = L_1479->___textElementInfo_10;
		int32_t L_1481 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_1480);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1482 = (&((L_1480)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1481)))->___topRight_20);
		float L_1483 = L_1482->___x_2;
		float L_1484 = V_209;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1485;
		memset((&L_1485), 0, sizeof(L_1485));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_1485), L_1483, L_1484, /*hidden argument*/NULL);
		L_1478->___max_1 = L_1485;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1486 = ___textInfo1;
		NullCheck(L_1486);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1487 = L_1486->___lineInfo_13;
		int32_t L_1488 = __this->___m_LineNumber_55;
		NullCheck(L_1487);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1489 = ___textInfo1;
		NullCheck(L_1489);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1490 = L_1489->___lineInfo_13;
		int32_t L_1491 = __this->___m_LineNumber_55;
		NullCheck(L_1490);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1492 = (&((L_1490)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1491)))->___lineExtents_20);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1493 = (&L_1492->___max_1);
		float L_1494 = L_1493->___x_0;
		float L_1495 = V_3;
		float L_1496 = V_2;
		((L_1487)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1488)))->___length_10 = ((float)il2cpp_codegen_subtract(L_1494, ((float)il2cpp_codegen_multiply(L_1495, L_1496))));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1497 = ___textInfo1;
		NullCheck(L_1497);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1498 = L_1497->___lineInfo_13;
		int32_t L_1499 = __this->___m_LineNumber_55;
		NullCheck(L_1498);
		float L_1500 = V_22;
		((L_1498)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1499)))->___width_16 = L_1500;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1501 = ___textInfo1;
		NullCheck(L_1501);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1502 = L_1501->___lineInfo_13;
		int32_t L_1503 = __this->___m_LineNumber_55;
		NullCheck(L_1502);
		int32_t L_1504 = ((L_1502)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1503)))->___characterCount_1;
		V_215 = (bool)((((int32_t)L_1504) == ((int32_t)1))? 1 : 0);
		bool L_1505 = V_215;
		if (!L_1505)
		{
			goto IL_2b65;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1506 = ___textInfo1;
		NullCheck(L_1506);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1507 = L_1506->___lineInfo_13;
		int32_t L_1508 = __this->___m_LineNumber_55;
		NullCheck(L_1507);
		int32_t L_1509 = __this->___m_LineJustification_23;
		((L_1507)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1508)))->___alignment_19 = L_1509;
	}

IL_2b65:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1510 = ___textInfo1;
		NullCheck(L_1510);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1511 = L_1510->___textElementInfo_10;
		int32_t L_1512 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_1511);
		bool L_1513 = ((L_1511)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1512)))->___isVisible_34;
		V_216 = L_1513;
		bool L_1514 = V_216;
		if (!L_1514)
		{
			goto IL_2bcb;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1515 = ___textInfo1;
		NullCheck(L_1515);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1516 = L_1515->___lineInfo_13;
		int32_t L_1517 = __this->___m_LineNumber_55;
		NullCheck(L_1516);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1518 = ___textInfo1;
		NullCheck(L_1518);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1519 = L_1518->___textElementInfo_10;
		int32_t L_1520 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_1519);
		float L_1521 = ((L_1519)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1520)))->___xAdvance_26;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1522 = ___generationSettings0;
		NullCheck(L_1522);
		float L_1523 = L_1522->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1524 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1524);
		float L_1525;
		L_1525 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1524, NULL);
		float L_1526 = V_2;
		float L_1527 = __this->___m_CSpacing_41;
		((L_1516)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1517)))->___maxAdvance_15 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_1521, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1523, L_1525)), L_1526)))), L_1527));
		goto IL_2c13;
	}

IL_2bcb:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1528 = ___textInfo1;
		NullCheck(L_1528);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1529 = L_1528->___lineInfo_13;
		int32_t L_1530 = __this->___m_LineNumber_55;
		NullCheck(L_1529);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1531 = ___textInfo1;
		NullCheck(L_1531);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1532 = L_1531->___textElementInfo_10;
		int32_t L_1533 = __this->___m_LastCharacterOfLine_50;
		NullCheck(L_1532);
		float L_1534 = ((L_1532)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1533)))->___xAdvance_26;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1535 = ___generationSettings0;
		NullCheck(L_1535);
		float L_1536 = L_1535->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1537 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1537);
		float L_1538;
		L_1538 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1537, NULL);
		float L_1539 = V_2;
		float L_1540 = __this->___m_CSpacing_41;
		((L_1529)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1530)))->___maxAdvance_15 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_1534, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1536, L_1538)), L_1539)))), L_1540));
	}

IL_2c13:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1541 = ___textInfo1;
		NullCheck(L_1541);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1542 = L_1541->___lineInfo_13;
		int32_t L_1543 = __this->___m_LineNumber_55;
		NullCheck(L_1542);
		float L_1544 = __this->___m_LineOffset_39;
		((L_1542)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1543)))->___baseline_13 = ((float)il2cpp_codegen_subtract((0.0f), L_1544));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1545 = ___textInfo1;
		NullCheck(L_1545);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1546 = L_1545->___lineInfo_13;
		int32_t L_1547 = __this->___m_LineNumber_55;
		NullCheck(L_1546);
		float L_1548 = V_209;
		((L_1546)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1547)))->___ascender_12 = L_1548;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1549 = ___textInfo1;
		NullCheck(L_1549);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1550 = L_1549->___lineInfo_13;
		int32_t L_1551 = __this->___m_LineNumber_55;
		NullCheck(L_1550);
		float L_1552 = V_210;
		((L_1550)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1551)))->___descender_14 = L_1552;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1553 = ___textInfo1;
		NullCheck(L_1553);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1554 = L_1553->___lineInfo_13;
		int32_t L_1555 = __this->___m_LineNumber_55;
		NullCheck(L_1554);
		float L_1556 = V_209;
		float L_1557 = V_210;
		float L_1558 = V_14;
		float L_1559 = V_1;
		((L_1554)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1555)))->___lineHeight_11 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_1556, L_1557)), ((float)il2cpp_codegen_multiply(L_1558, L_1559))));
		int32_t L_1560 = __this->___m_CharacterCount_48;
		__this->___m_FirstCharacterOfLine_49 = ((int32_t)il2cpp_codegen_add(L_1560, 1));
		__this->___m_LineVisibleCharacterCount_56 = 0;
		int32_t L_1561 = V_60;
		V_217 = (bool)((((int32_t)L_1561) == ((int32_t)((int32_t)10)))? 1 : 0);
		bool L_1562 = V_217;
		if (!L_1562)
		{
			goto IL_2ddb;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1563 = (&__this->___m_SavedLineState_69);
		int32_t L_1564 = V_59;
		int32_t L_1565 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1566 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1563, L_1564, L_1565, L_1566, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1567 = (&__this->___m_SavedWordWrapState_68);
		int32_t L_1568 = V_59;
		int32_t L_1569 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1570 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1567, L_1568, L_1569, L_1570, NULL);
		int32_t L_1571 = __this->___m_LineNumber_55;
		__this->___m_LineNumber_55 = ((int32_t)il2cpp_codegen_add(L_1571, 1));
		V_15 = (bool)1;
		V_28 = (bool)0;
		V_27 = (bool)1;
		int32_t L_1572 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1573 = ___textInfo1;
		NullCheck(L_1573);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1574 = L_1573->___lineInfo_13;
		NullCheck(L_1574);
		V_218 = (bool)((((int32_t)((((int32_t)L_1572) < ((int32_t)((int32_t)(((RuntimeArray*)L_1574)->max_length))))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1575 = V_218;
		if (!L_1575)
		{
			goto IL_2d13;
		}
	}
	{
		int32_t L_1576 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1577 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85(L_1576, L_1577, NULL);
	}

IL_2d13:
	{
		float L_1578 = __this->___m_LineHeight_40;
		V_219 = (bool)((((float)L_1578) == ((float)(-32767.0f)))? 1 : 0);
		bool L_1579 = V_219;
		if (!L_1579)
		{
			goto IL_2d64;
		}
	}
	{
		float L_1580 = __this->___m_MaxLineDescender_54;
		float L_1581 = V_74;
		float L_1582 = V_14;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1583 = ___generationSettings0;
		NullCheck(L_1583);
		float L_1584 = L_1583->___lineSpacing_29;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1585 = ___generationSettings0;
		NullCheck(L_1585);
		float L_1586 = L_1585->___paragraphSpacing_30;
		float L_1587 = __this->___m_LineSpacingDelta_83;
		float L_1588 = V_1;
		V_77 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_1580)), L_1581)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1582, L_1584)), L_1586)), L_1587)), L_1588))));
		float L_1589 = __this->___m_LineOffset_39;
		float L_1590 = V_77;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1589, L_1590));
		goto IL_2d87;
	}

IL_2d64:
	{
		float L_1591 = __this->___m_LineOffset_39;
		float L_1592 = __this->___m_LineHeight_40;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1593 = ___generationSettings0;
		NullCheck(L_1593);
		float L_1594 = L_1593->___lineSpacing_29;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1595 = ___generationSettings0;
		NullCheck(L_1595);
		float L_1596 = L_1595->___paragraphSpacing_30;
		float L_1597 = V_1;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1591, ((float)il2cpp_codegen_add(L_1592, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1594, L_1596)), L_1597))))));
	}

IL_2d87:
	{
		__this->___m_MaxLineAscender_53 = (-32767.0f);
		__this->___m_MaxLineDescender_54 = (32767.0f);
		float L_1598 = V_74;
		__this->___m_StartOfLineAscender_82 = L_1598;
		float L_1599 = __this->___m_TagLineIndent_44;
		float L_1600 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add((0.0f), L_1599)), L_1600));
		int32_t L_1601 = __this->___m_CharacterCount_48;
		V_18 = ((int32_t)il2cpp_codegen_subtract(L_1601, 1));
		int32_t L_1602 = __this->___m_CharacterCount_48;
		__this->___m_CharacterCount_48 = ((int32_t)il2cpp_codegen_add(L_1602, 1));
		goto IL_329d;
	}

IL_2ddb:
	{
	}

IL_2ddc:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1603 = ___textInfo1;
		NullCheck(L_1603);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1604 = L_1603->___textElementInfo_10;
		int32_t L_1605 = __this->___m_CharacterCount_48;
		NullCheck(L_1604);
		bool L_1606 = ((L_1604)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1605)))->___isVisible_34;
		V_220 = L_1606;
		bool L_1607 = V_220;
		if (!L_1607)
		{
			goto IL_2efd;
		}
	}
	{
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1608 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1609 = (&L_1608->___min_0);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1610 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1611 = (&L_1610->___min_0);
		float L_1612 = L_1611->___x_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1613 = ___textInfo1;
		NullCheck(L_1613);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1614 = L_1613->___textElementInfo_10;
		int32_t L_1615 = __this->___m_CharacterCount_48;
		NullCheck(L_1614);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1616 = (&((L_1614)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1615)))->___bottomLeft_19);
		float L_1617 = L_1616->___x_2;
		float L_1618;
		L_1618 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1612, L_1617, NULL);
		L_1609->___x_0 = L_1618;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1619 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1620 = (&L_1619->___min_0);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1621 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1622 = (&L_1621->___min_0);
		float L_1623 = L_1622->___y_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1624 = ___textInfo1;
		NullCheck(L_1624);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1625 = L_1624->___textElementInfo_10;
		int32_t L_1626 = __this->___m_CharacterCount_48;
		NullCheck(L_1625);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1627 = (&((L_1625)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1626)))->___bottomLeft_19);
		float L_1628 = L_1627->___y_3;
		float L_1629;
		L_1629 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1623, L_1628, NULL);
		L_1620->___y_1 = L_1629;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1630 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1631 = (&L_1630->___max_1);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1632 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1633 = (&L_1632->___max_1);
		float L_1634 = L_1633->___x_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1635 = ___textInfo1;
		NullCheck(L_1635);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1636 = L_1635->___textElementInfo_10;
		int32_t L_1637 = __this->___m_CharacterCount_48;
		NullCheck(L_1636);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1638 = (&((L_1636)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1637)))->___topRight_20);
		float L_1639 = L_1638->___x_2;
		float L_1640;
		L_1640 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1634, L_1639, NULL);
		L_1631->___x_0 = L_1640;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1641 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1642 = (&L_1641->___max_1);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1643 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1644 = (&L_1643->___max_1);
		float L_1645 = L_1644->___y_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1646 = ___textInfo1;
		NullCheck(L_1646);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1647 = L_1646->___textElementInfo_10;
		int32_t L_1648 = __this->___m_CharacterCount_48;
		NullCheck(L_1647);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1649 = (&((L_1647)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1648)))->___topRight_20);
		float L_1650 = L_1649->___y_3;
		float L_1651;
		L_1651 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1645, L_1650, NULL);
		L_1642->___y_1 = L_1651;
	}

IL_2efd:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1652 = ___generationSettings0;
		NullCheck(L_1652);
		int32_t L_1653 = L_1652->___overflowMode_11;
		if ((!(((uint32_t)L_1653) == ((uint32_t)5))))
		{
			goto IL_2f17;
		}
	}
	{
		int32_t L_1654 = V_60;
		if ((((int32_t)L_1654) == ((int32_t)((int32_t)13))))
		{
			goto IL_2f17;
		}
	}
	{
		int32_t L_1655 = V_60;
		G_B425_0 = ((((int32_t)((((int32_t)L_1655) == ((int32_t)((int32_t)10)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2f18;
	}

IL_2f17:
	{
		G_B425_0 = 0;
	}

IL_2f18:
	{
		V_221 = (bool)G_B425_0;
		bool L_1656 = V_221;
		if (!L_1656)
		{
			goto IL_308f;
		}
	}
	{
		int32_t L_1657 = __this->___m_PageNumber_58;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1658 = ___textInfo1;
		NullCheck(L_1658);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1659 = L_1658->___pageInfo_14;
		NullCheck(L_1659);
		V_222 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_1657, 1))) > ((int32_t)((int32_t)(((RuntimeArray*)L_1659)->max_length))))? 1 : 0);
		bool L_1660 = V_222;
		if (!L_1660)
		{
			goto IL_2f4f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1661 = ___textInfo1;
		NullCheck(L_1661);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** L_1662 = (&L_1661->___pageInfo_14);
		int32_t L_1663 = __this->___m_PageNumber_58;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8(L_1662, ((int32_t)il2cpp_codegen_add(L_1663, 1)), (bool)1, TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var);
	}

IL_2f4f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1664 = ___textInfo1;
		NullCheck(L_1664);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1665 = L_1664->___pageInfo_14;
		int32_t L_1666 = __this->___m_PageNumber_58;
		NullCheck(L_1665);
		float L_1667 = V_24;
		((L_1665)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1666)))->___ascender_2 = L_1667;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1668 = ___textInfo1;
		NullCheck(L_1668);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1669 = L_1668->___pageInfo_14;
		int32_t L_1670 = __this->___m_PageNumber_58;
		NullCheck(L_1669);
		float L_1671 = V_75;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1672 = ___textInfo1;
		NullCheck(L_1672);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1673 = L_1672->___pageInfo_14;
		int32_t L_1674 = __this->___m_PageNumber_58;
		NullCheck(L_1673);
		float L_1675 = ((L_1673)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1674)))->___descender_4;
		G_B429_0 = ((L_1669)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1670)));
		if ((((float)L_1671) < ((float)L_1675)))
		{
			G_B430_0 = ((L_1669)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1670)));
			goto IL_2faa;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1676 = ___textInfo1;
		NullCheck(L_1676);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1677 = L_1676->___pageInfo_14;
		int32_t L_1678 = __this->___m_PageNumber_58;
		NullCheck(L_1677);
		float L_1679 = ((L_1677)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1678)))->___descender_4;
		G_B431_0 = L_1679;
		G_B431_1 = G_B429_0;
		goto IL_2fac;
	}

IL_2faa:
	{
		float L_1680 = V_75;
		G_B431_0 = L_1680;
		G_B431_1 = G_B430_0;
	}

IL_2fac:
	{
		G_B431_1->___descender_4 = G_B431_0;
		int32_t L_1681 = __this->___m_PageNumber_58;
		if (L_1681)
		{
			goto IL_2fc4;
		}
	}
	{
		int32_t L_1682 = __this->___m_CharacterCount_48;
		G_B434_0 = ((((int32_t)L_1682) == ((int32_t)0))? 1 : 0);
		goto IL_2fc5;
	}

IL_2fc4:
	{
		G_B434_0 = 0;
	}

IL_2fc5:
	{
		V_223 = (bool)G_B434_0;
		bool L_1683 = V_223;
		if (!L_1683)
		{
			goto IL_2fec;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1684 = ___textInfo1;
		NullCheck(L_1684);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1685 = L_1684->___pageInfo_14;
		int32_t L_1686 = __this->___m_PageNumber_58;
		NullCheck(L_1685);
		int32_t L_1687 = __this->___m_CharacterCount_48;
		((L_1685)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1686)))->___firstCharacterIndex_0 = L_1687;
		goto IL_308e;
	}

IL_2fec:
	{
		int32_t L_1688 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_1688) <= ((int32_t)0)))
		{
			goto IL_301a;
		}
	}
	{
		int32_t L_1689 = __this->___m_PageNumber_58;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1690 = ___textInfo1;
		NullCheck(L_1690);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1691 = L_1690->___textElementInfo_10;
		int32_t L_1692 = __this->___m_CharacterCount_48;
		NullCheck(L_1691);
		int32_t L_1693 = ((L_1691)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1692, 1)))))->___pageNumber_12;
		G_B439_0 = ((((int32_t)((((int32_t)L_1689) == ((int32_t)L_1693))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_301b;
	}

IL_301a:
	{
		G_B439_0 = 0;
	}

IL_301b:
	{
		V_224 = (bool)G_B439_0;
		bool L_1694 = V_224;
		if (!L_1694)
		{
			goto IL_3061;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1695 = ___textInfo1;
		NullCheck(L_1695);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1696 = L_1695->___pageInfo_14;
		int32_t L_1697 = __this->___m_PageNumber_58;
		NullCheck(L_1696);
		int32_t L_1698 = __this->___m_CharacterCount_48;
		((L_1696)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1697, 1)))))->___lastCharacterIndex_1 = ((int32_t)il2cpp_codegen_subtract(L_1698, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1699 = ___textInfo1;
		NullCheck(L_1699);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1700 = L_1699->___pageInfo_14;
		int32_t L_1701 = __this->___m_PageNumber_58;
		NullCheck(L_1700);
		int32_t L_1702 = __this->___m_CharacterCount_48;
		((L_1700)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1701)))->___firstCharacterIndex_0 = L_1702;
		goto IL_308e;
	}

IL_3061:
	{
		int32_t L_1703 = __this->___m_CharacterCount_48;
		int32_t L_1704 = V_0;
		V_225 = (bool)((((int32_t)L_1703) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1704, 1))))? 1 : 0);
		bool L_1705 = V_225;
		if (!L_1705)
		{
			goto IL_308e;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1706 = ___textInfo1;
		NullCheck(L_1706);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1707 = L_1706->___pageInfo_14;
		int32_t L_1708 = __this->___m_PageNumber_58;
		NullCheck(L_1707);
		int32_t L_1709 = __this->___m_CharacterCount_48;
		((L_1707)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1708)))->___lastCharacterIndex_1 = L_1709;
	}

IL_308e:
	{
	}

IL_308f:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1710 = ___generationSettings0;
		NullCheck(L_1710);
		bool L_1711 = L_1710->___wordWrap_12;
		if (L_1711)
		{
			goto IL_30ab;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1712 = ___generationSettings0;
		NullCheck(L_1712);
		int32_t L_1713 = L_1712->___overflowMode_11;
		if ((((int32_t)L_1713) == ((int32_t)3)))
		{
			goto IL_30ab;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1714 = ___generationSettings0;
		NullCheck(L_1714);
		int32_t L_1715 = L_1714->___overflowMode_11;
		G_B448_0 = ((((int32_t)L_1715) == ((int32_t)1))? 1 : 0);
		goto IL_30ac;
	}

IL_30ab:
	{
		G_B448_0 = 1;
	}

IL_30ac:
	{
		V_226 = (bool)G_B448_0;
		bool L_1716 = V_226;
		if (!L_1716)
		{
			goto IL_328e;
		}
	}
	{
		int32_t L_1717 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1718;
		L_1718 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_1717), NULL);
		if (L_1718)
		{
			goto IL_30d8;
		}
	}
	{
		int32_t L_1719 = V_60;
		if ((((int32_t)L_1719) == ((int32_t)((int32_t)8203))))
		{
			goto IL_30d8;
		}
	}
	{
		int32_t L_1720 = V_60;
		if ((((int32_t)L_1720) == ((int32_t)((int32_t)45))))
		{
			goto IL_30d8;
		}
	}
	{
		int32_t L_1721 = V_60;
		if ((!(((uint32_t)L_1721) == ((uint32_t)((int32_t)173)))))
		{
			goto IL_3118;
		}
	}

IL_30d8:
	{
		bool L_1722 = __this->___m_IsNonBreakingSpace_67;
		bool L_1723 = V_28;
		if (!((int32_t)(((((int32_t)L_1722) == ((int32_t)0))? 1 : 0)|(int32_t)L_1723)))
		{
			goto IL_3118;
		}
	}
	{
		int32_t L_1724 = V_60;
		if ((((int32_t)L_1724) == ((int32_t)((int32_t)160))))
		{
			goto IL_3118;
		}
	}
	{
		int32_t L_1725 = V_60;
		if ((((int32_t)L_1725) == ((int32_t)((int32_t)8199))))
		{
			goto IL_3118;
		}
	}
	{
		int32_t L_1726 = V_60;
		if ((((int32_t)L_1726) == ((int32_t)((int32_t)8209))))
		{
			goto IL_3118;
		}
	}
	{
		int32_t L_1727 = V_60;
		if ((((int32_t)L_1727) == ((int32_t)((int32_t)8239))))
		{
			goto IL_3118;
		}
	}
	{
		int32_t L_1728 = V_60;
		G_B460_0 = ((((int32_t)((((int32_t)L_1728) == ((int32_t)((int32_t)8288)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_3119;
	}

IL_3118:
	{
		G_B460_0 = 0;
	}

IL_3119:
	{
		V_227 = (bool)G_B460_0;
		bool L_1729 = V_227;
		if (!L_1729)
		{
			goto IL_3146;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1730 = (&__this->___m_SavedWordWrapState_68);
		int32_t L_1731 = V_59;
		int32_t L_1732 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1733 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1730, L_1731, L_1732, L_1733, NULL);
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)0;
		V_27 = (bool)0;
		goto IL_328d;
	}

IL_3146:
	{
		int32_t L_1734 = V_60;
		if ((((int32_t)L_1734) <= ((int32_t)((int32_t)4352))))
		{
			goto IL_3158;
		}
	}
	{
		int32_t L_1735 = V_60;
		if ((((int32_t)L_1735) < ((int32_t)((int32_t)4607))))
		{
			goto IL_31c4;
		}
	}

IL_3158:
	{
		int32_t L_1736 = V_60;
		if ((((int32_t)L_1736) <= ((int32_t)((int32_t)11904))))
		{
			goto IL_316a;
		}
	}
	{
		int32_t L_1737 = V_60;
		if ((((int32_t)L_1737) < ((int32_t)((int32_t)40959))))
		{
			goto IL_31c4;
		}
	}

IL_316a:
	{
		int32_t L_1738 = V_60;
		if ((((int32_t)L_1738) <= ((int32_t)((int32_t)43360))))
		{
			goto IL_317c;
		}
	}
	{
		int32_t L_1739 = V_60;
		if ((((int32_t)L_1739) < ((int32_t)((int32_t)43391))))
		{
			goto IL_31c4;
		}
	}

IL_317c:
	{
		int32_t L_1740 = V_60;
		if ((((int32_t)L_1740) <= ((int32_t)((int32_t)44032))))
		{
			goto IL_318e;
		}
	}
	{
		int32_t L_1741 = V_60;
		if ((((int32_t)L_1741) < ((int32_t)((int32_t)55295))))
		{
			goto IL_31c4;
		}
	}

IL_318e:
	{
		int32_t L_1742 = V_60;
		if ((((int32_t)L_1742) <= ((int32_t)((int32_t)63744))))
		{
			goto IL_31a0;
		}
	}
	{
		int32_t L_1743 = V_60;
		if ((((int32_t)L_1743) < ((int32_t)((int32_t)64255))))
		{
			goto IL_31c4;
		}
	}

IL_31a0:
	{
		int32_t L_1744 = V_60;
		if ((((int32_t)L_1744) <= ((int32_t)((int32_t)65072))))
		{
			goto IL_31b2;
		}
	}
	{
		int32_t L_1745 = V_60;
		if ((((int32_t)L_1745) < ((int32_t)((int32_t)65103))))
		{
			goto IL_31c4;
		}
	}

IL_31b2:
	{
		int32_t L_1746 = V_60;
		if ((((int32_t)L_1746) <= ((int32_t)((int32_t)65280))))
		{
			goto IL_31cf;
		}
	}
	{
		int32_t L_1747 = V_60;
		if ((((int32_t)L_1747) >= ((int32_t)((int32_t)65519))))
		{
			goto IL_31cf;
		}
	}

IL_31c4:
	{
		bool L_1748 = __this->___m_IsNonBreakingSpace_67;
		G_B478_0 = ((((int32_t)L_1748) == ((int32_t)0))? 1 : 0);
		goto IL_31d0;
	}

IL_31cf:
	{
		G_B478_0 = 0;
	}

IL_31d0:
	{
		V_228 = (bool)G_B478_0;
		bool L_1749 = V_228;
		if (!L_1749)
		{
			goto IL_3261;
		}
	}
	{
		bool L_1750 = V_27;
		bool L_1751 = V_29;
		if (((int32_t)((int32_t)L_1750|(int32_t)L_1751)))
		{
			goto IL_3235;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_1752 = V_23;
		NullCheck(L_1752);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_1753;
		L_1753 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_1752, NULL);
		NullCheck(L_1753);
		HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* L_1754;
		L_1754 = UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC(L_1753, NULL);
		int32_t L_1755 = V_60;
		NullCheck(L_1754);
		bool L_1756;
		L_1756 = HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9(L_1754, L_1755, HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		if (L_1756)
		{
			goto IL_3232;
		}
	}
	{
		int32_t L_1757 = __this->___m_CharacterCount_48;
		int32_t L_1758 = V_0;
		if ((((int32_t)L_1757) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1758, 1)))))
		{
			goto IL_322f;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_1759 = V_23;
		NullCheck(L_1759);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_1760;
		L_1760 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_1759, NULL);
		NullCheck(L_1760);
		HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* L_1761;
		L_1761 = UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B(L_1760, NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1762 = ___textInfo1;
		NullCheck(L_1762);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1763 = L_1762->___textElementInfo_10;
		int32_t L_1764 = __this->___m_CharacterCount_48;
		NullCheck(L_1763);
		Il2CppChar L_1765 = ((L_1763)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_1764, 1)))))->___character_0;
		NullCheck(L_1761);
		bool L_1766;
		L_1766 = HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9(L_1761, L_1765, HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		G_B484_0 = ((((int32_t)L_1766) == ((int32_t)0))? 1 : 0);
		goto IL_3230;
	}

IL_322f:
	{
		G_B484_0 = 0;
	}

IL_3230:
	{
		G_B486_0 = G_B484_0;
		goto IL_3233;
	}

IL_3232:
	{
		G_B486_0 = 0;
	}

IL_3233:
	{
		G_B488_0 = G_B486_0;
		goto IL_3236;
	}

IL_3235:
	{
		G_B488_0 = 1;
	}

IL_3236:
	{
		V_229 = (bool)G_B488_0;
		bool L_1767 = V_229;
		if (!L_1767)
		{
			goto IL_325e;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1768 = (&__this->___m_SavedWordWrapState_68);
		int32_t L_1769 = V_59;
		int32_t L_1770 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1771 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1768, L_1769, L_1770, L_1771, NULL);
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)0;
		V_27 = (bool)0;
	}

IL_325e:
	{
		goto IL_328d;
	}

IL_3261:
	{
		bool L_1772 = V_27;
		if (L_1772)
		{
			goto IL_326d;
		}
	}
	{
		bool L_1773 = __this->___m_IsCharacterWrappingEnabled_81;
		G_B494_0 = ((int32_t)(L_1773));
		goto IL_326e;
	}

IL_326d:
	{
		G_B494_0 = 1;
	}

IL_326e:
	{
		bool L_1774 = V_29;
		V_230 = (bool)((int32_t)(G_B494_0|(int32_t)L_1774));
		bool L_1775 = V_230;
		if (!L_1775)
		{
			goto IL_328d;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1776 = (&__this->___m_SavedWordWrapState_68);
		int32_t L_1777 = V_59;
		int32_t L_1778 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1779 = ___textInfo1;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1776, L_1777, L_1778, L_1779, NULL);
	}

IL_328d:
	{
	}

IL_328e:
	{
		int32_t L_1780 = __this->___m_CharacterCount_48;
		__this->___m_CharacterCount_48 = ((int32_t)il2cpp_codegen_add(L_1780, 1));
	}

IL_329d:
	{
		int32_t L_1781 = V_59;
		V_149 = L_1781;
		int32_t L_1782 = V_149;
		V_59 = ((int32_t)il2cpp_codegen_add(L_1782, 1));
	}

IL_32a7:
	{
		int32_t L_1783 = V_59;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1784 = __this->___m_CharBuffer_4;
		NullCheck(L_1784);
		if ((((int32_t)L_1783) >= ((int32_t)((int32_t)(((RuntimeArray*)L_1784)->max_length)))))
		{
			goto IL_32c1;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1785 = __this->___m_CharBuffer_4;
		int32_t L_1786 = V_59;
		NullCheck(L_1785);
		int32_t L_1787 = L_1786;
		int32_t L_1788 = (L_1785)->GetAt(static_cast<il2cpp_array_size_t>(L_1787));
		G_B502_0 = ((!(((uint32_t)L_1788) <= ((uint32_t)0)))? 1 : 0);
		goto IL_32c2;
	}

IL_32c1:
	{
		G_B502_0 = 0;
	}

IL_32c2:
	{
		V_231 = (bool)G_B502_0;
		bool L_1789 = V_231;
		if (L_1789)
		{
			goto IL_0496;
		}
	}
	{
		float L_1790 = __this->___m_MaxFontSize_79;
		float L_1791 = __this->___m_MinFontSize_80;
		V_32 = ((float)il2cpp_codegen_subtract(L_1790, L_1791));
		bool L_1792 = __this->___m_IsCharacterWrappingEnabled_81;
		if (L_1792)
		{
			goto IL_3303;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1793 = ___generationSettings0;
		NullCheck(L_1793);
		bool L_1794 = L_1793->___autoSize_19;
		if (!L_1794)
		{
			goto IL_3303;
		}
	}
	{
		float L_1795 = V_32;
		if ((!(((float)L_1795) > ((float)(0.050999999f)))))
		{
			goto IL_3303;
		}
	}
	{
		float L_1796 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1797 = ___generationSettings0;
		NullCheck(L_1797);
		float L_1798 = L_1797->___fontSizeMax_21;
		G_B508_0 = ((((float)L_1796) < ((float)L_1798))? 1 : 0);
		goto IL_3304;
	}

IL_3303:
	{
		G_B508_0 = 0;
	}

IL_3304:
	{
		V_232 = (bool)G_B508_0;
		bool L_1799 = V_232;
		if (!L_1799)
		{
			goto IL_3393;
		}
	}
	{
		float L_1800 = __this->___m_FontSize_15;
		__this->___m_MinFontSize_80 = L_1800;
		float L_1801 = __this->___m_FontSize_15;
		float L_1802 = __this->___m_MaxFontSize_79;
		float L_1803 = __this->___m_FontSize_15;
		float L_1804;
		L_1804 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1802, L_1803))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_add(L_1801, L_1804));
		float L_1805 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1806 = ___generationSettings0;
		NullCheck(L_1806);
		float L_1807 = L_1806->___fontSizeMax_21;
		float L_1808;
		L_1808 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1805, L_1807, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1808, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_1809 = __this->___m_LoopCountA_70;
		V_233 = (bool)((((int32_t)L_1809) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_1810 = V_233;
		if (!L_1810)
		{
			goto IL_3385;
		}
	}
	{
		goto IL_6c5c;
	}

IL_3385:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1811 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1812 = ___textInfo1;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1811, L_1812, NULL);
		goto IL_6c5c;
	}

IL_3393:
	{
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)0;
		int32_t L_1813 = __this->___m_CharacterCount_48;
		V_234 = (bool)((((int32_t)L_1813) == ((int32_t)0))? 1 : 0);
		bool L_1814 = V_234;
		if (!L_1814)
		{
			goto IL_33b7;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1815 = ___textInfo1;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_1815, NULL);
		goto IL_6c5c;
	}

IL_33b7:
	{
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1816 = __this->___m_MaterialReferences_85;
		NullCheck(L_1816);
		int32_t L_1817 = ((L_1816)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___referenceCount_8;
		V_33 = ((int32_t)il2cpp_codegen_multiply(L_1817, 4));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1818 = ___textInfo1;
		NullCheck(L_1818);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_1819 = L_1818->___meshInfo_15;
		NullCheck(L_1819);
		MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475(((L_1819)->GetAddressAt(static_cast<il2cpp_array_size_t>(0))), (bool)0, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1820;
		L_1820 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_34 = L_1820;
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1821 = __this->___m_RectTransformCorners_1;
		V_35 = L_1821;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1822 = ___generationSettings0;
		NullCheck(L_1822);
		int32_t L_1823 = L_1822->___textAlignment_10;
		V_236 = L_1823;
		int32_t L_1824 = V_236;
		V_235 = L_1824;
		int32_t L_1825 = V_235;
		if ((((int32_t)L_1825) > ((int32_t)((int32_t)1056))))
		{
			goto IL_352c;
		}
	}
	{
		int32_t L_1826 = V_235;
		if ((((int32_t)L_1826) > ((int32_t)((int32_t)516))))
		{
			goto IL_3493;
		}
	}
	{
		int32_t L_1827 = V_235;
		if ((((int32_t)L_1827) > ((int32_t)((int32_t)264))))
		{
			goto IL_344a;
		}
	}
	{
		int32_t L_1828 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1828, ((int32_t)257)))) > ((uint32_t)1))))
		{
			goto IL_3652;
		}
	}
	{
		goto IL_342b;
	}

IL_342b:
	{
		int32_t L_1829 = V_235;
		if ((((int32_t)L_1829) == ((int32_t)((int32_t)260))))
		{
			goto IL_3652;
		}
	}
	{
		goto IL_3439;
	}

IL_3439:
	{
		int32_t L_1830 = V_235;
		if ((((int32_t)L_1830) == ((int32_t)((int32_t)264))))
		{
			goto IL_3652;
		}
	}
	{
		goto IL_399d;
	}

IL_344a:
	{
		int32_t L_1831 = V_235;
		if ((((int32_t)L_1831) > ((int32_t)((int32_t)288))))
		{
			goto IL_3472;
		}
	}
	{
		int32_t L_1832 = V_235;
		if ((((int32_t)L_1832) == ((int32_t)((int32_t)272))))
		{
			goto IL_3652;
		}
	}
	{
		goto IL_3461;
	}

IL_3461:
	{
		int32_t L_1833 = V_235;
		if ((((int32_t)L_1833) == ((int32_t)((int32_t)288))))
		{
			goto IL_3652;
		}
	}
	{
		goto IL_399d;
	}

IL_3472:
	{
		int32_t L_1834 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1834, ((int32_t)513)))) > ((uint32_t)1))))
		{
			goto IL_36eb;
		}
	}
	{
		goto IL_3482;
	}

IL_3482:
	{
		int32_t L_1835 = V_235;
		if ((((int32_t)L_1835) == ((int32_t)((int32_t)516))))
		{
			goto IL_36eb;
		}
	}
	{
		goto IL_399d;
	}

IL_3493:
	{
		int32_t L_1836 = V_235;
		if ((((int32_t)L_1836) > ((int32_t)((int32_t)1026))))
		{
			goto IL_34e5;
		}
	}
	{
		int32_t L_1837 = V_235;
		if ((((int32_t)L_1837) > ((int32_t)((int32_t)528))))
		{
			goto IL_34c4;
		}
	}
	{
		int32_t L_1838 = V_235;
		if ((((int32_t)L_1838) == ((int32_t)((int32_t)520))))
		{
			goto IL_36eb;
		}
	}
	{
		goto IL_34b3;
	}

IL_34b3:
	{
		int32_t L_1839 = V_235;
		if ((((int32_t)L_1839) == ((int32_t)((int32_t)528))))
		{
			goto IL_36eb;
		}
	}
	{
		goto IL_399d;
	}

IL_34c4:
	{
		int32_t L_1840 = V_235;
		if ((((int32_t)L_1840) == ((int32_t)((int32_t)544))))
		{
			goto IL_36eb;
		}
	}
	{
		goto IL_34d2;
	}

IL_34d2:
	{
		int32_t L_1841 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1841, ((int32_t)1025)))) > ((uint32_t)1))))
		{
			goto IL_37e4;
		}
	}
	{
		goto IL_399d;
	}

IL_34e5:
	{
		int32_t L_1842 = V_235;
		if ((((int32_t)L_1842) > ((int32_t)((int32_t)1032))))
		{
			goto IL_350d;
		}
	}
	{
		int32_t L_1843 = V_235;
		if ((((int32_t)L_1843) == ((int32_t)((int32_t)1028))))
		{
			goto IL_37e4;
		}
	}
	{
		goto IL_34fc;
	}

IL_34fc:
	{
		int32_t L_1844 = V_235;
		if ((((int32_t)L_1844) == ((int32_t)((int32_t)1032))))
		{
			goto IL_37e4;
		}
	}
	{
		goto IL_399d;
	}

IL_350d:
	{
		int32_t L_1845 = V_235;
		if ((((int32_t)L_1845) == ((int32_t)((int32_t)1040))))
		{
			goto IL_37e4;
		}
	}
	{
		goto IL_351b;
	}

IL_351b:
	{
		int32_t L_1846 = V_235;
		if ((((int32_t)L_1846) == ((int32_t)((int32_t)1056))))
		{
			goto IL_37e4;
		}
	}
	{
		goto IL_399d;
	}

IL_352c:
	{
		int32_t L_1847 = V_235;
		if ((((int32_t)L_1847) > ((int32_t)((int32_t)4100))))
		{
			goto IL_35b9;
		}
	}
	{
		int32_t L_1848 = V_235;
		if ((((int32_t)L_1848) > ((int32_t)((int32_t)2056))))
		{
			goto IL_3570;
		}
	}
	{
		int32_t L_1849 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1849, ((int32_t)2049)))) > ((uint32_t)1))))
		{
			goto IL_3879;
		}
	}
	{
		goto IL_3551;
	}

IL_3551:
	{
		int32_t L_1850 = V_235;
		if ((((int32_t)L_1850) == ((int32_t)((int32_t)2052))))
		{
			goto IL_3879;
		}
	}
	{
		goto IL_355f;
	}

IL_355f:
	{
		int32_t L_1851 = V_235;
		if ((((int32_t)L_1851) == ((int32_t)((int32_t)2056))))
		{
			goto IL_3879;
		}
	}
	{
		goto IL_399d;
	}

IL_3570:
	{
		int32_t L_1852 = V_235;
		if ((((int32_t)L_1852) > ((int32_t)((int32_t)2080))))
		{
			goto IL_3598;
		}
	}
	{
		int32_t L_1853 = V_235;
		if ((((int32_t)L_1853) == ((int32_t)((int32_t)2064))))
		{
			goto IL_3879;
		}
	}
	{
		goto IL_3587;
	}

IL_3587:
	{
		int32_t L_1854 = V_235;
		if ((((int32_t)L_1854) == ((int32_t)((int32_t)2080))))
		{
			goto IL_3879;
		}
	}
	{
		goto IL_399d;
	}

IL_3598:
	{
		int32_t L_1855 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1855, ((int32_t)4097)))) > ((uint32_t)1))))
		{
			goto IL_38c0;
		}
	}
	{
		goto IL_35a8;
	}

IL_35a8:
	{
		int32_t L_1856 = V_235;
		if ((((int32_t)L_1856) == ((int32_t)((int32_t)4100))))
		{
			goto IL_38c0;
		}
	}
	{
		goto IL_399d;
	}

IL_35b9:
	{
		int32_t L_1857 = V_235;
		if ((((int32_t)L_1857) > ((int32_t)((int32_t)8194))))
		{
			goto IL_360b;
		}
	}
	{
		int32_t L_1858 = V_235;
		if ((((int32_t)L_1858) > ((int32_t)((int32_t)4112))))
		{
			goto IL_35ea;
		}
	}
	{
		int32_t L_1859 = V_235;
		if ((((int32_t)L_1859) == ((int32_t)((int32_t)4104))))
		{
			goto IL_38c0;
		}
	}
	{
		goto IL_35d9;
	}

IL_35d9:
	{
		int32_t L_1860 = V_235;
		if ((((int32_t)L_1860) == ((int32_t)((int32_t)4112))))
		{
			goto IL_38c0;
		}
	}
	{
		goto IL_399d;
	}

IL_35ea:
	{
		int32_t L_1861 = V_235;
		if ((((int32_t)L_1861) == ((int32_t)((int32_t)4128))))
		{
			goto IL_38c0;
		}
	}
	{
		goto IL_35f8;
	}

IL_35f8:
	{
		int32_t L_1862 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1862, ((int32_t)8193)))) > ((uint32_t)1))))
		{
			goto IL_393c;
		}
	}
	{
		goto IL_399d;
	}

IL_360b:
	{
		int32_t L_1863 = V_235;
		if ((((int32_t)L_1863) > ((int32_t)((int32_t)8200))))
		{
			goto IL_3633;
		}
	}
	{
		int32_t L_1864 = V_235;
		if ((((int32_t)L_1864) == ((int32_t)((int32_t)8196))))
		{
			goto IL_393c;
		}
	}
	{
		goto IL_3622;
	}

IL_3622:
	{
		int32_t L_1865 = V_235;
		if ((((int32_t)L_1865) == ((int32_t)((int32_t)8200))))
		{
			goto IL_393c;
		}
	}
	{
		goto IL_399d;
	}

IL_3633:
	{
		int32_t L_1866 = V_235;
		if ((((int32_t)L_1866) == ((int32_t)((int32_t)8208))))
		{
			goto IL_393c;
		}
	}
	{
		goto IL_3641;
	}

IL_3641:
	{
		int32_t L_1867 = V_235;
		if ((((int32_t)L_1867) == ((int32_t)((int32_t)8224))))
		{
			goto IL_393c;
		}
	}
	{
		goto IL_399d;
	}

IL_3652:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1868 = ___generationSettings0;
		NullCheck(L_1868);
		int32_t L_1869 = L_1868->___overflowMode_11;
		V_237 = (bool)((((int32_t)((((int32_t)L_1869) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1870 = V_237;
		if (!L_1870)
		{
			goto IL_36a0;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1871 = V_35;
		NullCheck(L_1871);
		int32_t L_1872 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1873 = (L_1871)->GetAt(static_cast<il2cpp_array_size_t>(L_1872));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1874 = V_19;
		float L_1875 = L_1874.___x_1;
		float L_1876 = __this->___m_MaxAscender_64;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1877 = V_19;
		float L_1878 = L_1877.___y_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1879;
		memset((&L_1879), 0, sizeof(L_1879));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1879), ((float)il2cpp_codegen_add((0.0f), L_1875)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract((0.0f), L_1876)), L_1878)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1880;
		L_1880 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1873, L_1879, NULL);
		V_34 = L_1880;
		goto IL_36e6;
	}

IL_36a0:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1881 = V_35;
		NullCheck(L_1881);
		int32_t L_1882 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1883 = (L_1881)->GetAt(static_cast<il2cpp_array_size_t>(L_1882));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1884 = V_19;
		float L_1885 = L_1884.___x_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1886 = ___textInfo1;
		NullCheck(L_1886);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1887 = L_1886->___pageInfo_14;
		int32_t L_1888 = V_16;
		NullCheck(L_1887);
		float L_1889 = ((L_1887)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1888)))->___ascender_2;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1890 = V_19;
		float L_1891 = L_1890.___y_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1892;
		memset((&L_1892), 0, sizeof(L_1892));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1892), ((float)il2cpp_codegen_add((0.0f), L_1885)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract((0.0f), L_1889)), L_1891)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1893;
		L_1893 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1883, L_1892, NULL);
		V_34 = L_1893;
	}

IL_36e6:
	{
		goto IL_399d;
	}

IL_36eb:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1894 = ___generationSettings0;
		NullCheck(L_1894);
		int32_t L_1895 = L_1894->___overflowMode_11;
		V_238 = (bool)((((int32_t)((((int32_t)L_1895) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1896 = V_238;
		if (!L_1896)
		{
			goto IL_3761;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1897 = V_35;
		NullCheck(L_1897);
		int32_t L_1898 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1899 = (L_1897)->GetAt(static_cast<il2cpp_array_size_t>(L_1898));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1900 = V_35;
		NullCheck(L_1900);
		int32_t L_1901 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1902 = (L_1900)->GetAt(static_cast<il2cpp_array_size_t>(L_1901));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1903;
		L_1903 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1899, L_1902, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1904;
		L_1904 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1903, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1905 = V_19;
		float L_1906 = L_1905.___x_1;
		float L_1907 = __this->___m_MaxAscender_64;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1908 = V_19;
		float L_1909 = L_1908.___y_2;
		float L_1910 = V_25;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1911 = V_19;
		float L_1912 = L_1911.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1913;
		memset((&L_1913), 0, sizeof(L_1913));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1913), ((float)il2cpp_codegen_add((0.0f), L_1906)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1907, L_1909)), L_1910)), L_1912))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1914;
		L_1914 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1904, L_1913, NULL);
		V_34 = L_1914;
		goto IL_37df;
	}

IL_3761:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1915 = V_35;
		NullCheck(L_1915);
		int32_t L_1916 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1917 = (L_1915)->GetAt(static_cast<il2cpp_array_size_t>(L_1916));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1918 = V_35;
		NullCheck(L_1918);
		int32_t L_1919 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1920 = (L_1918)->GetAt(static_cast<il2cpp_array_size_t>(L_1919));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1921;
		L_1921 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1917, L_1920, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1922;
		L_1922 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1921, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1923 = V_19;
		float L_1924 = L_1923.___x_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1925 = ___textInfo1;
		NullCheck(L_1925);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1926 = L_1925->___pageInfo_14;
		int32_t L_1927 = V_16;
		NullCheck(L_1926);
		float L_1928 = ((L_1926)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1927)))->___ascender_2;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1929 = V_19;
		float L_1930 = L_1929.___y_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1931 = ___textInfo1;
		NullCheck(L_1931);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1932 = L_1931->___pageInfo_14;
		int32_t L_1933 = V_16;
		NullCheck(L_1932);
		float L_1934 = ((L_1932)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1933)))->___descender_4;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1935 = V_19;
		float L_1936 = L_1935.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1937;
		memset((&L_1937), 0, sizeof(L_1937));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1937), ((float)il2cpp_codegen_add((0.0f), L_1924)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1928, L_1930)), L_1934)), L_1936))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1938;
		L_1938 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1922, L_1937, NULL);
		V_34 = L_1938;
	}

IL_37df:
	{
		goto IL_399d;
	}

IL_37e4:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1939 = ___generationSettings0;
		NullCheck(L_1939);
		int32_t L_1940 = L_1939->___overflowMode_11;
		V_239 = (bool)((((int32_t)((((int32_t)L_1940) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1941 = V_239;
		if (!L_1941)
		{
			goto IL_382e;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1942 = V_35;
		NullCheck(L_1942);
		int32_t L_1943 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1944 = (L_1942)->GetAt(static_cast<il2cpp_array_size_t>(L_1943));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1945 = V_19;
		float L_1946 = L_1945.___x_1;
		float L_1947 = V_25;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1948 = V_19;
		float L_1949 = L_1948.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1950;
		memset((&L_1950), 0, sizeof(L_1950));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1950), ((float)il2cpp_codegen_add((0.0f), L_1946)), ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_1947)), L_1949)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1951;
		L_1951 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1944, L_1950, NULL);
		V_34 = L_1951;
		goto IL_3874;
	}

IL_382e:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1952 = V_35;
		NullCheck(L_1952);
		int32_t L_1953 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1954 = (L_1952)->GetAt(static_cast<il2cpp_array_size_t>(L_1953));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1955 = V_19;
		float L_1956 = L_1955.___x_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1957 = ___textInfo1;
		NullCheck(L_1957);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1958 = L_1957->___pageInfo_14;
		int32_t L_1959 = V_16;
		NullCheck(L_1958);
		float L_1960 = ((L_1958)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1959)))->___descender_4;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1961 = V_19;
		float L_1962 = L_1961.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1963;
		memset((&L_1963), 0, sizeof(L_1963));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1963), ((float)il2cpp_codegen_add((0.0f), L_1956)), ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_1960)), L_1962)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1964;
		L_1964 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1954, L_1963, NULL);
		V_34 = L_1964;
	}

IL_3874:
	{
		goto IL_399d;
	}

IL_3879:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1965 = V_35;
		NullCheck(L_1965);
		int32_t L_1966 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1967 = (L_1965)->GetAt(static_cast<il2cpp_array_size_t>(L_1966));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1968 = V_35;
		NullCheck(L_1968);
		int32_t L_1969 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1970 = (L_1968)->GetAt(static_cast<il2cpp_array_size_t>(L_1969));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1971;
		L_1971 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1967, L_1970, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1972;
		L_1972 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1971, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1973 = V_19;
		float L_1974 = L_1973.___x_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1975;
		memset((&L_1975), 0, sizeof(L_1975));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1975), ((float)il2cpp_codegen_add((0.0f), L_1974)), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1976;
		L_1976 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1972, L_1975, NULL);
		V_34 = L_1976;
		goto IL_399d;
	}

IL_38c0:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1977 = V_35;
		NullCheck(L_1977);
		int32_t L_1978 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1979 = (L_1977)->GetAt(static_cast<il2cpp_array_size_t>(L_1978));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1980 = V_35;
		NullCheck(L_1980);
		int32_t L_1981 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1982 = (L_1980)->GetAt(static_cast<il2cpp_array_size_t>(L_1981));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1983;
		L_1983 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1979, L_1982, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1984;
		L_1984 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1983, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1985 = V_19;
		float L_1986 = L_1985.___x_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1987 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1988 = (&L_1987->___max_1);
		float L_1989 = L_1988->___y_1;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1990 = V_19;
		float L_1991 = L_1990.___y_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1992 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1993 = (&L_1992->___min_0);
		float L_1994 = L_1993->___y_1;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1995 = V_19;
		float L_1996 = L_1995.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1997;
		memset((&L_1997), 0, sizeof(L_1997));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1997), ((float)il2cpp_codegen_add((0.0f), L_1986)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1989, L_1991)), L_1994)), L_1996))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1998;
		L_1998 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1984, L_1997, NULL);
		V_34 = L_1998;
		goto IL_399d;
	}

IL_393c:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1999 = V_35;
		NullCheck(L_1999);
		int32_t L_2000 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2001 = (L_1999)->GetAt(static_cast<il2cpp_array_size_t>(L_2000));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2002 = V_35;
		NullCheck(L_2002);
		int32_t L_2003 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2004 = (L_2002)->GetAt(static_cast<il2cpp_array_size_t>(L_2003));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2005;
		L_2005 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2001, L_2004, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2006;
		L_2006 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2005, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2007 = V_19;
		float L_2008 = L_2007.___x_1;
		float L_2009 = __this->___m_MaxCapHeight_63;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2010 = V_19;
		float L_2011 = L_2010.___y_2;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2012 = V_19;
		float L_2013 = L_2012.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2014;
		memset((&L_2014), 0, sizeof(L_2014));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2014), ((float)il2cpp_codegen_add((0.0f), L_2008)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_2009, L_2011)), L_2013))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2015;
		L_2015 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2006, L_2014, NULL);
		V_34 = L_2015;
		goto IL_399d;
	}

IL_399d:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2016;
		L_2016 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_36 = L_2016;
		V_37 = 0;
		V_38 = 0;
		V_39 = 0;
		V_40 = (bool)0;
		V_41 = (bool)0;
		V_42 = 0;
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_2017;
		L_2017 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2018;
		L_2018 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_2017, NULL);
		V_43 = L_2018;
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_2019;
		L_2019 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2020;
		L_2020 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_2019, NULL);
		V_44 = L_2020;
		Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline((&V_45), (uint8_t)((int32_t)255), (uint8_t)((int32_t)255), (uint8_t)0, (uint8_t)((int32_t)64), NULL);
		V_46 = (0.0f);
		V_47 = (0.0f);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		V_50 = 0;
		V_51 = (0.0f);
		V_52 = (0.0f);
		V_53 = (0.0f);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2021 = ___textInfo1;
		NullCheck(L_2021);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2022 = L_2021->___textElementInfo_10;
		V_54 = L_2022;
		V_240 = 0;
		goto IL_6b35;
	}

IL_3a26:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2023 = V_54;
		int32_t L_2024 = V_240;
		NullCheck(L_2023);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_2025 = ((L_2023)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2024)))->___fontAsset_4;
		V_241 = L_2025;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2026 = V_54;
		int32_t L_2027 = V_240;
		NullCheck(L_2026);
		Il2CppChar L_2028 = ((L_2026)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2027)))->___character_0;
		V_242 = L_2028;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2029 = V_54;
		int32_t L_2030 = V_240;
		NullCheck(L_2029);
		int32_t L_2031 = ((L_2029)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2030)))->___lineNumber_11;
		V_243 = L_2031;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2032 = ___textInfo1;
		NullCheck(L_2032);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2033 = L_2032->___lineInfo_13;
		int32_t L_2034 = V_243;
		NullCheck(L_2033);
		int32_t L_2035 = L_2034;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2036 = (L_2033)->GetAt(static_cast<il2cpp_array_size_t>(L_2035));
		V_244 = L_2036;
		int32_t L_2037 = V_243;
		V_38 = ((int32_t)il2cpp_codegen_add(L_2037, 1));
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2038 = V_244;
		int32_t L_2039 = L_2038.___alignment_19;
		V_245 = L_2039;
		int32_t L_2040 = V_245;
		V_257 = L_2040;
		int32_t L_2041 = V_257;
		V_256 = L_2041;
		int32_t L_2042 = V_256;
		if ((((int32_t)L_2042) > ((int32_t)((int32_t)1056))))
		{
			goto IL_3bda;
		}
	}
	{
		int32_t L_2043 = V_256;
		if ((((int32_t)L_2043) > ((int32_t)((int32_t)520))))
		{
			goto IL_3b4a;
		}
	}
	{
		int32_t L_2044 = V_256;
		if ((((int32_t)L_2044) > ((int32_t)((int32_t)272))))
		{
			goto IL_3b00;
		}
	}
	{
		int32_t L_2045 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2045, ((int32_t)257))))
		{
			case 0:
			{
				goto IL_3d1b;
			}
			case 1:
			{
				goto IL_3d75;
			}
			case 2:
			{
				goto IL_41fd;
			}
			case 3:
			{
				goto IL_3e03;
			}
		}
	}
	{
		goto IL_3ad9;
	}

IL_3ad9:
	{
		int32_t L_2046 = V_256;
		if ((((int32_t)L_2046) == ((int32_t)((int32_t)264))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3aeb;
	}

IL_3aeb:
	{
		int32_t L_2047 = V_256;
		if ((((int32_t)L_2047) == ((int32_t)((int32_t)272))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_41fd;
	}

IL_3b00:
	{
		int32_t L_2048 = V_256;
		if ((((int32_t)L_2048) == ((int32_t)((int32_t)288))))
		{
			goto IL_3dae;
		}
	}
	{
		goto IL_3b12;
	}

IL_3b12:
	{
		int32_t L_2049 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2049, ((int32_t)513))))
		{
			case 0:
			{
				goto IL_3d1b;
			}
			case 1:
			{
				goto IL_3d75;
			}
			case 2:
			{
				goto IL_41fd;
			}
			case 3:
			{
				goto IL_3e03;
			}
		}
	}
	{
		goto IL_3b35;
	}

IL_3b35:
	{
		int32_t L_2050 = V_256;
		if ((((int32_t)L_2050) == ((int32_t)((int32_t)520))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_41fd;
	}

IL_3b4a:
	{
		int32_t L_2051 = V_256;
		if ((((int32_t)L_2051) > ((int32_t)((int32_t)1028))))
		{
			goto IL_3ba1;
		}
	}
	{
		int32_t L_2052 = V_256;
		if ((((int32_t)L_2052) == ((int32_t)((int32_t)528))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3b69;
	}

IL_3b69:
	{
		int32_t L_2053 = V_256;
		if ((((int32_t)L_2053) == ((int32_t)((int32_t)544))))
		{
			goto IL_3dae;
		}
	}
	{
		goto IL_3b7b;
	}

IL_3b7b:
	{
		int32_t L_2054 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2054, ((int32_t)1025))))
		{
			case 0:
			{
				goto IL_3d1b;
			}
			case 1:
			{
				goto IL_3d75;
			}
			case 2:
			{
				goto IL_41fd;
			}
			case 3:
			{
				goto IL_3e03;
			}
		}
	}
	{
		goto IL_41fd;
	}

IL_3ba1:
	{
		int32_t L_2055 = V_256;
		if ((((int32_t)L_2055) == ((int32_t)((int32_t)1032))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3bb3;
	}

IL_3bb3:
	{
		int32_t L_2056 = V_256;
		if ((((int32_t)L_2056) == ((int32_t)((int32_t)1040))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3bc5;
	}

IL_3bc5:
	{
		int32_t L_2057 = V_256;
		if ((((int32_t)L_2057) == ((int32_t)((int32_t)1056))))
		{
			goto IL_3dae;
		}
	}
	{
		goto IL_41fd;
	}

IL_3bda:
	{
		int32_t L_2058 = V_256;
		if ((((int32_t)L_2058) > ((int32_t)((int32_t)4104))))
		{
			goto IL_3c8b;
		}
	}
	{
		int32_t L_2059 = V_256;
		if ((((int32_t)L_2059) > ((int32_t)((int32_t)2064))))
		{
			goto IL_3c41;
		}
	}
	{
		int32_t L_2060 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2060, ((int32_t)2049))))
		{
			case 0:
			{
				goto IL_3d1b;
			}
			case 1:
			{
				goto IL_3d75;
			}
			case 2:
			{
				goto IL_41fd;
			}
			case 3:
			{
				goto IL_3e03;
			}
		}
	}
	{
		goto IL_3c1a;
	}

IL_3c1a:
	{
		int32_t L_2061 = V_256;
		if ((((int32_t)L_2061) == ((int32_t)((int32_t)2056))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3c2c;
	}

IL_3c2c:
	{
		int32_t L_2062 = V_256;
		if ((((int32_t)L_2062) == ((int32_t)((int32_t)2064))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_41fd;
	}

IL_3c41:
	{
		int32_t L_2063 = V_256;
		if ((((int32_t)L_2063) == ((int32_t)((int32_t)2080))))
		{
			goto IL_3dae;
		}
	}
	{
		goto IL_3c53;
	}

IL_3c53:
	{
		int32_t L_2064 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2064, ((int32_t)4097))))
		{
			case 0:
			{
				goto IL_3d1b;
			}
			case 1:
			{
				goto IL_3d75;
			}
			case 2:
			{
				goto IL_41fd;
			}
			case 3:
			{
				goto IL_3e03;
			}
		}
	}
	{
		goto IL_3c76;
	}

IL_3c76:
	{
		int32_t L_2065 = V_256;
		if ((((int32_t)L_2065) == ((int32_t)((int32_t)4104))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_41fd;
	}

IL_3c8b:
	{
		int32_t L_2066 = V_256;
		if ((((int32_t)L_2066) > ((int32_t)((int32_t)8196))))
		{
			goto IL_3ce2;
		}
	}
	{
		int32_t L_2067 = V_256;
		if ((((int32_t)L_2067) == ((int32_t)((int32_t)4112))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3caa;
	}

IL_3caa:
	{
		int32_t L_2068 = V_256;
		if ((((int32_t)L_2068) == ((int32_t)((int32_t)4128))))
		{
			goto IL_3dae;
		}
	}
	{
		goto IL_3cbc;
	}

IL_3cbc:
	{
		int32_t L_2069 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2069, ((int32_t)8193))))
		{
			case 0:
			{
				goto IL_3d1b;
			}
			case 1:
			{
				goto IL_3d75;
			}
			case 2:
			{
				goto IL_41fd;
			}
			case 3:
			{
				goto IL_3e03;
			}
		}
	}
	{
		goto IL_41fd;
	}

IL_3ce2:
	{
		int32_t L_2070 = V_256;
		if ((((int32_t)L_2070) == ((int32_t)((int32_t)8200))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3cf4;
	}

IL_3cf4:
	{
		int32_t L_2071 = V_256;
		if ((((int32_t)L_2071) == ((int32_t)((int32_t)8208))))
		{
			goto IL_3e69;
		}
	}
	{
		goto IL_3d06;
	}

IL_3d06:
	{
		int32_t L_2072 = V_256;
		if ((((int32_t)L_2072) == ((int32_t)((int32_t)8224))))
		{
			goto IL_3dae;
		}
	}
	{
		goto IL_41fd;
	}

IL_3d1b:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2073 = ___generationSettings0;
		NullCheck(L_2073);
		bool L_2074 = L_2073->___isRightToLeft_24;
		V_258 = (bool)((((int32_t)L_2074) == ((int32_t)0))? 1 : 0);
		bool L_2075 = V_258;
		if (!L_2075)
		{
			goto IL_3d52;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2076 = V_244;
		float L_2077 = L_2076.___marginLeft_17;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add((0.0f), L_2077)), (0.0f), (0.0f), NULL);
		goto IL_3d70;
	}

IL_3d52:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2078 = V_244;
		float L_2079 = L_2078.___maxAdvance_15;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract((0.0f), L_2079)), (0.0f), (0.0f), NULL);
	}

IL_3d70:
	{
		goto IL_41fd;
	}

IL_3d75:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2080 = V_244;
		float L_2081 = L_2080.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2082 = V_244;
		float L_2083 = L_2082.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2084 = V_244;
		float L_2085 = L_2084.___maxAdvance_15;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2081, ((float)(L_2083/(2.0f))))), ((float)(L_2085/(2.0f))))), (0.0f), (0.0f), NULL);
		goto IL_41fd;
	}

IL_3dae:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2086 = V_244;
		float L_2087 = L_2086.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2088 = V_244;
		float L_2089 = L_2088.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2090 = V_244;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2091 = L_2090.___lineExtents_20;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2092 = L_2091.___min_0;
		float L_2093 = L_2092.___x_0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2094 = V_244;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2095 = L_2094.___lineExtents_20;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2096 = L_2095.___max_1;
		float L_2097 = L_2096.___x_0;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2087, ((float)(L_2089/(2.0f))))), ((float)(((float)il2cpp_codegen_add(L_2093, L_2097))/(2.0f))))), (0.0f), (0.0f), NULL);
		goto IL_41fd;
	}

IL_3e03:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2098 = ___generationSettings0;
		NullCheck(L_2098);
		bool L_2099 = L_2098->___isRightToLeft_24;
		V_259 = (bool)((((int32_t)L_2099) == ((int32_t)0))? 1 : 0);
		bool L_2100 = V_259;
		if (!L_2100)
		{
			goto IL_3e44;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2101 = V_244;
		float L_2102 = L_2101.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2103 = V_244;
		float L_2104 = L_2103.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2105 = V_244;
		float L_2106 = L_2105.___maxAdvance_15;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2102, L_2104)), L_2106)), (0.0f), (0.0f), NULL);
		goto IL_3e64;
	}

IL_3e44:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2107 = V_244;
		float L_2108 = L_2107.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2109 = V_244;
		float L_2110 = L_2109.___width_16;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add(L_2108, L_2110)), (0.0f), (0.0f), NULL);
	}

IL_3e64:
	{
		goto IL_41fd;
	}

IL_3e69:
	{
		Il2CppChar L_2111 = V_242;
		if ((((int32_t)L_2111) == ((int32_t)((int32_t)173))))
		{
			goto IL_3e86;
		}
	}
	{
		Il2CppChar L_2112 = V_242;
		if ((((int32_t)L_2112) == ((int32_t)((int32_t)8203))))
		{
			goto IL_3e86;
		}
	}
	{
		Il2CppChar L_2113 = V_242;
		G_B672_0 = ((((int32_t)L_2113) == ((int32_t)((int32_t)8288)))? 1 : 0);
		goto IL_3e87;
	}

IL_3e86:
	{
		G_B672_0 = 1;
	}

IL_3e87:
	{
		V_260 = (bool)G_B672_0;
		bool L_2114 = V_260;
		if (!L_2114)
		{
			goto IL_3e9a;
		}
	}
	{
		goto IL_41fd;
	}

IL_3e9a:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2115 = V_54;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2116 = V_244;
		int32_t L_2117 = L_2116.___lastCharacterIndex_8;
		NullCheck(L_2115);
		Il2CppChar L_2118 = ((L_2115)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2117)))->___character_0;
		V_254 = L_2118;
		int32_t L_2119 = V_245;
		V_255 = (bool)((((int32_t)((int32_t)((int32_t)L_2119&((int32_t)16)))) == ((int32_t)((int32_t)16)))? 1 : 0);
		Il2CppChar L_2120 = V_254;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2121;
		L_2121 = Char_IsControl_m133C10360BE82B7580E4D3ECE3C881A6C82B3F7F(L_2120, NULL);
		if (L_2121)
		{
			goto IL_3ed3;
		}
	}
	{
		int32_t L_2122 = V_243;
		int32_t L_2123 = __this->___m_LineNumber_55;
		G_B677_0 = ((((int32_t)L_2122) < ((int32_t)L_2123))? 1 : 0);
		goto IL_3ed4;
	}

IL_3ed3:
	{
		G_B677_0 = 0;
	}

IL_3ed4:
	{
		bool L_2124 = V_255;
		if (((int32_t)(G_B677_0|(int32_t)L_2124)))
		{
			goto IL_3eef;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2125 = V_244;
		float L_2126 = L_2125.___maxAdvance_15;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2127 = V_244;
		float L_2128 = L_2127.___width_16;
		G_B680_0 = ((((float)L_2126) > ((float)L_2128))? 1 : 0);
		goto IL_3ef0;
	}

IL_3eef:
	{
		G_B680_0 = 1;
	}

IL_3ef0:
	{
		V_261 = (bool)G_B680_0;
		bool L_2129 = V_261;
		if (!L_2129)
		{
			goto IL_41a8;
		}
	}
	{
		int32_t L_2130 = V_243;
		int32_t L_2131 = V_39;
		if ((!(((uint32_t)L_2130) == ((uint32_t)L_2131))))
		{
			goto IL_3f18;
		}
	}
	{
		int32_t L_2132 = V_240;
		if (!L_2132)
		{
			goto IL_3f18;
		}
	}
	{
		int32_t L_2133 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2134 = ___generationSettings0;
		NullCheck(L_2134);
		int32_t L_2135 = L_2134->___firstVisibleCharacter_35;
		G_B685_0 = ((((int32_t)L_2133) == ((int32_t)L_2135))? 1 : 0);
		goto IL_3f19;
	}

IL_3f18:
	{
		G_B685_0 = 1;
	}

IL_3f19:
	{
		V_262 = (bool)G_B685_0;
		bool L_2136 = V_262;
		if (!L_2136)
		{
			goto IL_3f9c;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2137 = ___generationSettings0;
		NullCheck(L_2137);
		bool L_2138 = L_2137->___isRightToLeft_24;
		V_263 = (bool)((((int32_t)L_2138) == ((int32_t)0))? 1 : 0);
		bool L_2139 = V_263;
		if (!L_2139)
		{
			goto IL_3f59;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2140 = V_244;
		float L_2141 = L_2140.___marginLeft_17;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), L_2141, (0.0f), (0.0f), NULL);
		goto IL_3f79;
	}

IL_3f59:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2142 = V_244;
		float L_2143 = L_2142.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2144 = V_244;
		float L_2145 = L_2144.___width_16;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add(L_2143, L_2145)), (0.0f), (0.0f), NULL);
	}

IL_3f79:
	{
		Il2CppChar L_2146 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2147;
		L_2147 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_2146, NULL);
		V_264 = L_2147;
		bool L_2148 = V_264;
		if (!L_2148)
		{
			goto IL_3f93;
		}
	}
	{
		V_40 = (bool)1;
		goto IL_3f96;
	}

IL_3f93:
	{
		V_40 = (bool)0;
	}

IL_3f96:
	{
		goto IL_41a5;
	}

IL_3f9c:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2149 = ___generationSettings0;
		NullCheck(L_2149);
		bool L_2150 = L_2149->___isRightToLeft_24;
		if (!L_2150)
		{
			goto IL_3fb6;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2151 = V_244;
		float L_2152 = L_2151.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2153 = V_244;
		float L_2154 = L_2153.___maxAdvance_15;
		G_B696_0 = ((float)il2cpp_codegen_add(L_2152, L_2154));
		goto IL_3fc5;
	}

IL_3fb6:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2155 = V_244;
		float L_2156 = L_2155.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2157 = V_244;
		float L_2158 = L_2157.___maxAdvance_15;
		G_B696_0 = ((float)il2cpp_codegen_subtract(L_2156, L_2158));
	}

IL_3fc5:
	{
		V_265 = G_B696_0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2159 = V_244;
		int32_t L_2160 = L_2159.___visibleCharacterCount_2;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2161 = V_244;
		int32_t L_2162 = L_2161.___controlCharacterCount_0;
		V_266 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_2160, 1)), L_2162));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2163 = V_54;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2164 = V_244;
		int32_t L_2165 = L_2164.___lastCharacterIndex_8;
		NullCheck(L_2163);
		bool L_2166 = ((L_2163)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2165)))->___isVisible_34;
		if (L_2166)
		{
			goto IL_4002;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2167 = V_244;
		int32_t L_2168 = L_2167.___spaceCount_3;
		G_B699_0 = ((int32_t)il2cpp_codegen_subtract(L_2168, 1));
		goto IL_4009;
	}

IL_4002:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2169 = V_244;
		int32_t L_2170 = L_2169.___spaceCount_3;
		G_B699_0 = L_2170;
	}

IL_4009:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2171 = V_244;
		int32_t L_2172 = L_2171.___controlCharacterCount_0;
		V_267 = ((int32_t)il2cpp_codegen_subtract(G_B699_0, L_2172));
		bool L_2173 = V_40;
		V_269 = L_2173;
		bool L_2174 = V_269;
		if (!L_2174)
		{
			goto IL_4045;
		}
	}
	{
		int32_t L_2175 = V_267;
		V_267 = ((int32_t)il2cpp_codegen_subtract(L_2175, 1));
		int32_t L_2176 = V_266;
		V_266 = ((int32_t)il2cpp_codegen_add(L_2176, 1));
	}

IL_4045:
	{
		int32_t L_2177 = V_267;
		if ((((int32_t)L_2177) > ((int32_t)0)))
		{
			goto IL_4055;
		}
	}
	{
		G_B704_0 = (1.0f);
		goto IL_405b;
	}

IL_4055:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2178 = ___generationSettings0;
		NullCheck(L_2178);
		float L_2179 = L_2178->___wordWrappingRatio_13;
		G_B704_0 = L_2179;
	}

IL_405b:
	{
		V_268 = G_B704_0;
		int32_t L_2180 = V_267;
		V_270 = (bool)((((int32_t)L_2180) < ((int32_t)1))? 1 : 0);
		bool L_2181 = V_270;
		if (!L_2181)
		{
			goto IL_407f;
		}
	}
	{
		V_267 = 1;
	}

IL_407f:
	{
		Il2CppChar L_2182 = V_242;
		if ((((int32_t)L_2182) == ((int32_t)((int32_t)160))))
		{
			goto IL_409a;
		}
	}
	{
		Il2CppChar L_2183 = V_242;
		if ((((int32_t)L_2183) == ((int32_t)((int32_t)9))))
		{
			goto IL_4097;
		}
	}
	{
		Il2CppChar L_2184 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2185;
		L_2185 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_2184, NULL);
		G_B710_0 = ((int32_t)(L_2185));
		goto IL_4098;
	}

IL_4097:
	{
		G_B710_0 = 1;
	}

IL_4098:
	{
		G_B712_0 = G_B710_0;
		goto IL_409b;
	}

IL_409a:
	{
		G_B712_0 = 0;
	}

IL_409b:
	{
		V_271 = (bool)G_B712_0;
		bool L_2186 = V_271;
		if (!L_2186)
		{
			goto IL_412f;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2187 = ___generationSettings0;
		NullCheck(L_2187);
		bool L_2188 = L_2187->___isRightToLeft_24;
		V_272 = (bool)((((int32_t)L_2188) == ((int32_t)0))? 1 : 0);
		bool L_2189 = V_272;
		if (!L_2189)
		{
			goto IL_40f9;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2190 = V_36;
		float L_2191 = V_265;
		float L_2192 = V_268;
		int32_t L_2193 = V_267;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2194;
		memset((&L_2194), 0, sizeof(L_2194));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2194), ((float)(((float)il2cpp_codegen_multiply(L_2191, ((float)il2cpp_codegen_subtract((1.0f), L_2192))))/((float)L_2193))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2195;
		L_2195 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2190, L_2194, NULL);
		V_36 = L_2195;
		goto IL_412c;
	}

IL_40f9:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2196 = V_36;
		float L_2197 = V_265;
		float L_2198 = V_268;
		int32_t L_2199 = V_267;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2200;
		memset((&L_2200), 0, sizeof(L_2200));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2200), ((float)(((float)il2cpp_codegen_multiply(L_2197, ((float)il2cpp_codegen_subtract((1.0f), L_2198))))/((float)L_2199))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2201;
		L_2201 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_2196, L_2200, NULL);
		V_36 = L_2201;
	}

IL_412c:
	{
		goto IL_41a4;
	}

IL_412f:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2202 = ___generationSettings0;
		NullCheck(L_2202);
		bool L_2203 = L_2202->___isRightToLeft_24;
		V_273 = (bool)((((int32_t)L_2203) == ((int32_t)0))? 1 : 0);
		bool L_2204 = V_273;
		if (!L_2204)
		{
			goto IL_4176;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2205 = V_36;
		float L_2206 = V_265;
		float L_2207 = V_268;
		int32_t L_2208 = V_266;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2209;
		memset((&L_2209), 0, sizeof(L_2209));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2209), ((float)(((float)il2cpp_codegen_multiply(L_2206, L_2207))/((float)L_2208))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2210;
		L_2210 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2205, L_2209, NULL);
		V_36 = L_2210;
		goto IL_41a3;
	}

IL_4176:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2211 = V_36;
		float L_2212 = V_265;
		float L_2213 = V_268;
		int32_t L_2214 = V_266;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2215;
		memset((&L_2215), 0, sizeof(L_2215));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2215), ((float)(((float)il2cpp_codegen_multiply(L_2212, L_2213))/((float)L_2214))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2216;
		L_2216 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_2211, L_2215, NULL);
		V_36 = L_2216;
	}

IL_41a3:
	{
	}

IL_41a4:
	{
	}

IL_41a5:
	{
		goto IL_41fb;
	}

IL_41a8:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2217 = ___generationSettings0;
		NullCheck(L_2217);
		bool L_2218 = L_2217->___isRightToLeft_24;
		V_274 = (bool)((((int32_t)L_2218) == ((int32_t)0))? 1 : 0);
		bool L_2219 = V_274;
		if (!L_2219)
		{
			goto IL_41da;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2220 = V_244;
		float L_2221 = L_2220.___marginLeft_17;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), L_2221, (0.0f), (0.0f), NULL);
		goto IL_41fa;
	}

IL_41da:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2222 = V_244;
		float L_2223 = L_2222.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2224 = V_244;
		float L_2225 = L_2224.___width_16;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add(L_2223, L_2225)), (0.0f), (0.0f), NULL);
	}

IL_41fa:
	{
	}

IL_41fb:
	{
		goto IL_41fd;
	}

IL_41fd:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2226 = V_34;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2227 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2228;
		L_2228 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2226, L_2227, NULL);
		V_246 = L_2228;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2229 = V_54;
		int32_t L_2230 = V_240;
		NullCheck(L_2229);
		bool L_2231 = ((L_2229)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2230)))->___isVisible_34;
		V_247 = L_2231;
		bool L_2232 = V_247;
		V_275 = L_2232;
		bool L_2233 = V_275;
		if (!L_2233)
		{
			goto IL_557f;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2234 = V_54;
		int32_t L_2235 = V_240;
		NullCheck(L_2234);
		uint8_t L_2236 = ((L_2234)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2235)))->___elementType_2;
		V_276 = L_2236;
		uint8_t L_2237 = V_276;
		V_280 = L_2237;
		uint8_t L_2238 = V_280;
		V_279 = L_2238;
		uint8_t L_2239 = V_279;
		if ((((int32_t)L_2239) == ((int32_t)1)))
		{
			goto IL_4274;
		}
	}
	{
		goto IL_4263;
	}

IL_4263:
	{
		uint8_t L_2240 = V_279;
		if ((((int32_t)L_2240) == ((int32_t)2)))
		{
			goto IL_527d;
		}
	}
	{
		goto IL_527f;
	}

IL_4274:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2241 = V_244;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2242 = L_2241.___lineExtents_20;
		V_277 = L_2242;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2243 = ___generationSettings0;
		NullCheck(L_2243);
		float L_2244 = L_2243->___uvLineOffset_41;
		int32_t L_2245 = V_243;
		V_278 = (fmodf(((float)il2cpp_codegen_multiply(L_2244, ((float)L_2245))), (1.0f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2246 = ___generationSettings0;
		NullCheck(L_2246);
		int32_t L_2247 = L_2246->___horizontalMapping_39;
		V_283 = L_2247;
		int32_t L_2248 = V_283;
		V_282 = L_2248;
		int32_t L_2249 = V_282;
		switch (L_2249)
		{
			case 0:
			{
				goto IL_42cf;
			}
			case 1:
			{
				goto IL_4348;
			}
			case 2:
			{
				goto IL_46e5;
			}
			case 3:
			{
				goto IL_48b2;
			}
		}
	}
	{
		goto IL_4d2d;
	}

IL_42cf:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2250 = V_54;
		int32_t L_2251 = V_240;
		NullCheck(L_2250);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2252 = (&((L_2250)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2251)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2253 = (&L_2252->___uv2_2);
		L_2253->___x_0 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2254 = V_54;
		int32_t L_2255 = V_240;
		NullCheck(L_2254);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2256 = (&((L_2254)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2255)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2257 = (&L_2256->___uv2_2);
		L_2257->___x_0 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2258 = V_54;
		int32_t L_2259 = V_240;
		NullCheck(L_2258);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2260 = (&((L_2258)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2259)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2261 = (&L_2260->___uv2_2);
		L_2261->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2262 = V_54;
		int32_t L_2263 = V_240;
		NullCheck(L_2262);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2264 = (&((L_2262)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2263)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2265 = (&L_2264->___uv2_2);
		L_2265->___x_0 = (1.0f);
		goto IL_4d2d;
	}

IL_4348:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2266 = ___generationSettings0;
		NullCheck(L_2266);
		int32_t L_2267 = L_2266->___textAlignment_10;
		V_284 = (bool)((((int32_t)((((int32_t)L_2267) == ((int32_t)((int32_t)520)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2268 = V_284;
		if (!L_2268)
		{
			goto IL_4517;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2269 = V_54;
		int32_t L_2270 = V_240;
		NullCheck(L_2269);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2271 = (&((L_2269)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2270)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2272 = (&L_2271->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2273 = V_54;
		int32_t L_2274 = V_240;
		NullCheck(L_2273);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2275 = (&((L_2273)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2274)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2276 = (&L_2275->___position_0);
		float L_2277 = L_2276->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2278 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2279 = L_2278.___min_0;
		float L_2280 = L_2279.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2281 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2282 = L_2281.___max_1;
		float L_2283 = L_2282.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2284 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2285 = L_2284.___min_0;
		float L_2286 = L_2285.___x_0;
		float L_2287 = V_278;
		L_2272->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2277, L_2280))/((float)il2cpp_codegen_subtract(L_2283, L_2286)))), L_2287));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2288 = V_54;
		int32_t L_2289 = V_240;
		NullCheck(L_2288);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2290 = (&((L_2288)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2289)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2291 = (&L_2290->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2292 = V_54;
		int32_t L_2293 = V_240;
		NullCheck(L_2292);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2294 = (&((L_2292)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2293)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2295 = (&L_2294->___position_0);
		float L_2296 = L_2295->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2297 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2298 = L_2297.___min_0;
		float L_2299 = L_2298.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2300 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2301 = L_2300.___max_1;
		float L_2302 = L_2301.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2303 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2304 = L_2303.___min_0;
		float L_2305 = L_2304.___x_0;
		float L_2306 = V_278;
		L_2291->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2296, L_2299))/((float)il2cpp_codegen_subtract(L_2302, L_2305)))), L_2306));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2307 = V_54;
		int32_t L_2308 = V_240;
		NullCheck(L_2307);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2309 = (&((L_2307)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2308)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2310 = (&L_2309->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2311 = V_54;
		int32_t L_2312 = V_240;
		NullCheck(L_2311);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2313 = (&((L_2311)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2312)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2314 = (&L_2313->___position_0);
		float L_2315 = L_2314->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2316 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2317 = L_2316.___min_0;
		float L_2318 = L_2317.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2319 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2320 = L_2319.___max_1;
		float L_2321 = L_2320.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2322 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2323 = L_2322.___min_0;
		float L_2324 = L_2323.___x_0;
		float L_2325 = V_278;
		L_2310->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2315, L_2318))/((float)il2cpp_codegen_subtract(L_2321, L_2324)))), L_2325));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2326 = V_54;
		int32_t L_2327 = V_240;
		NullCheck(L_2326);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2328 = (&((L_2326)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2327)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2329 = (&L_2328->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2330 = V_54;
		int32_t L_2331 = V_240;
		NullCheck(L_2330);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2332 = (&((L_2330)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2331)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2333 = (&L_2332->___position_0);
		float L_2334 = L_2333->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2335 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2336 = L_2335.___min_0;
		float L_2337 = L_2336.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2338 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2339 = L_2338.___max_1;
		float L_2340 = L_2339.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2341 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2342 = L_2341.___min_0;
		float L_2343 = L_2342.___x_0;
		float L_2344 = V_278;
		L_2329->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2334, L_2337))/((float)il2cpp_codegen_subtract(L_2340, L_2343)))), L_2344));
		goto IL_4d2d;
	}

IL_4517:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2345 = V_54;
		int32_t L_2346 = V_240;
		NullCheck(L_2345);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2347 = (&((L_2345)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2346)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2348 = (&L_2347->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2349 = V_54;
		int32_t L_2350 = V_240;
		NullCheck(L_2349);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2351 = (&((L_2349)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2350)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2352 = (&L_2351->___position_0);
		float L_2353 = L_2352->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2354 = V_36;
		float L_2355 = L_2354.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2356 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2357 = (&L_2356->___min_0);
		float L_2358 = L_2357->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2359 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2360 = (&L_2359->___max_1);
		float L_2361 = L_2360->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2362 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2363 = (&L_2362->___min_0);
		float L_2364 = L_2363->___x_0;
		float L_2365 = V_278;
		L_2348->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2353, L_2355)), L_2358))/((float)il2cpp_codegen_subtract(L_2361, L_2364)))), L_2365));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2366 = V_54;
		int32_t L_2367 = V_240;
		NullCheck(L_2366);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2368 = (&((L_2366)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2367)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2369 = (&L_2368->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2370 = V_54;
		int32_t L_2371 = V_240;
		NullCheck(L_2370);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2372 = (&((L_2370)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2371)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2373 = (&L_2372->___position_0);
		float L_2374 = L_2373->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2375 = V_36;
		float L_2376 = L_2375.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2377 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2378 = (&L_2377->___min_0);
		float L_2379 = L_2378->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2380 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2381 = (&L_2380->___max_1);
		float L_2382 = L_2381->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2383 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2384 = (&L_2383->___min_0);
		float L_2385 = L_2384->___x_0;
		float L_2386 = V_278;
		L_2369->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2374, L_2376)), L_2379))/((float)il2cpp_codegen_subtract(L_2382, L_2385)))), L_2386));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2387 = V_54;
		int32_t L_2388 = V_240;
		NullCheck(L_2387);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2389 = (&((L_2387)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2388)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2390 = (&L_2389->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2391 = V_54;
		int32_t L_2392 = V_240;
		NullCheck(L_2391);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2393 = (&((L_2391)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2392)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2394 = (&L_2393->___position_0);
		float L_2395 = L_2394->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2396 = V_36;
		float L_2397 = L_2396.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2398 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2399 = (&L_2398->___min_0);
		float L_2400 = L_2399->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2401 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2402 = (&L_2401->___max_1);
		float L_2403 = L_2402->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2404 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2405 = (&L_2404->___min_0);
		float L_2406 = L_2405->___x_0;
		float L_2407 = V_278;
		L_2390->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2395, L_2397)), L_2400))/((float)il2cpp_codegen_subtract(L_2403, L_2406)))), L_2407));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2408 = V_54;
		int32_t L_2409 = V_240;
		NullCheck(L_2408);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2410 = (&((L_2408)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2409)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2411 = (&L_2410->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2412 = V_54;
		int32_t L_2413 = V_240;
		NullCheck(L_2412);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2414 = (&((L_2412)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2413)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2415 = (&L_2414->___position_0);
		float L_2416 = L_2415->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2417 = V_36;
		float L_2418 = L_2417.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2419 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2420 = (&L_2419->___min_0);
		float L_2421 = L_2420->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2422 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2423 = (&L_2422->___max_1);
		float L_2424 = L_2423->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2425 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2426 = (&L_2425->___min_0);
		float L_2427 = L_2426->___x_0;
		float L_2428 = V_278;
		L_2411->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2416, L_2418)), L_2421))/((float)il2cpp_codegen_subtract(L_2424, L_2427)))), L_2428));
		goto IL_4d2d;
	}

IL_46e5:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2429 = V_54;
		int32_t L_2430 = V_240;
		NullCheck(L_2429);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2431 = (&((L_2429)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2430)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2432 = (&L_2431->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2433 = V_54;
		int32_t L_2434 = V_240;
		NullCheck(L_2433);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2435 = (&((L_2433)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2434)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2436 = (&L_2435->___position_0);
		float L_2437 = L_2436->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2438 = V_36;
		float L_2439 = L_2438.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2440 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2441 = (&L_2440->___min_0);
		float L_2442 = L_2441->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2443 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2444 = (&L_2443->___max_1);
		float L_2445 = L_2444->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2446 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2447 = (&L_2446->___min_0);
		float L_2448 = L_2447->___x_0;
		float L_2449 = V_278;
		L_2432->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2437, L_2439)), L_2442))/((float)il2cpp_codegen_subtract(L_2445, L_2448)))), L_2449));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2450 = V_54;
		int32_t L_2451 = V_240;
		NullCheck(L_2450);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2452 = (&((L_2450)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2451)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2453 = (&L_2452->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2454 = V_54;
		int32_t L_2455 = V_240;
		NullCheck(L_2454);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2456 = (&((L_2454)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2455)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2457 = (&L_2456->___position_0);
		float L_2458 = L_2457->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2459 = V_36;
		float L_2460 = L_2459.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2461 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2462 = (&L_2461->___min_0);
		float L_2463 = L_2462->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2464 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2465 = (&L_2464->___max_1);
		float L_2466 = L_2465->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2467 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2468 = (&L_2467->___min_0);
		float L_2469 = L_2468->___x_0;
		float L_2470 = V_278;
		L_2453->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2458, L_2460)), L_2463))/((float)il2cpp_codegen_subtract(L_2466, L_2469)))), L_2470));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2471 = V_54;
		int32_t L_2472 = V_240;
		NullCheck(L_2471);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2473 = (&((L_2471)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2472)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2474 = (&L_2473->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2475 = V_54;
		int32_t L_2476 = V_240;
		NullCheck(L_2475);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2477 = (&((L_2475)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2476)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2478 = (&L_2477->___position_0);
		float L_2479 = L_2478->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2480 = V_36;
		float L_2481 = L_2480.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2482 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2483 = (&L_2482->___min_0);
		float L_2484 = L_2483->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2485 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2486 = (&L_2485->___max_1);
		float L_2487 = L_2486->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2488 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2489 = (&L_2488->___min_0);
		float L_2490 = L_2489->___x_0;
		float L_2491 = V_278;
		L_2474->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2479, L_2481)), L_2484))/((float)il2cpp_codegen_subtract(L_2487, L_2490)))), L_2491));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2492 = V_54;
		int32_t L_2493 = V_240;
		NullCheck(L_2492);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2494 = (&((L_2492)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2493)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2495 = (&L_2494->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2496 = V_54;
		int32_t L_2497 = V_240;
		NullCheck(L_2496);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2498 = (&((L_2496)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2497)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2499 = (&L_2498->___position_0);
		float L_2500 = L_2499->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2501 = V_36;
		float L_2502 = L_2501.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2503 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2504 = (&L_2503->___min_0);
		float L_2505 = L_2504->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2506 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2507 = (&L_2506->___max_1);
		float L_2508 = L_2507->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2509 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2510 = (&L_2509->___min_0);
		float L_2511 = L_2510->___x_0;
		float L_2512 = V_278;
		L_2495->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2500, L_2502)), L_2505))/((float)il2cpp_codegen_subtract(L_2508, L_2511)))), L_2512));
		goto IL_4d2d;
	}

IL_48b2:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2513 = ___generationSettings0;
		NullCheck(L_2513);
		int32_t L_2514 = L_2513->___verticalMapping_40;
		V_286 = L_2514;
		int32_t L_2515 = V_286;
		V_285 = L_2515;
		int32_t L_2516 = V_285;
		switch (L_2516)
		{
			case 0:
			{
				goto IL_48ea;
			}
			case 1:
			{
				goto IL_4963;
			}
			case 2:
			{
				goto IL_4a9c;
			}
			case 3:
			{
				goto IL_4bd2;
			}
		}
	}
	{
		goto IL_4bdf;
	}

IL_48ea:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2517 = V_54;
		int32_t L_2518 = V_240;
		NullCheck(L_2517);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2519 = (&((L_2517)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2518)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2520 = (&L_2519->___uv2_2);
		L_2520->___y_1 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2521 = V_54;
		int32_t L_2522 = V_240;
		NullCheck(L_2521);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2523 = (&((L_2521)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2522)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2524 = (&L_2523->___uv2_2);
		L_2524->___y_1 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2525 = V_54;
		int32_t L_2526 = V_240;
		NullCheck(L_2525);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2527 = (&((L_2525)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2526)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2528 = (&L_2527->___uv2_2);
		L_2528->___y_1 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2529 = V_54;
		int32_t L_2530 = V_240;
		NullCheck(L_2529);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2531 = (&((L_2529)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2530)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2532 = (&L_2531->___uv2_2);
		L_2532->___y_1 = (1.0f);
		goto IL_4bdf;
	}

IL_4963:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2533 = V_54;
		int32_t L_2534 = V_240;
		NullCheck(L_2533);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2535 = (&((L_2533)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2534)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2536 = (&L_2535->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2537 = V_54;
		int32_t L_2538 = V_240;
		NullCheck(L_2537);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2539 = (&((L_2537)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2538)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2540 = (&L_2539->___position_0);
		float L_2541 = L_2540->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2542 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2543 = L_2542.___min_0;
		float L_2544 = L_2543.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2545 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2546 = L_2545.___max_1;
		float L_2547 = L_2546.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2548 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2549 = L_2548.___min_0;
		float L_2550 = L_2549.___y_1;
		float L_2551 = V_278;
		L_2536->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2541, L_2544))/((float)il2cpp_codegen_subtract(L_2547, L_2550)))), L_2551));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2552 = V_54;
		int32_t L_2553 = V_240;
		NullCheck(L_2552);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2554 = (&((L_2552)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2553)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2555 = (&L_2554->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2556 = V_54;
		int32_t L_2557 = V_240;
		NullCheck(L_2556);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2558 = (&((L_2556)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2557)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2559 = (&L_2558->___position_0);
		float L_2560 = L_2559->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2561 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2562 = L_2561.___min_0;
		float L_2563 = L_2562.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2564 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2565 = L_2564.___max_1;
		float L_2566 = L_2565.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2567 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2568 = L_2567.___min_0;
		float L_2569 = L_2568.___y_1;
		float L_2570 = V_278;
		L_2555->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2560, L_2563))/((float)il2cpp_codegen_subtract(L_2566, L_2569)))), L_2570));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2571 = V_54;
		int32_t L_2572 = V_240;
		NullCheck(L_2571);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2573 = (&((L_2571)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2572)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2574 = (&L_2573->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2575 = V_54;
		int32_t L_2576 = V_240;
		NullCheck(L_2575);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2577 = (&((L_2575)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2576)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2578 = (&L_2577->___uv2_2);
		float L_2579 = L_2578->___y_1;
		L_2574->___y_1 = L_2579;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2580 = V_54;
		int32_t L_2581 = V_240;
		NullCheck(L_2580);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2582 = (&((L_2580)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2581)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2583 = (&L_2582->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2584 = V_54;
		int32_t L_2585 = V_240;
		NullCheck(L_2584);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2586 = (&((L_2584)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2585)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2587 = (&L_2586->___uv2_2);
		float L_2588 = L_2587->___y_1;
		L_2583->___y_1 = L_2588;
		goto IL_4bdf;
	}

IL_4a9c:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2589 = V_54;
		int32_t L_2590 = V_240;
		NullCheck(L_2589);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2591 = (&((L_2589)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2590)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2592 = (&L_2591->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2593 = V_54;
		int32_t L_2594 = V_240;
		NullCheck(L_2593);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2595 = (&((L_2593)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2594)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2596 = (&L_2595->___position_0);
		float L_2597 = L_2596->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2598 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2599 = (&L_2598->___min_0);
		float L_2600 = L_2599->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2601 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2602 = (&L_2601->___max_1);
		float L_2603 = L_2602->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2604 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2605 = (&L_2604->___min_0);
		float L_2606 = L_2605->___y_1;
		float L_2607 = V_278;
		L_2592->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2597, L_2600))/((float)il2cpp_codegen_subtract(L_2603, L_2606)))), L_2607));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2608 = V_54;
		int32_t L_2609 = V_240;
		NullCheck(L_2608);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2610 = (&((L_2608)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2609)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2611 = (&L_2610->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2612 = V_54;
		int32_t L_2613 = V_240;
		NullCheck(L_2612);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2614 = (&((L_2612)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2613)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2615 = (&L_2614->___position_0);
		float L_2616 = L_2615->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2617 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2618 = (&L_2617->___min_0);
		float L_2619 = L_2618->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2620 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2621 = (&L_2620->___max_1);
		float L_2622 = L_2621->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2623 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2624 = (&L_2623->___min_0);
		float L_2625 = L_2624->___y_1;
		float L_2626 = V_278;
		L_2611->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2616, L_2619))/((float)il2cpp_codegen_subtract(L_2622, L_2625)))), L_2626));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2627 = V_54;
		int32_t L_2628 = V_240;
		NullCheck(L_2627);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2629 = (&((L_2627)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2628)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2630 = (&L_2629->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2631 = V_54;
		int32_t L_2632 = V_240;
		NullCheck(L_2631);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2633 = (&((L_2631)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2632)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2634 = (&L_2633->___uv2_2);
		float L_2635 = L_2634->___y_1;
		L_2630->___y_1 = L_2635;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2636 = V_54;
		int32_t L_2637 = V_240;
		NullCheck(L_2636);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2638 = (&((L_2636)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2637)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2639 = (&L_2638->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2640 = V_54;
		int32_t L_2641 = V_240;
		NullCheck(L_2640);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2642 = (&((L_2640)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2641)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2643 = (&L_2642->___uv2_2);
		float L_2644 = L_2643->___y_1;
		L_2639->___y_1 = L_2644;
		goto IL_4bdf;
	}

IL_4bd2:
	{
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB(_stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4, NULL);
		goto IL_4bdf;
	}

IL_4bdf:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2645 = V_54;
		int32_t L_2646 = V_240;
		NullCheck(L_2645);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2647 = (&((L_2645)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2646)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2648 = (&L_2647->___uv2_2);
		float L_2649 = L_2648->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2650 = V_54;
		int32_t L_2651 = V_240;
		NullCheck(L_2650);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2652 = (&((L_2650)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2651)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2653 = (&L_2652->___uv2_2);
		float L_2654 = L_2653->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2655 = V_54;
		int32_t L_2656 = V_240;
		NullCheck(L_2655);
		float L_2657 = ((L_2655)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2656)))->___aspectRatio_27;
		V_281 = ((float)(((float)il2cpp_codegen_subtract((1.0f), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_2649, L_2654)), L_2657))))/(2.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2658 = V_54;
		int32_t L_2659 = V_240;
		NullCheck(L_2658);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2660 = (&((L_2658)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2659)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2661 = (&L_2660->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2662 = V_54;
		int32_t L_2663 = V_240;
		NullCheck(L_2662);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2664 = (&((L_2662)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2663)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2665 = (&L_2664->___uv2_2);
		float L_2666 = L_2665->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2667 = V_54;
		int32_t L_2668 = V_240;
		NullCheck(L_2667);
		float L_2669 = ((L_2667)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2668)))->___aspectRatio_27;
		float L_2670 = V_281;
		float L_2671 = V_278;
		L_2661->___x_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_2666, L_2669)), L_2670)), L_2671));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2672 = V_54;
		int32_t L_2673 = V_240;
		NullCheck(L_2672);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2674 = (&((L_2672)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2673)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2675 = (&L_2674->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2676 = V_54;
		int32_t L_2677 = V_240;
		NullCheck(L_2676);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2678 = (&((L_2676)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2677)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2679 = (&L_2678->___uv2_2);
		float L_2680 = L_2679->___x_0;
		L_2675->___x_0 = L_2680;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2681 = V_54;
		int32_t L_2682 = V_240;
		NullCheck(L_2681);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2683 = (&((L_2681)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2682)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2684 = (&L_2683->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2685 = V_54;
		int32_t L_2686 = V_240;
		NullCheck(L_2685);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2687 = (&((L_2685)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2686)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2688 = (&L_2687->___uv2_2);
		float L_2689 = L_2688->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2690 = V_54;
		int32_t L_2691 = V_240;
		NullCheck(L_2690);
		float L_2692 = ((L_2690)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2691)))->___aspectRatio_27;
		float L_2693 = V_281;
		float L_2694 = V_278;
		L_2684->___x_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_2689, L_2692)), L_2693)), L_2694));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2695 = V_54;
		int32_t L_2696 = V_240;
		NullCheck(L_2695);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2697 = (&((L_2695)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2696)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2698 = (&L_2697->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2699 = V_54;
		int32_t L_2700 = V_240;
		NullCheck(L_2699);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2701 = (&((L_2699)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2700)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2702 = (&L_2701->___uv2_2);
		float L_2703 = L_2702->___x_0;
		L_2698->___x_0 = L_2703;
		goto IL_4d2d;
	}

IL_4d2d:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2704 = ___generationSettings0;
		NullCheck(L_2704);
		int32_t L_2705 = L_2704->___verticalMapping_40;
		V_289 = L_2705;
		int32_t L_2706 = V_289;
		V_288 = L_2706;
		int32_t L_2707 = V_288;
		switch (L_2707)
		{
			case 0:
			{
				goto IL_4d65;
			}
			case 1:
			{
				goto IL_4dde;
			}
			case 2:
			{
				goto IL_4ed3;
			}
			case 3:
			{
				goto IL_4ffe;
			}
		}
	}
	{
		goto IL_513e;
	}

IL_4d65:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2708 = V_54;
		int32_t L_2709 = V_240;
		NullCheck(L_2708);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2710 = (&((L_2708)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2709)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2711 = (&L_2710->___uv2_2);
		L_2711->___y_1 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2712 = V_54;
		int32_t L_2713 = V_240;
		NullCheck(L_2712);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2714 = (&((L_2712)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2713)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2715 = (&L_2714->___uv2_2);
		L_2715->___y_1 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2716 = V_54;
		int32_t L_2717 = V_240;
		NullCheck(L_2716);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2718 = (&((L_2716)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2717)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2719 = (&L_2718->___uv2_2);
		L_2719->___y_1 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2720 = V_54;
		int32_t L_2721 = V_240;
		NullCheck(L_2720);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2722 = (&((L_2720)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2721)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2723 = (&L_2722->___uv2_2);
		L_2723->___y_1 = (0.0f);
		goto IL_513e;
	}

IL_4dde:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2724 = V_54;
		int32_t L_2725 = V_240;
		NullCheck(L_2724);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2726 = (&((L_2724)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2725)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2727 = (&L_2726->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2728 = V_54;
		int32_t L_2729 = V_240;
		NullCheck(L_2728);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2730 = (&((L_2728)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2729)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2731 = (&L_2730->___position_0);
		float L_2732 = L_2731->___y_3;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2733 = V_244;
		float L_2734 = L_2733.___descender_14;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2735 = V_244;
		float L_2736 = L_2735.___ascender_12;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2737 = V_244;
		float L_2738 = L_2737.___descender_14;
		L_2727->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2732, L_2734))/((float)il2cpp_codegen_subtract(L_2736, L_2738))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2739 = V_54;
		int32_t L_2740 = V_240;
		NullCheck(L_2739);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2741 = (&((L_2739)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2740)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2742 = (&L_2741->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2743 = V_54;
		int32_t L_2744 = V_240;
		NullCheck(L_2743);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2745 = (&((L_2743)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2744)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2746 = (&L_2745->___position_0);
		float L_2747 = L_2746->___y_3;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2748 = V_244;
		float L_2749 = L_2748.___descender_14;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2750 = V_244;
		float L_2751 = L_2750.___ascender_12;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2752 = V_244;
		float L_2753 = L_2752.___descender_14;
		L_2742->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2747, L_2749))/((float)il2cpp_codegen_subtract(L_2751, L_2753))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2754 = V_54;
		int32_t L_2755 = V_240;
		NullCheck(L_2754);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2756 = (&((L_2754)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2755)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2757 = (&L_2756->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2758 = V_54;
		int32_t L_2759 = V_240;
		NullCheck(L_2758);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2760 = (&((L_2758)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2759)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2761 = (&L_2760->___uv2_2);
		float L_2762 = L_2761->___y_1;
		L_2757->___y_1 = L_2762;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2763 = V_54;
		int32_t L_2764 = V_240;
		NullCheck(L_2763);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2765 = (&((L_2763)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2764)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2766 = (&L_2765->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2767 = V_54;
		int32_t L_2768 = V_240;
		NullCheck(L_2767);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2769 = (&((L_2767)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2768)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2770 = (&L_2769->___uv2_2);
		float L_2771 = L_2770->___y_1;
		L_2766->___y_1 = L_2771;
		goto IL_513e;
	}

IL_4ed3:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2772 = V_54;
		int32_t L_2773 = V_240;
		NullCheck(L_2772);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2774 = (&((L_2772)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2773)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2775 = (&L_2774->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2776 = V_54;
		int32_t L_2777 = V_240;
		NullCheck(L_2776);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2778 = (&((L_2776)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2777)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2779 = (&L_2778->___position_0);
		float L_2780 = L_2779->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2781 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2782 = (&L_2781->___min_0);
		float L_2783 = L_2782->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2784 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2785 = (&L_2784->___max_1);
		float L_2786 = L_2785->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2787 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2788 = (&L_2787->___min_0);
		float L_2789 = L_2788->___y_1;
		L_2775->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2780, L_2783))/((float)il2cpp_codegen_subtract(L_2786, L_2789))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2790 = V_54;
		int32_t L_2791 = V_240;
		NullCheck(L_2790);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2792 = (&((L_2790)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2791)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2793 = (&L_2792->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2794 = V_54;
		int32_t L_2795 = V_240;
		NullCheck(L_2794);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2796 = (&((L_2794)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2795)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2797 = (&L_2796->___position_0);
		float L_2798 = L_2797->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2799 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2800 = (&L_2799->___min_0);
		float L_2801 = L_2800->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2802 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2803 = (&L_2802->___max_1);
		float L_2804 = L_2803->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2805 = (&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2806 = (&L_2805->___min_0);
		float L_2807 = L_2806->___y_1;
		L_2793->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2798, L_2801))/((float)il2cpp_codegen_subtract(L_2804, L_2807))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2808 = V_54;
		int32_t L_2809 = V_240;
		NullCheck(L_2808);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2810 = (&((L_2808)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2809)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2811 = (&L_2810->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2812 = V_54;
		int32_t L_2813 = V_240;
		NullCheck(L_2812);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2814 = (&((L_2812)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2813)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2815 = (&L_2814->___uv2_2);
		float L_2816 = L_2815->___y_1;
		L_2811->___y_1 = L_2816;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2817 = V_54;
		int32_t L_2818 = V_240;
		NullCheck(L_2817);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2819 = (&((L_2817)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2818)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2820 = (&L_2819->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2821 = V_54;
		int32_t L_2822 = V_240;
		NullCheck(L_2821);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2823 = (&((L_2821)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2822)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2824 = (&L_2823->___uv2_2);
		float L_2825 = L_2824->___y_1;
		L_2820->___y_1 = L_2825;
		goto IL_513e;
	}

IL_4ffe:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2826 = V_54;
		int32_t L_2827 = V_240;
		NullCheck(L_2826);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2828 = (&((L_2826)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2827)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2829 = (&L_2828->___uv2_2);
		float L_2830 = L_2829->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2831 = V_54;
		int32_t L_2832 = V_240;
		NullCheck(L_2831);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2833 = (&((L_2831)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2832)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2834 = (&L_2833->___uv2_2);
		float L_2835 = L_2834->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2836 = V_54;
		int32_t L_2837 = V_240;
		NullCheck(L_2836);
		float L_2838 = ((L_2836)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2837)))->___aspectRatio_27;
		V_287 = ((float)(((float)il2cpp_codegen_subtract((1.0f), ((float)(((float)il2cpp_codegen_add(L_2830, L_2835))/L_2838))))/(2.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2839 = V_54;
		int32_t L_2840 = V_240;
		NullCheck(L_2839);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2841 = (&((L_2839)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2840)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2842 = (&L_2841->___uv2_2);
		float L_2843 = V_287;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2844 = V_54;
		int32_t L_2845 = V_240;
		NullCheck(L_2844);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2846 = (&((L_2844)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2845)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2847 = (&L_2846->___uv2_2);
		float L_2848 = L_2847->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2849 = V_54;
		int32_t L_2850 = V_240;
		NullCheck(L_2849);
		float L_2851 = ((L_2849)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2850)))->___aspectRatio_27;
		L_2842->___y_1 = ((float)il2cpp_codegen_add(L_2843, ((float)(L_2848/L_2851))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2852 = V_54;
		int32_t L_2853 = V_240;
		NullCheck(L_2852);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2854 = (&((L_2852)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2853)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2855 = (&L_2854->___uv2_2);
		float L_2856 = V_287;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2857 = V_54;
		int32_t L_2858 = V_240;
		NullCheck(L_2857);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2859 = (&((L_2857)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2858)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2860 = (&L_2859->___uv2_2);
		float L_2861 = L_2860->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2862 = V_54;
		int32_t L_2863 = V_240;
		NullCheck(L_2862);
		float L_2864 = ((L_2862)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2863)))->___aspectRatio_27;
		L_2855->___y_1 = ((float)il2cpp_codegen_add(L_2856, ((float)(L_2861/L_2864))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2865 = V_54;
		int32_t L_2866 = V_240;
		NullCheck(L_2865);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2867 = (&((L_2865)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2866)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2868 = (&L_2867->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2869 = V_54;
		int32_t L_2870 = V_240;
		NullCheck(L_2869);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2871 = (&((L_2869)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2870)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2872 = (&L_2871->___uv2_2);
		float L_2873 = L_2872->___y_1;
		L_2868->___y_1 = L_2873;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2874 = V_54;
		int32_t L_2875 = V_240;
		NullCheck(L_2874);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2876 = (&((L_2874)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2875)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2877 = (&L_2876->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2878 = V_54;
		int32_t L_2879 = V_240;
		NullCheck(L_2878);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2880 = (&((L_2878)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2879)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2881 = (&L_2880->___uv2_2);
		float L_2882 = L_2881->___y_1;
		L_2877->___y_1 = L_2882;
		goto IL_513e;
	}

IL_513e:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2883 = V_54;
		int32_t L_2884 = V_240;
		NullCheck(L_2883);
		float L_2885 = ((L_2883)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2884)))->___scale_28;
		float L_2886 = __this->___m_CharWidthAdjDelta_77;
		V_46 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_2885, ((float)il2cpp_codegen_subtract((1.0f), L_2886)))), (1.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2887 = V_54;
		int32_t L_2888 = V_240;
		NullCheck(L_2887);
		bool L_2889 = ((L_2887)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2888)))->___isUsingAlternateTypeface_9;
		if (L_2889)
		{
			goto IL_5186;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2890 = V_54;
		int32_t L_2891 = V_240;
		NullCheck(L_2890);
		int32_t L_2892 = ((L_2890)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2891)))->___style_33;
		G_B756_0 = ((((int32_t)((int32_t)((int32_t)L_2892&1))) == ((int32_t)1))? 1 : 0);
		goto IL_5187;
	}

IL_5186:
	{
		G_B756_0 = 0;
	}

IL_5187:
	{
		V_290 = (bool)G_B756_0;
		bool L_2893 = V_290;
		if (!L_2893)
		{
			goto IL_519f;
		}
	}
	{
		float L_2894 = V_46;
		V_46 = ((float)il2cpp_codegen_multiply(L_2894, (-1.0f)));
	}

IL_519f:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2895 = V_54;
		int32_t L_2896 = V_240;
		NullCheck(L_2895);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2897 = (&((L_2895)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2896)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2898 = (&L_2897->___uv2_2);
		L_2898->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2899 = V_54;
		int32_t L_2900 = V_240;
		NullCheck(L_2899);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2901 = (&((L_2899)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2900)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2902 = (&L_2901->___uv2_2);
		float L_2903 = V_46;
		L_2902->___y_1 = L_2903;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2904 = V_54;
		int32_t L_2905 = V_240;
		NullCheck(L_2904);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2906 = (&((L_2904)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2905)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2907 = (&L_2906->___uv2_2);
		L_2907->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2908 = V_54;
		int32_t L_2909 = V_240;
		NullCheck(L_2908);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2910 = (&((L_2908)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2909)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2911 = (&L_2910->___uv2_2);
		float L_2912 = V_46;
		L_2911->___y_1 = L_2912;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2913 = V_54;
		int32_t L_2914 = V_240;
		NullCheck(L_2913);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2915 = (&((L_2913)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2914)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2916 = (&L_2915->___uv2_2);
		L_2916->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2917 = V_54;
		int32_t L_2918 = V_240;
		NullCheck(L_2917);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2919 = (&((L_2917)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2918)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2920 = (&L_2919->___uv2_2);
		float L_2921 = V_46;
		L_2920->___y_1 = L_2921;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2922 = V_54;
		int32_t L_2923 = V_240;
		NullCheck(L_2922);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2924 = (&((L_2922)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2923)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2925 = (&L_2924->___uv2_2);
		L_2925->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2926 = V_54;
		int32_t L_2927 = V_240;
		NullCheck(L_2926);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2928 = (&((L_2926)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2927)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2929 = (&L_2928->___uv2_2);
		float L_2930 = V_46;
		L_2929->___y_1 = L_2930;
		goto IL_527f;
	}

IL_527d:
	{
		goto IL_527f;
	}

IL_527f:
	{
		int32_t L_2931 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2932 = ___generationSettings0;
		NullCheck(L_2932);
		int32_t L_2933 = L_2932->___maxVisibleCharacters_32;
		if ((((int32_t)L_2931) >= ((int32_t)L_2933)))
		{
			goto IL_52ab;
		}
	}
	{
		int32_t L_2934 = V_37;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2935 = ___generationSettings0;
		NullCheck(L_2935);
		int32_t L_2936 = L_2935->___maxVisibleWords_33;
		if ((((int32_t)L_2934) >= ((int32_t)L_2936)))
		{
			goto IL_52ab;
		}
	}
	{
		int32_t L_2937 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2938 = ___generationSettings0;
		NullCheck(L_2938);
		int32_t L_2939 = L_2938->___maxVisibleLines_34;
		if ((((int32_t)L_2937) >= ((int32_t)L_2939)))
		{
			goto IL_52ab;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2940 = ___generationSettings0;
		NullCheck(L_2940);
		int32_t L_2941 = L_2940->___overflowMode_11;
		G_B765_0 = ((((int32_t)((((int32_t)L_2941) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_52ac;
	}

IL_52ab:
	{
		G_B765_0 = 0;
	}

IL_52ac:
	{
		V_291 = (bool)G_B765_0;
		bool L_2942 = V_291;
		if (!L_2942)
		{
			goto IL_539c;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2943 = V_54;
		int32_t L_2944 = V_240;
		NullCheck(L_2943);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2945 = (&((L_2943)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2944)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2946 = (&L_2945->___position_0);
		V_292 = L_2946;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2947 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2948 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2949 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2948);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2950 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2951;
		L_2951 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2949, L_2950, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2947 = L_2951;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2952 = V_54;
		int32_t L_2953 = V_240;
		NullCheck(L_2952);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2954 = (&((L_2952)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2953)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2955 = (&L_2954->___position_0);
		V_292 = L_2955;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2956 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2957 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2958 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2957);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2959 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2960;
		L_2960 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2958, L_2959, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2956 = L_2960;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2961 = V_54;
		int32_t L_2962 = V_240;
		NullCheck(L_2961);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2963 = (&((L_2961)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2962)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2964 = (&L_2963->___position_0);
		V_292 = L_2964;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2965 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2966 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2967 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2966);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2968 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2969;
		L_2969 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2967, L_2968, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2965 = L_2969;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2970 = V_54;
		int32_t L_2971 = V_240;
		NullCheck(L_2970);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2972 = (&((L_2970)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2971)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2973 = (&L_2972->___position_0);
		V_292 = L_2973;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2974 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2975 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2976 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2975);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2977 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2978;
		L_2978 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2976, L_2977, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2974 = L_2978;
		goto IL_5536;
	}

IL_539c:
	{
		int32_t L_2979 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2980 = ___generationSettings0;
		NullCheck(L_2980);
		int32_t L_2981 = L_2980->___maxVisibleCharacters_32;
		if ((((int32_t)L_2979) >= ((int32_t)L_2981)))
		{
			goto IL_53d7;
		}
	}
	{
		int32_t L_2982 = V_37;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2983 = ___generationSettings0;
		NullCheck(L_2983);
		int32_t L_2984 = L_2983->___maxVisibleWords_33;
		if ((((int32_t)L_2982) >= ((int32_t)L_2984)))
		{
			goto IL_53d7;
		}
	}
	{
		int32_t L_2985 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2986 = ___generationSettings0;
		NullCheck(L_2986);
		int32_t L_2987 = L_2986->___maxVisibleLines_34;
		if ((((int32_t)L_2985) >= ((int32_t)L_2987)))
		{
			goto IL_53d7;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2988 = ___generationSettings0;
		NullCheck(L_2988);
		int32_t L_2989 = L_2988->___overflowMode_11;
		if ((!(((uint32_t)L_2989) == ((uint32_t)5))))
		{
			goto IL_53d7;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2990 = V_54;
		int32_t L_2991 = V_240;
		NullCheck(L_2990);
		int32_t L_2992 = ((L_2990)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2991)))->___pageNumber_12;
		int32_t L_2993 = V_16;
		G_B773_0 = ((((int32_t)L_2992) == ((int32_t)L_2993))? 1 : 0);
		goto IL_53d8;
	}

IL_53d7:
	{
		G_B773_0 = 0;
	}

IL_53d8:
	{
		V_293 = (bool)G_B773_0;
		bool L_2994 = V_293;
		if (!L_2994)
		{
			goto IL_54c5;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2995 = V_54;
		int32_t L_2996 = V_240;
		NullCheck(L_2995);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2997 = (&((L_2995)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2996)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2998 = (&L_2997->___position_0);
		V_292 = L_2998;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2999 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3000 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3001 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3000);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3002 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3003;
		L_3003 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3001, L_3002, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2999 = L_3003;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3004 = V_54;
		int32_t L_3005 = V_240;
		NullCheck(L_3004);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3006 = (&((L_3004)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3005)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3007 = (&L_3006->___position_0);
		V_292 = L_3007;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3008 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3009 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3010 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3009);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3011 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3012;
		L_3012 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3010, L_3011, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3008 = L_3012;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3013 = V_54;
		int32_t L_3014 = V_240;
		NullCheck(L_3013);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3015 = (&((L_3013)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3014)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3016 = (&L_3015->___position_0);
		V_292 = L_3016;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3017 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3018 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3019 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3018);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3020 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3021;
		L_3021 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3019, L_3020, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3017 = L_3021;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3022 = V_54;
		int32_t L_3023 = V_240;
		NullCheck(L_3022);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3024 = (&((L_3022)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3023)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3025 = (&L_3024->___position_0);
		V_292 = L_3025;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3026 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3027 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3028 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3027);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3029 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3030;
		L_3030 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3028, L_3029, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3026 = L_3030;
		goto IL_5536;
	}

IL_54c5:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3031 = V_54;
		int32_t L_3032 = V_240;
		NullCheck(L_3031);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3033 = (&((L_3031)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3032)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3034;
		L_3034 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3033->___position_0 = L_3034;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3035 = V_54;
		int32_t L_3036 = V_240;
		NullCheck(L_3035);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3037 = (&((L_3035)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3036)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3038;
		L_3038 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3037->___position_0 = L_3038;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3039 = V_54;
		int32_t L_3040 = V_240;
		NullCheck(L_3039);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3041 = (&((L_3039)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3040)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3042;
		L_3042 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3041->___position_0 = L_3042;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3043 = V_54;
		int32_t L_3044 = V_240;
		NullCheck(L_3043);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3045 = (&((L_3043)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3044)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3046;
		L_3046 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3045->___position_0 = L_3046;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3047 = V_54;
		int32_t L_3048 = V_240;
		NullCheck(L_3047);
		((L_3047)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3048)))->___isVisible_34 = (bool)0;
	}

IL_5536:
	{
		uint8_t L_3049 = V_276;
		V_294 = (bool)((((int32_t)L_3049) == ((int32_t)1))? 1 : 0);
		bool L_3050 = V_294;
		if (!L_3050)
		{
			goto IL_555b;
		}
	}
	{
		int32_t L_3051 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3052 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3053 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_FillCharacterVertexBuffers_m54CA97C6C26BA84BC949845B20E9DADF2F0C19CA(L_3051, L_3052, L_3053, NULL);
		goto IL_557e;
	}

IL_555b:
	{
		uint8_t L_3054 = V_276;
		V_295 = (bool)((((int32_t)L_3054) == ((int32_t)2))? 1 : 0);
		bool L_3055 = V_295;
		if (!L_3055)
		{
			goto IL_557e;
		}
	}
	{
		int32_t L_3056 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3057 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3058 = ___textInfo1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_FillSpriteVertexBuffers_m4305B80FA32FE21A59AF68A5501226E5A4203CC3(L_3056, L_3057, L_3058, NULL);
	}

IL_557e:
	{
	}

IL_557f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3059 = ___textInfo1;
		NullCheck(L_3059);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3060 = L_3059->___textElementInfo_10;
		int32_t L_3061 = V_240;
		NullCheck(L_3060);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3062 = (&((L_3060)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3061)))->___bottomLeft_19);
		V_292 = L_3062;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3063 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3064 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3065 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3064);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3066 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3067;
		L_3067 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3065, L_3066, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3063 = L_3067;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3068 = ___textInfo1;
		NullCheck(L_3068);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3069 = L_3068->___textElementInfo_10;
		int32_t L_3070 = V_240;
		NullCheck(L_3069);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3071 = (&((L_3069)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3070)))->___topLeft_18);
		V_292 = L_3071;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3072 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3073 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3074 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3073);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3075 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3076;
		L_3076 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3074, L_3075, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3072 = L_3076;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3077 = ___textInfo1;
		NullCheck(L_3077);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3078 = L_3077->___textElementInfo_10;
		int32_t L_3079 = V_240;
		NullCheck(L_3078);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3080 = (&((L_3078)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3079)))->___topRight_20);
		V_292 = L_3080;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3081 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3082 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3083 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3082);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3084 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3085;
		L_3085 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3083, L_3084, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3081 = L_3085;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3086 = ___textInfo1;
		NullCheck(L_3086);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3087 = L_3086->___textElementInfo_10;
		int32_t L_3088 = V_240;
		NullCheck(L_3087);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3089 = (&((L_3087)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3088)))->___bottomRight_21);
		V_292 = L_3089;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3090 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3091 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3092 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3091);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3093 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3094;
		L_3094 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3092, L_3093, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3090 = L_3094;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3095 = ___textInfo1;
		NullCheck(L_3095);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3096 = L_3095->___textElementInfo_10;
		int32_t L_3097 = V_240;
		NullCheck(L_3096);
		float* L_3098 = (&((L_3096)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3097)))->___origin_22);
		float* L_3099 = L_3098;
		float L_3100 = *((float*)L_3099);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3101 = V_246;
		float L_3102 = L_3101.___x_2;
		*((float*)L_3099) = (float)((float)il2cpp_codegen_add(L_3100, L_3102));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3103 = ___textInfo1;
		NullCheck(L_3103);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3104 = L_3103->___textElementInfo_10;
		int32_t L_3105 = V_240;
		NullCheck(L_3104);
		float* L_3106 = (&((L_3104)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3105)))->___xAdvance_26);
		float* L_3107 = L_3106;
		float L_3108 = *((float*)L_3107);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3109 = V_246;
		float L_3110 = L_3109.___x_2;
		*((float*)L_3107) = (float)((float)il2cpp_codegen_add(L_3108, L_3110));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3111 = ___textInfo1;
		NullCheck(L_3111);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3112 = L_3111->___textElementInfo_10;
		int32_t L_3113 = V_240;
		NullCheck(L_3112);
		float* L_3114 = (&((L_3112)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3113)))->___ascender_23);
		float* L_3115 = L_3114;
		float L_3116 = *((float*)L_3115);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3117 = V_246;
		float L_3118 = L_3117.___y_3;
		*((float*)L_3115) = (float)((float)il2cpp_codegen_add(L_3116, L_3118));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3119 = ___textInfo1;
		NullCheck(L_3119);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3120 = L_3119->___textElementInfo_10;
		int32_t L_3121 = V_240;
		NullCheck(L_3120);
		float* L_3122 = (&((L_3120)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3121)))->___descender_25);
		float* L_3123 = L_3122;
		float L_3124 = *((float*)L_3123);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3125 = V_246;
		float L_3126 = L_3125.___y_3;
		*((float*)L_3123) = (float)((float)il2cpp_codegen_add(L_3124, L_3126));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3127 = ___textInfo1;
		NullCheck(L_3127);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3128 = L_3127->___textElementInfo_10;
		int32_t L_3129 = V_240;
		NullCheck(L_3128);
		float* L_3130 = (&((L_3128)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3129)))->___baseLine_24);
		float* L_3131 = L_3130;
		float L_3132 = *((float*)L_3131);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3133 = V_246;
		float L_3134 = L_3133.___y_3;
		*((float*)L_3131) = (float)((float)il2cpp_codegen_add(L_3132, L_3134));
		int32_t L_3135 = V_243;
		int32_t L_3136 = V_39;
		if ((!(((uint32_t)L_3135) == ((uint32_t)L_3136))))
		{
			goto IL_56f8;
		}
	}
	{
		int32_t L_3137 = V_240;
		int32_t L_3138 = __this->___m_CharacterCount_48;
		G_B784_0 = ((((int32_t)L_3137) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3138, 1))))? 1 : 0);
		goto IL_56f9;
	}

IL_56f8:
	{
		G_B784_0 = 1;
	}

IL_56f9:
	{
		V_296 = (bool)G_B784_0;
		bool L_3139 = V_296;
		if (!L_3139)
		{
			goto IL_5949;
		}
	}
	{
		int32_t L_3140 = V_243;
		int32_t L_3141 = V_39;
		V_297 = (bool)((((int32_t)((((int32_t)L_3140) == ((int32_t)L_3141))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_3142 = V_297;
		if (!L_3142)
		{
			goto IL_5828;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3143 = ___textInfo1;
		NullCheck(L_3143);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3144 = L_3143->___lineInfo_13;
		int32_t L_3145 = V_39;
		NullCheck(L_3144);
		float* L_3146 = (&((L_3144)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3145)))->___baseline_13);
		float* L_3147 = L_3146;
		float L_3148 = *((float*)L_3147);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3149 = V_246;
		float L_3150 = L_3149.___y_3;
		*((float*)L_3147) = (float)((float)il2cpp_codegen_add(L_3148, L_3150));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3151 = ___textInfo1;
		NullCheck(L_3151);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3152 = L_3151->___lineInfo_13;
		int32_t L_3153 = V_39;
		NullCheck(L_3152);
		float* L_3154 = (&((L_3152)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3153)))->___ascender_12);
		float* L_3155 = L_3154;
		float L_3156 = *((float*)L_3155);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3157 = V_246;
		float L_3158 = L_3157.___y_3;
		*((float*)L_3155) = (float)((float)il2cpp_codegen_add(L_3156, L_3158));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3159 = ___textInfo1;
		NullCheck(L_3159);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3160 = L_3159->___lineInfo_13;
		int32_t L_3161 = V_39;
		NullCheck(L_3160);
		float* L_3162 = (&((L_3160)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3161)))->___descender_14);
		float* L_3163 = L_3162;
		float L_3164 = *((float*)L_3163);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3165 = V_246;
		float L_3166 = L_3165.___y_3;
		*((float*)L_3163) = (float)((float)il2cpp_codegen_add(L_3164, L_3166));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3167 = ___textInfo1;
		NullCheck(L_3167);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3168 = L_3167->___lineInfo_13;
		int32_t L_3169 = V_39;
		NullCheck(L_3168);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3170 = (&((L_3168)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3169)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3171 = ___textInfo1;
		NullCheck(L_3171);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3172 = L_3171->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3173 = ___textInfo1;
		NullCheck(L_3173);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3174 = L_3173->___lineInfo_13;
		int32_t L_3175 = V_39;
		NullCheck(L_3174);
		int32_t L_3176 = ((L_3174)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3175)))->___firstCharacterIndex_6;
		NullCheck(L_3172);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3177 = (&((L_3172)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3176)))->___bottomLeft_19);
		float L_3178 = L_3177->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3179 = ___textInfo1;
		NullCheck(L_3179);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3180 = L_3179->___lineInfo_13;
		int32_t L_3181 = V_39;
		NullCheck(L_3180);
		float L_3182 = ((L_3180)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3181)))->___descender_14;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3183;
		memset((&L_3183), 0, sizeof(L_3183));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3183), L_3178, L_3182, /*hidden argument*/NULL);
		L_3170->___min_0 = L_3183;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3184 = ___textInfo1;
		NullCheck(L_3184);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3185 = L_3184->___lineInfo_13;
		int32_t L_3186 = V_39;
		NullCheck(L_3185);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3187 = (&((L_3185)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3186)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3188 = ___textInfo1;
		NullCheck(L_3188);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3189 = L_3188->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3190 = ___textInfo1;
		NullCheck(L_3190);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3191 = L_3190->___lineInfo_13;
		int32_t L_3192 = V_39;
		NullCheck(L_3191);
		int32_t L_3193 = ((L_3191)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3192)))->___lastVisibleCharacterIndex_9;
		NullCheck(L_3189);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3194 = (&((L_3189)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3193)))->___topRight_20);
		float L_3195 = L_3194->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3196 = ___textInfo1;
		NullCheck(L_3196);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3197 = L_3196->___lineInfo_13;
		int32_t L_3198 = V_39;
		NullCheck(L_3197);
		float L_3199 = ((L_3197)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3198)))->___ascender_12;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3200;
		memset((&L_3200), 0, sizeof(L_3200));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3200), L_3195, L_3199, /*hidden argument*/NULL);
		L_3187->___max_1 = L_3200;
	}

IL_5828:
	{
		int32_t L_3201 = V_240;
		int32_t L_3202 = __this->___m_CharacterCount_48;
		V_298 = (bool)((((int32_t)L_3201) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3202, 1))))? 1 : 0);
		bool L_3203 = V_298;
		if (!L_3203)
		{
			goto IL_5948;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3204 = ___textInfo1;
		NullCheck(L_3204);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3205 = L_3204->___lineInfo_13;
		int32_t L_3206 = V_243;
		NullCheck(L_3205);
		float* L_3207 = (&((L_3205)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3206)))->___baseline_13);
		float* L_3208 = L_3207;
		float L_3209 = *((float*)L_3208);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3210 = V_246;
		float L_3211 = L_3210.___y_3;
		*((float*)L_3208) = (float)((float)il2cpp_codegen_add(L_3209, L_3211));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3212 = ___textInfo1;
		NullCheck(L_3212);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3213 = L_3212->___lineInfo_13;
		int32_t L_3214 = V_243;
		NullCheck(L_3213);
		float* L_3215 = (&((L_3213)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3214)))->___ascender_12);
		float* L_3216 = L_3215;
		float L_3217 = *((float*)L_3216);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3218 = V_246;
		float L_3219 = L_3218.___y_3;
		*((float*)L_3216) = (float)((float)il2cpp_codegen_add(L_3217, L_3219));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3220 = ___textInfo1;
		NullCheck(L_3220);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3221 = L_3220->___lineInfo_13;
		int32_t L_3222 = V_243;
		NullCheck(L_3221);
		float* L_3223 = (&((L_3221)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3222)))->___descender_14);
		float* L_3224 = L_3223;
		float L_3225 = *((float*)L_3224);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3226 = V_246;
		float L_3227 = L_3226.___y_3;
		*((float*)L_3224) = (float)((float)il2cpp_codegen_add(L_3225, L_3227));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3228 = ___textInfo1;
		NullCheck(L_3228);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3229 = L_3228->___lineInfo_13;
		int32_t L_3230 = V_243;
		NullCheck(L_3229);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3231 = (&((L_3229)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3230)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3232 = ___textInfo1;
		NullCheck(L_3232);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3233 = L_3232->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3234 = ___textInfo1;
		NullCheck(L_3234);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3235 = L_3234->___lineInfo_13;
		int32_t L_3236 = V_243;
		NullCheck(L_3235);
		int32_t L_3237 = ((L_3235)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3236)))->___firstCharacterIndex_6;
		NullCheck(L_3233);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3238 = (&((L_3233)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3237)))->___bottomLeft_19);
		float L_3239 = L_3238->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3240 = ___textInfo1;
		NullCheck(L_3240);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3241 = L_3240->___lineInfo_13;
		int32_t L_3242 = V_243;
		NullCheck(L_3241);
		float L_3243 = ((L_3241)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3242)))->___descender_14;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3244;
		memset((&L_3244), 0, sizeof(L_3244));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3244), L_3239, L_3243, /*hidden argument*/NULL);
		L_3231->___min_0 = L_3244;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3245 = ___textInfo1;
		NullCheck(L_3245);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3246 = L_3245->___lineInfo_13;
		int32_t L_3247 = V_243;
		NullCheck(L_3246);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3248 = (&((L_3246)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3247)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3249 = ___textInfo1;
		NullCheck(L_3249);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3250 = L_3249->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3251 = ___textInfo1;
		NullCheck(L_3251);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3252 = L_3251->___lineInfo_13;
		int32_t L_3253 = V_243;
		NullCheck(L_3252);
		int32_t L_3254 = ((L_3252)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3253)))->___lastVisibleCharacterIndex_9;
		NullCheck(L_3250);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3255 = (&((L_3250)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3254)))->___topRight_20);
		float L_3256 = L_3255->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3257 = ___textInfo1;
		NullCheck(L_3257);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3258 = L_3257->___lineInfo_13;
		int32_t L_3259 = V_243;
		NullCheck(L_3258);
		float L_3260 = ((L_3258)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3259)))->___ascender_12;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3261;
		memset((&L_3261), 0, sizeof(L_3261));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3261), L_3256, L_3260, /*hidden argument*/NULL);
		L_3248->___max_1 = L_3261;
	}

IL_5948:
	{
	}

IL_5949:
	{
		Il2CppChar L_3262 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3263;
		L_3263 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3262, NULL);
		if (L_3263)
		{
			goto IL_5975;
		}
	}
	{
		Il2CppChar L_3264 = V_242;
		if ((((int32_t)L_3264) == ((int32_t)((int32_t)45))))
		{
			goto IL_5975;
		}
	}
	{
		Il2CppChar L_3265 = V_242;
		if ((((int32_t)L_3265) == ((int32_t)((int32_t)173))))
		{
			goto IL_5975;
		}
	}
	{
		Il2CppChar L_3266 = V_242;
		if ((((int32_t)L_3266) == ((int32_t)((int32_t)8208))))
		{
			goto IL_5975;
		}
	}
	{
		Il2CppChar L_3267 = V_242;
		G_B796_0 = ((((int32_t)L_3267) == ((int32_t)((int32_t)8209)))? 1 : 0);
		goto IL_5976;
	}

IL_5975:
	{
		G_B796_0 = 1;
	}

IL_5976:
	{
		V_299 = (bool)G_B796_0;
		bool L_3268 = V_299;
		if (!L_3268)
		{
			goto IL_5a9d;
		}
	}
	{
		bool L_3269 = V_41;
		V_300 = (bool)((((int32_t)L_3269) == ((int32_t)0))? 1 : 0);
		bool L_3270 = V_300;
		if (!L_3270)
		{
			goto IL_59a4;
		}
	}
	{
		V_41 = (bool)1;
		int32_t L_3271 = V_240;
		V_42 = L_3271;
	}

IL_59a4:
	{
		bool L_3272 = V_41;
		if (!L_3272)
		{
			goto IL_59b6;
		}
	}
	{
		int32_t L_3273 = V_240;
		int32_t L_3274 = __this->___m_CharacterCount_48;
		G_B802_0 = ((((int32_t)L_3273) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3274, 1))))? 1 : 0);
		goto IL_59b7;
	}

IL_59b6:
	{
		G_B802_0 = 0;
	}

IL_59b7:
	{
		V_301 = (bool)G_B802_0;
		bool L_3275 = V_301;
		if (!L_3275)
		{
			goto IL_5a97;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3276 = ___textInfo1;
		NullCheck(L_3276);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3277 = L_3276->___wordInfo_11;
		NullCheck(L_3277);
		V_302 = ((int32_t)(((RuntimeArray*)L_3277)->max_length));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3278 = ___textInfo1;
		NullCheck(L_3278);
		int32_t L_3279 = L_3278->___wordCount_5;
		V_303 = L_3279;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3280 = ___textInfo1;
		NullCheck(L_3280);
		int32_t L_3281 = L_3280->___wordCount_5;
		int32_t L_3282 = V_302;
		V_304 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_3281, 1))) > ((int32_t)L_3282))? 1 : 0);
		bool L_3283 = V_304;
		if (!L_3283)
		{
			goto IL_5a15;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3284 = ___textInfo1;
		NullCheck(L_3284);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** L_3285 = (&L_3284->___wordInfo_11);
		int32_t L_3286 = V_302;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D(L_3285, ((int32_t)il2cpp_codegen_add(L_3286, 1)), TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
	}

IL_5a15:
	{
		int32_t L_3287 = V_240;
		V_248 = L_3287;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3288 = ___textInfo1;
		NullCheck(L_3288);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3289 = L_3288->___wordInfo_11;
		int32_t L_3290 = V_303;
		NullCheck(L_3289);
		int32_t L_3291 = V_42;
		((L_3289)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3290)))->___firstCharacterIndex_0 = L_3291;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3292 = ___textInfo1;
		NullCheck(L_3292);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3293 = L_3292->___wordInfo_11;
		int32_t L_3294 = V_303;
		NullCheck(L_3293);
		int32_t L_3295 = V_248;
		((L_3293)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3294)))->___lastCharacterIndex_1 = L_3295;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3296 = ___textInfo1;
		NullCheck(L_3296);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3297 = L_3296->___wordInfo_11;
		int32_t L_3298 = V_303;
		NullCheck(L_3297);
		int32_t L_3299 = V_248;
		int32_t L_3300 = V_42;
		((L_3297)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3298)))->___characterCount_2 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_3299, L_3300)), 1));
		int32_t L_3301 = V_37;
		V_37 = ((int32_t)il2cpp_codegen_add(L_3301, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3302 = ___textInfo1;
		V_166 = L_3302;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3303 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3304 = V_166;
		NullCheck(L_3304);
		int32_t L_3305 = L_3304->___wordCount_5;
		NullCheck(L_3303);
		L_3303->___wordCount_5 = ((int32_t)il2cpp_codegen_add(L_3305, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3306 = ___textInfo1;
		NullCheck(L_3306);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3307 = L_3306->___lineInfo_13;
		int32_t L_3308 = V_243;
		NullCheck(L_3307);
		int32_t* L_3309 = (&((L_3307)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3308)))->___wordCount_5);
		int32_t* L_3310 = L_3309;
		int32_t L_3311 = *((int32_t*)L_3310);
		*((int32_t*)L_3310) = (int32_t)((int32_t)il2cpp_codegen_add(L_3311, 1));
	}

IL_5a97:
	{
		goto IL_5c40;
	}

IL_5a9d:
	{
		bool L_3312 = V_41;
		if (L_3312)
		{
			goto IL_5ad4;
		}
	}
	{
		int32_t L_3313 = V_240;
		if (L_3313)
		{
			goto IL_5ad1;
		}
	}
	{
		Il2CppChar L_3314 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3315;
		L_3315 = Char_IsPunctuation_m619E42D942E22C9BA1DDB8E704BECA546C376473(L_3314, NULL);
		if (!L_3315)
		{
			goto IL_5ace;
		}
	}
	{
		Il2CppChar L_3316 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3317;
		L_3317 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3316, NULL);
		if (L_3317)
		{
			goto IL_5ace;
		}
	}
	{
		Il2CppChar L_3318 = V_242;
		if ((((int32_t)L_3318) == ((int32_t)((int32_t)8203))))
		{
			goto IL_5ace;
		}
	}
	{
		int32_t L_3319 = V_240;
		int32_t L_3320 = __this->___m_CharacterCount_48;
		G_B814_0 = ((((int32_t)L_3319) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3320, 1))))? 1 : 0);
		goto IL_5acf;
	}

IL_5ace:
	{
		G_B814_0 = 1;
	}

IL_5acf:
	{
		G_B816_0 = G_B814_0;
		goto IL_5ad2;
	}

IL_5ad1:
	{
		G_B816_0 = 0;
	}

IL_5ad2:
	{
		G_B818_0 = G_B816_0;
		goto IL_5ad5;
	}

IL_5ad4:
	{
		G_B818_0 = 1;
	}

IL_5ad5:
	{
		V_305 = (bool)G_B818_0;
		bool L_3321 = V_305;
		if (!L_3321)
		{
			goto IL_5c40;
		}
	}
	{
		int32_t L_3322 = V_240;
		if ((((int32_t)L_3322) <= ((int32_t)0)))
		{
			goto IL_5b40;
		}
	}
	{
		int32_t L_3323 = V_240;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3324 = V_54;
		NullCheck(L_3324);
		if ((((int32_t)L_3323) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_3324)->max_length)), 1)))))
		{
			goto IL_5b40;
		}
	}
	{
		int32_t L_3325 = V_240;
		int32_t L_3326 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3325) >= ((int32_t)L_3326)))
		{
			goto IL_5b40;
		}
	}
	{
		Il2CppChar L_3327 = V_242;
		if ((((int32_t)L_3327) == ((int32_t)((int32_t)39))))
		{
			goto IL_5b0f;
		}
	}
	{
		Il2CppChar L_3328 = V_242;
		if ((!(((uint32_t)L_3328) == ((uint32_t)((int32_t)8217)))))
		{
			goto IL_5b40;
		}
	}

IL_5b0f:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3329 = V_54;
		int32_t L_3330 = V_240;
		NullCheck(L_3329);
		Il2CppChar L_3331 = ((L_3329)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3330, 1)))))->___character_0;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3332;
		L_3332 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3331, NULL);
		if (!L_3332)
		{
			goto IL_5b40;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3333 = V_54;
		int32_t L_3334 = V_240;
		NullCheck(L_3333);
		Il2CppChar L_3335 = ((L_3333)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3334, 1)))))->___character_0;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3336;
		L_3336 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3335, NULL);
		G_B827_0 = ((((int32_t)L_3336) == ((int32_t)0))? 1 : 0);
		goto IL_5b41;
	}

IL_5b40:
	{
		G_B827_0 = 1;
	}

IL_5b41:
	{
		V_306 = (bool)G_B827_0;
		bool L_3337 = V_306;
		if (!L_3337)
		{
			goto IL_5c3f;
		}
	}
	{
		int32_t L_3338 = V_240;
		int32_t L_3339 = __this->___m_CharacterCount_48;
		if ((!(((uint32_t)L_3338) == ((uint32_t)((int32_t)il2cpp_codegen_subtract(L_3339, 1))))))
		{
			goto IL_5b68;
		}
	}
	{
		Il2CppChar L_3340 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3341;
		L_3341 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3340, NULL);
		if (L_3341)
		{
			goto IL_5b6e;
		}
	}

IL_5b68:
	{
		int32_t L_3342 = V_240;
		G_B832_0 = ((int32_t)il2cpp_codegen_subtract(L_3342, 1));
		goto IL_5b70;
	}

IL_5b6e:
	{
		int32_t L_3343 = V_240;
		G_B832_0 = L_3343;
	}

IL_5b70:
	{
		V_248 = G_B832_0;
		V_41 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3344 = ___textInfo1;
		NullCheck(L_3344);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3345 = L_3344->___wordInfo_11;
		NullCheck(L_3345);
		V_307 = ((int32_t)(((RuntimeArray*)L_3345)->max_length));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3346 = ___textInfo1;
		NullCheck(L_3346);
		int32_t L_3347 = L_3346->___wordCount_5;
		V_308 = L_3347;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3348 = ___textInfo1;
		NullCheck(L_3348);
		int32_t L_3349 = L_3348->___wordCount_5;
		int32_t L_3350 = V_307;
		V_309 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_3349, 1))) > ((int32_t)L_3350))? 1 : 0);
		bool L_3351 = V_309;
		if (!L_3351)
		{
			goto IL_5bc1;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3352 = ___textInfo1;
		NullCheck(L_3352);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** L_3353 = (&L_3352->___wordInfo_11);
		int32_t L_3354 = V_307;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D(L_3353, ((int32_t)il2cpp_codegen_add(L_3354, 1)), TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
	}

IL_5bc1:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3355 = ___textInfo1;
		NullCheck(L_3355);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3356 = L_3355->___wordInfo_11;
		int32_t L_3357 = V_308;
		NullCheck(L_3356);
		int32_t L_3358 = V_42;
		((L_3356)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3357)))->___firstCharacterIndex_0 = L_3358;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3359 = ___textInfo1;
		NullCheck(L_3359);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3360 = L_3359->___wordInfo_11;
		int32_t L_3361 = V_308;
		NullCheck(L_3360);
		int32_t L_3362 = V_248;
		((L_3360)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3361)))->___lastCharacterIndex_1 = L_3362;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3363 = ___textInfo1;
		NullCheck(L_3363);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3364 = L_3363->___wordInfo_11;
		int32_t L_3365 = V_308;
		NullCheck(L_3364);
		int32_t L_3366 = V_248;
		int32_t L_3367 = V_42;
		((L_3364)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3365)))->___characterCount_2 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_3366, L_3367)), 1));
		int32_t L_3368 = V_37;
		V_37 = ((int32_t)il2cpp_codegen_add(L_3368, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3369 = ___textInfo1;
		V_166 = L_3369;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3370 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3371 = V_166;
		NullCheck(L_3371);
		int32_t L_3372 = L_3371->___wordCount_5;
		NullCheck(L_3370);
		L_3370->___wordCount_5 = ((int32_t)il2cpp_codegen_add(L_3372, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3373 = ___textInfo1;
		NullCheck(L_3373);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3374 = L_3373->___lineInfo_13;
		int32_t L_3375 = V_243;
		NullCheck(L_3374);
		int32_t* L_3376 = (&((L_3374)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3375)))->___wordCount_5);
		int32_t* L_3377 = L_3376;
		int32_t L_3378 = *((int32_t*)L_3377);
		*((int32_t*)L_3377) = (int32_t)((int32_t)il2cpp_codegen_add(L_3378, 1));
	}

IL_5c3f:
	{
	}

IL_5c40:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3379 = ___textInfo1;
		NullCheck(L_3379);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3380 = L_3379->___textElementInfo_10;
		int32_t L_3381 = V_240;
		NullCheck(L_3380);
		int32_t L_3382 = ((L_3380)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3381)))->___style_33;
		V_249 = (bool)((((int32_t)((int32_t)((int32_t)L_3382&4))) == ((int32_t)4))? 1 : 0);
		bool L_3383 = V_249;
		V_310 = L_3383;
		bool L_3384 = V_310;
		if (!L_3384)
		{
			goto IL_6107;
		}
	}
	{
		V_311 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3385 = ___textInfo1;
		NullCheck(L_3385);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3386 = L_3385->___textElementInfo_10;
		int32_t L_3387 = V_240;
		NullCheck(L_3386);
		int32_t L_3388 = ((L_3386)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3387)))->___pageNumber_12;
		V_312 = L_3388;
		int32_t L_3389 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3390 = ___generationSettings0;
		NullCheck(L_3390);
		int32_t L_3391 = L_3390->___maxVisibleCharacters_32;
		if ((((int32_t)L_3389) > ((int32_t)L_3391)))
		{
			goto IL_5cc1;
		}
	}
	{
		int32_t L_3392 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3393 = ___generationSettings0;
		NullCheck(L_3393);
		int32_t L_3394 = L_3393->___maxVisibleLines_34;
		if ((((int32_t)L_3392) > ((int32_t)L_3394)))
		{
			goto IL_5cc1;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3395 = ___generationSettings0;
		NullCheck(L_3395);
		int32_t L_3396 = L_3395->___overflowMode_11;
		if ((!(((uint32_t)L_3396) == ((uint32_t)5))))
		{
			goto IL_5cbe;
		}
	}
	{
		int32_t L_3397 = V_312;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3398 = ___generationSettings0;
		NullCheck(L_3398);
		int32_t L_3399 = L_3398->___pageToDisplay_38;
		G_B842_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_3397, 1))) == ((int32_t)L_3399))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5cbf;
	}

IL_5cbe:
	{
		G_B842_0 = 0;
	}

IL_5cbf:
	{
		G_B844_0 = G_B842_0;
		goto IL_5cc2;
	}

IL_5cc1:
	{
		G_B844_0 = 1;
	}

IL_5cc2:
	{
		V_313 = (bool)G_B844_0;
		bool L_3400 = V_313;
		if (!L_3400)
		{
			goto IL_5cd7;
		}
	}
	{
		V_311 = (bool)0;
	}

IL_5cd7:
	{
		Il2CppChar L_3401 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3402;
		L_3402 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3401, NULL);
		if (L_3402)
		{
			goto IL_5cee;
		}
	}
	{
		Il2CppChar L_3403 = V_242;
		G_B849_0 = ((((int32_t)((((int32_t)L_3403) == ((int32_t)((int32_t)8203)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5cef;
	}

IL_5cee:
	{
		G_B849_0 = 0;
	}

IL_5cef:
	{
		V_314 = (bool)G_B849_0;
		bool L_3404 = V_314;
		if (!L_3404)
		{
			goto IL_5d66;
		}
	}
	{
		float L_3405 = V_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3406 = ___textInfo1;
		NullCheck(L_3406);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3407 = L_3406->___textElementInfo_10;
		int32_t L_3408 = V_240;
		NullCheck(L_3407);
		float L_3409 = ((L_3407)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3408)))->___scale_28;
		float L_3410;
		L_3410 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3405, L_3409, NULL);
		V_48 = L_3410;
		int32_t L_3411 = V_312;
		int32_t L_3412 = V_50;
		if ((((int32_t)L_3411) == ((int32_t)L_3412)))
		{
			goto IL_5d2a;
		}
	}
	{
		G_B853_0 = (32767.0f);
		goto IL_5d2c;
	}

IL_5d2a:
	{
		float L_3413 = V_49;
		G_B853_0 = L_3413;
	}

IL_5d2c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3414 = ___textInfo1;
		NullCheck(L_3414);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3415 = L_3414->___textElementInfo_10;
		int32_t L_3416 = V_240;
		NullCheck(L_3415);
		float L_3417 = ((L_3415)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3416)))->___baseLine_24;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3418 = ___generationSettings0;
		NullCheck(L_3418);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3419 = L_3418->___fontAsset_4;
		NullCheck(L_3419);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_3420;
		L_3420 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_3419, NULL);
		V_57 = L_3420;
		float L_3421;
		L_3421 = FaceInfo_get_underlineOffset_mB1CBB29ECFFE69047F35E654E7F90755F95DD251((&V_57), NULL);
		float L_3422 = V_48;
		float L_3423;
		L_3423 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(G_B853_0, ((float)il2cpp_codegen_add(L_3417, ((float)il2cpp_codegen_multiply(L_3421, L_3422)))), NULL);
		V_49 = L_3423;
		int32_t L_3424 = V_312;
		V_50 = L_3424;
	}

IL_5d66:
	{
		bool L_3425 = V_5;
		bool L_3426 = V_311;
		if (!((int32_t)(((((int32_t)L_3425) == ((int32_t)0))? 1 : 0)&(int32_t)L_3426)))
		{
			goto IL_5d90;
		}
	}
	{
		int32_t L_3427 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3428 = V_244;
		int32_t L_3429 = L_3428.___lastVisibleCharacterIndex_9;
		if ((((int32_t)L_3427) > ((int32_t)L_3429)))
		{
			goto IL_5d90;
		}
	}
	{
		Il2CppChar L_3430 = V_242;
		if ((((int32_t)L_3430) == ((int32_t)((int32_t)10))))
		{
			goto IL_5d90;
		}
	}
	{
		Il2CppChar L_3431 = V_242;
		G_B859_0 = ((((int32_t)((((int32_t)L_3431) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5d91;
	}

IL_5d90:
	{
		G_B859_0 = 0;
	}

IL_5d91:
	{
		V_315 = (bool)G_B859_0;
		bool L_3432 = V_315;
		if (!L_3432)
		{
			goto IL_5e37;
		}
	}
	{
		int32_t L_3433 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3434 = V_244;
		int32_t L_3435 = L_3434.___lastVisibleCharacterIndex_9;
		if ((!(((uint32_t)L_3433) == ((uint32_t)L_3435))))
		{
			goto IL_5dba;
		}
	}
	{
		Il2CppChar L_3436 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3437;
		L_3437 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3436, NULL);
		G_B863_0 = ((((int32_t)L_3437) == ((int32_t)0))? 1 : 0);
		goto IL_5dbb;
	}

IL_5dba:
	{
		G_B863_0 = 1;
	}

IL_5dbb:
	{
		V_316 = (bool)G_B863_0;
		bool L_3438 = V_316;
		if (!L_3438)
		{
			goto IL_5e36;
		}
	}
	{
		V_5 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3439 = ___textInfo1;
		NullCheck(L_3439);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3440 = L_3439->___textElementInfo_10;
		int32_t L_3441 = V_240;
		NullCheck(L_3440);
		float L_3442 = ((L_3440)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3441)))->___scale_28;
		V_47 = L_3442;
		float L_3443 = V_48;
		V_317 = (bool)((((float)L_3443) == ((float)(0.0f)))? 1 : 0);
		bool L_3444 = V_317;
		if (!L_3444)
		{
			goto IL_5dfc;
		}
	}
	{
		float L_3445 = V_47;
		V_48 = L_3445;
	}

IL_5dfc:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3446 = ___textInfo1;
		NullCheck(L_3446);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3447 = L_3446->___textElementInfo_10;
		int32_t L_3448 = V_240;
		NullCheck(L_3447);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3449 = (&((L_3447)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3448)))->___bottomLeft_19);
		float L_3450 = L_3449->___x_2;
		float L_3451 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_6), L_3450, L_3451, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3452 = ___textInfo1;
		NullCheck(L_3452);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3453 = L_3452->___textElementInfo_10;
		int32_t L_3454 = V_240;
		NullCheck(L_3453);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3455 = ((L_3453)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3454)))->___underlineColor_30;
		V_43 = L_3455;
	}

IL_5e36:
	{
	}

IL_5e37:
	{
		bool L_3456 = V_5;
		if (!L_3456)
		{
			goto IL_5e46;
		}
	}
	{
		int32_t L_3457 = __this->___m_CharacterCount_48;
		G_B871_0 = ((((int32_t)L_3457) == ((int32_t)1))? 1 : 0);
		goto IL_5e47;
	}

IL_5e46:
	{
		G_B871_0 = 0;
	}

IL_5e47:
	{
		V_318 = (bool)G_B871_0;
		bool L_3458 = V_318;
		if (!L_3458)
		{
			goto IL_5ebf;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3459 = ___textInfo1;
		NullCheck(L_3459);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3460 = L_3459->___textElementInfo_10;
		int32_t L_3461 = V_240;
		NullCheck(L_3460);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3462 = (&((L_3460)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3461)))->___topRight_20);
		float L_3463 = L_3462->___x_2;
		float L_3464 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3463, L_3464, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3465 = ___textInfo1;
		NullCheck(L_3465);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3466 = L_3465->___textElementInfo_10;
		int32_t L_3467 = V_240;
		NullCheck(L_3466);
		float L_3468 = ((L_3466)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3467)))->___scale_28;
		V_250 = L_3468;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3469 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3470 = V_7;
		float L_3471 = V_47;
		float L_3472 = V_250;
		float L_3473 = V_48;
		float L_3474 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3475 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3476 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3477 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3469, L_3470, (&V_33), L_3471, L_3472, L_3473, L_3474, L_3475, L_3476, L_3477, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		goto IL_6104;
	}

IL_5ebf:
	{
		bool L_3478 = V_5;
		if (!L_3478)
		{
			goto IL_5ee1;
		}
	}
	{
		int32_t L_3479 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3480 = V_244;
		int32_t L_3481 = L_3480.___lastCharacterIndex_8;
		if ((((int32_t)L_3479) == ((int32_t)L_3481)))
		{
			goto IL_5ede;
		}
	}
	{
		int32_t L_3482 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3483 = V_244;
		int32_t L_3484 = L_3483.___lastVisibleCharacterIndex_9;
		G_B877_0 = ((((int32_t)((((int32_t)L_3482) < ((int32_t)L_3484))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5edf;
	}

IL_5ede:
	{
		G_B877_0 = 1;
	}

IL_5edf:
	{
		G_B879_0 = G_B877_0;
		goto IL_5ee2;
	}

IL_5ee1:
	{
		G_B879_0 = 0;
	}

IL_5ee2:
	{
		V_319 = (bool)G_B879_0;
		bool L_3485 = V_319;
		if (!L_3485)
		{
			goto IL_5fd4;
		}
	}
	{
		Il2CppChar L_3486 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3487;
		L_3487 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3486, NULL);
		if (L_3487)
		{
			goto IL_5f08;
		}
	}
	{
		Il2CppChar L_3488 = V_242;
		G_B883_0 = ((((int32_t)L_3488) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_5f09;
	}

IL_5f08:
	{
		G_B883_0 = 1;
	}

IL_5f09:
	{
		V_320 = (bool)G_B883_0;
		bool L_3489 = V_320;
		if (!L_3489)
		{
			goto IL_5f69;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3490 = V_244;
		int32_t L_3491 = L_3490.___lastVisibleCharacterIndex_9;
		V_321 = L_3491;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3492 = ___textInfo1;
		NullCheck(L_3492);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3493 = L_3492->___textElementInfo_10;
		int32_t L_3494 = V_321;
		NullCheck(L_3493);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3495 = (&((L_3493)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3494)))->___topRight_20);
		float L_3496 = L_3495->___x_2;
		float L_3497 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3496, L_3497, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3498 = ___textInfo1;
		NullCheck(L_3498);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3499 = L_3498->___textElementInfo_10;
		int32_t L_3500 = V_321;
		NullCheck(L_3499);
		float L_3501 = ((L_3499)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3500)))->___scale_28;
		V_250 = L_3501;
		goto IL_5fa4;
	}

IL_5f69:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3502 = ___textInfo1;
		NullCheck(L_3502);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3503 = L_3502->___textElementInfo_10;
		int32_t L_3504 = V_240;
		NullCheck(L_3503);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3505 = (&((L_3503)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3504)))->___topRight_20);
		float L_3506 = L_3505->___x_2;
		float L_3507 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3506, L_3507, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3508 = ___textInfo1;
		NullCheck(L_3508);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3509 = L_3508->___textElementInfo_10;
		int32_t L_3510 = V_240;
		NullCheck(L_3509);
		float L_3511 = ((L_3509)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3510)))->___scale_28;
		V_250 = L_3511;
	}

IL_5fa4:
	{
		V_5 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3512 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3513 = V_7;
		float L_3514 = V_47;
		float L_3515 = V_250;
		float L_3516 = V_48;
		float L_3517 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3518 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3519 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3520 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3512, L_3513, (&V_33), L_3514, L_3515, L_3516, L_3517, L_3518, L_3519, L_3520, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		goto IL_6104;
	}

IL_5fd4:
	{
		bool L_3521 = V_5;
		if (!L_3521)
		{
			goto IL_5fe3;
		}
	}
	{
		bool L_3522 = V_311;
		G_B890_0 = ((((int32_t)L_3522) == ((int32_t)0))? 1 : 0);
		goto IL_5fe4;
	}

IL_5fe3:
	{
		G_B890_0 = 0;
	}

IL_5fe4:
	{
		V_322 = (bool)G_B890_0;
		bool L_3523 = V_322;
		if (!L_3523)
		{
			goto IL_6060;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3524 = ___textInfo1;
		NullCheck(L_3524);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3525 = L_3524->___textElementInfo_10;
		int32_t L_3526 = V_240;
		NullCheck(L_3525);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3527 = (&((L_3525)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3526, 1)))))->___topRight_20);
		float L_3528 = L_3527->___x_2;
		float L_3529 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3528, L_3529, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3530 = ___textInfo1;
		NullCheck(L_3530);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3531 = L_3530->___textElementInfo_10;
		int32_t L_3532 = V_240;
		NullCheck(L_3531);
		float L_3533 = ((L_3531)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3532, 1)))))->___scale_28;
		V_250 = L_3533;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3534 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3535 = V_7;
		float L_3536 = V_47;
		float L_3537 = V_250;
		float L_3538 = V_48;
		float L_3539 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3540 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3541 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3542 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3534, L_3535, (&V_33), L_3536, L_3537, L_3538, L_3539, L_3540, L_3541, L_3542, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		goto IL_6104;
	}

IL_6060:
	{
		bool L_3543 = V_5;
		if (!L_3543)
		{
			goto IL_6090;
		}
	}
	{
		int32_t L_3544 = V_240;
		int32_t L_3545 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3544) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3545, 1)))))
		{
			goto IL_6090;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3546 = V_43;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3547 = ___textInfo1;
		NullCheck(L_3547);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3548 = L_3547->___textElementInfo_10;
		int32_t L_3549 = V_240;
		NullCheck(L_3548);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3550 = ((L_3548)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3549, 1)))))->___underlineColor_30;
		bool L_3551;
		L_3551 = ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875(L_3546, L_3550, NULL);
		G_B896_0 = ((((int32_t)L_3551) == ((int32_t)0))? 1 : 0);
		goto IL_6091;
	}

IL_6090:
	{
		G_B896_0 = 0;
	}

IL_6091:
	{
		V_323 = (bool)G_B896_0;
		bool L_3552 = V_323;
		if (!L_3552)
		{
			goto IL_6104;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3553 = ___textInfo1;
		NullCheck(L_3553);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3554 = L_3553->___textElementInfo_10;
		int32_t L_3555 = V_240;
		NullCheck(L_3554);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3556 = (&((L_3554)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3555)))->___topRight_20);
		float L_3557 = L_3556->___x_2;
		float L_3558 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3557, L_3558, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3559 = ___textInfo1;
		NullCheck(L_3559);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3560 = L_3559->___textElementInfo_10;
		int32_t L_3561 = V_240;
		NullCheck(L_3560);
		float L_3562 = ((L_3560)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3561)))->___scale_28;
		V_250 = L_3562;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3563 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3564 = V_7;
		float L_3565 = V_47;
		float L_3566 = V_250;
		float L_3567 = V_48;
		float L_3568 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3569 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3570 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3571 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3563, L_3564, (&V_33), L_3565, L_3566, L_3567, L_3568, L_3569, L_3570, L_3571, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
	}

IL_6104:
	{
		goto IL_6182;
	}

IL_6107:
	{
		bool L_3572 = V_5;
		V_324 = L_3572;
		bool L_3573 = V_324;
		if (!L_3573)
		{
			goto IL_6181;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3574 = ___textInfo1;
		NullCheck(L_3574);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3575 = L_3574->___textElementInfo_10;
		int32_t L_3576 = V_240;
		NullCheck(L_3575);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3577 = (&((L_3575)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3576, 1)))))->___topRight_20);
		float L_3578 = L_3577->___x_2;
		float L_3579 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3578, L_3579, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3580 = ___textInfo1;
		NullCheck(L_3580);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3581 = L_3580->___textElementInfo_10;
		int32_t L_3582 = V_240;
		NullCheck(L_3581);
		float L_3583 = ((L_3581)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3582, 1)))))->___scale_28;
		V_250 = L_3583;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3584 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3585 = V_7;
		float L_3586 = V_47;
		float L_3587 = V_250;
		float L_3588 = V_48;
		float L_3589 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3590 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3591 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3592 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3584, L_3585, (&V_33), L_3586, L_3587, L_3588, L_3589, L_3590, L_3591, L_3592, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
	}

IL_6181:
	{
	}

IL_6182:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3593 = ___textInfo1;
		NullCheck(L_3593);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3594 = L_3593->___textElementInfo_10;
		int32_t L_3595 = V_240;
		NullCheck(L_3594);
		int32_t L_3596 = ((L_3594)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3595)))->___style_33;
		V_251 = (bool)((((int32_t)((int32_t)((int32_t)L_3596&((int32_t)64)))) == ((int32_t)((int32_t)64)))? 1 : 0);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3597 = V_241;
		NullCheck(L_3597);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_3598;
		L_3598 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_3597, NULL);
		V_57 = L_3598;
		float L_3599;
		L_3599 = FaceInfo_get_strikethroughOffset_m7997E4A1512FE358331B3A6543C62C92A0AA5CA5((&V_57), NULL);
		V_252 = L_3599;
		bool L_3600 = V_251;
		V_325 = L_3600;
		bool L_3601 = V_325;
		if (!L_3601)
		{
			goto IL_66b9;
		}
	}
	{
		int32_t L_3602 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3603 = ___generationSettings0;
		NullCheck(L_3603);
		int32_t L_3604 = L_3603->___maxVisibleCharacters_32;
		if ((((int32_t)L_3602) > ((int32_t)L_3604)))
		{
			goto IL_6201;
		}
	}
	{
		int32_t L_3605 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3606 = ___generationSettings0;
		NullCheck(L_3606);
		int32_t L_3607 = L_3606->___maxVisibleLines_34;
		if ((((int32_t)L_3605) > ((int32_t)L_3607)))
		{
			goto IL_6201;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3608 = ___generationSettings0;
		NullCheck(L_3608);
		int32_t L_3609 = L_3608->___overflowMode_11;
		if ((!(((uint32_t)L_3609) == ((uint32_t)5))))
		{
			goto IL_61fe;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3610 = ___textInfo1;
		NullCheck(L_3610);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3611 = L_3610->___textElementInfo_10;
		int32_t L_3612 = V_240;
		NullCheck(L_3611);
		int32_t L_3613 = ((L_3611)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3612)))->___pageNumber_12;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3614 = ___generationSettings0;
		NullCheck(L_3614);
		int32_t L_3615 = L_3614->___pageToDisplay_38;
		G_B908_0 = ((((int32_t)((int32_t)il2cpp_codegen_add(L_3613, 1))) == ((int32_t)L_3615))? 1 : 0);
		goto IL_61ff;
	}

IL_61fe:
	{
		G_B908_0 = 1;
	}

IL_61ff:
	{
		G_B910_0 = G_B908_0;
		goto IL_6202;
	}

IL_6201:
	{
		G_B910_0 = 0;
	}

IL_6202:
	{
		V_326 = (bool)G_B910_0;
		bool L_3616 = V_8;
		bool L_3617 = V_326;
		if (!((int32_t)(((((int32_t)L_3616) == ((int32_t)0))? 1 : 0)&(int32_t)L_3617)))
		{
			goto IL_6232;
		}
	}
	{
		int32_t L_3618 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3619 = V_244;
		int32_t L_3620 = L_3619.___lastVisibleCharacterIndex_9;
		if ((((int32_t)L_3618) > ((int32_t)L_3620)))
		{
			goto IL_6232;
		}
	}
	{
		Il2CppChar L_3621 = V_242;
		if ((((int32_t)L_3621) == ((int32_t)((int32_t)10))))
		{
			goto IL_6232;
		}
	}
	{
		Il2CppChar L_3622 = V_242;
		G_B915_0 = ((((int32_t)((((int32_t)L_3622) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_6233;
	}

IL_6232:
	{
		G_B915_0 = 0;
	}

IL_6233:
	{
		V_327 = (bool)G_B915_0;
		bool L_3623 = V_327;
		if (!L_3623)
		{
			goto IL_62ff;
		}
	}
	{
		int32_t L_3624 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3625 = V_244;
		int32_t L_3626 = L_3625.___lastVisibleCharacterIndex_9;
		if ((!(((uint32_t)L_3624) == ((uint32_t)L_3626))))
		{
			goto IL_625c;
		}
	}
	{
		Il2CppChar L_3627 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3628;
		L_3628 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3627, NULL);
		G_B919_0 = ((((int32_t)L_3628) == ((int32_t)0))? 1 : 0);
		goto IL_625d;
	}

IL_625c:
	{
		G_B919_0 = 1;
	}

IL_625d:
	{
		V_328 = (bool)G_B919_0;
		bool L_3629 = V_328;
		if (!L_3629)
		{
			goto IL_62fe;
		}
	}
	{
		V_8 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3630 = ___textInfo1;
		NullCheck(L_3630);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3631 = L_3630->___textElementInfo_10;
		int32_t L_3632 = V_240;
		NullCheck(L_3631);
		float L_3633 = ((L_3631)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3632)))->___pointSize_10;
		V_51 = L_3633;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3634 = ___textInfo1;
		NullCheck(L_3634);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3635 = L_3634->___textElementInfo_10;
		int32_t L_3636 = V_240;
		NullCheck(L_3635);
		float L_3637 = ((L_3635)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3636)))->___scale_28;
		V_52 = L_3637;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3638 = ___textInfo1;
		NullCheck(L_3638);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3639 = L_3638->___textElementInfo_10;
		int32_t L_3640 = V_240;
		NullCheck(L_3639);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3641 = (&((L_3639)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3640)))->___bottomLeft_19);
		float L_3642 = L_3641->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3643 = ___textInfo1;
		NullCheck(L_3643);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3644 = L_3643->___textElementInfo_10;
		int32_t L_3645 = V_240;
		NullCheck(L_3644);
		float L_3646 = ((L_3644)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3645)))->___baseLine_24;
		float L_3647 = V_252;
		float L_3648 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_3642, ((float)il2cpp_codegen_add(L_3646, ((float)il2cpp_codegen_multiply(L_3647, L_3648)))), (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3649 = ___textInfo1;
		NullCheck(L_3649);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3650 = L_3649->___textElementInfo_10;
		int32_t L_3651 = V_240;
		NullCheck(L_3650);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3652 = ((L_3650)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3651)))->___strikethroughColor_31;
		V_44 = L_3652;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3653 = ___textInfo1;
		NullCheck(L_3653);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3654 = L_3653->___textElementInfo_10;
		int32_t L_3655 = V_240;
		NullCheck(L_3654);
		float L_3656 = ((L_3654)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3655)))->___baseLine_24;
		V_53 = L_3656;
	}

IL_62fe:
	{
	}

IL_62ff:
	{
		bool L_3657 = V_8;
		if (!L_3657)
		{
			goto IL_630e;
		}
	}
	{
		int32_t L_3658 = __this->___m_CharacterCount_48;
		G_B925_0 = ((((int32_t)L_3658) == ((int32_t)1))? 1 : 0);
		goto IL_630f;
	}

IL_630e:
	{
		G_B925_0 = 0;
	}

IL_630f:
	{
		V_329 = (bool)G_B925_0;
		bool L_3659 = V_329;
		if (!L_3659)
		{
			goto IL_637b;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3660 = ___textInfo1;
		NullCheck(L_3660);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3661 = L_3660->___textElementInfo_10;
		int32_t L_3662 = V_240;
		NullCheck(L_3661);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3663 = (&((L_3661)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3662)))->___topRight_20);
		float L_3664 = L_3663->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3665 = ___textInfo1;
		NullCheck(L_3665);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3666 = L_3665->___textElementInfo_10;
		int32_t L_3667 = V_240;
		NullCheck(L_3666);
		float L_3668 = ((L_3666)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3667)))->___baseLine_24;
		float L_3669 = V_252;
		float L_3670 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3664, ((float)il2cpp_codegen_add(L_3668, ((float)il2cpp_codegen_multiply(L_3669, L_3670)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3671 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3672 = V_10;
		float L_3673 = V_52;
		float L_3674 = V_52;
		float L_3675 = V_52;
		float L_3676 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3677 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3678 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3679 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3671, L_3672, (&V_33), L_3673, L_3674, L_3675, L_3676, L_3677, L_3678, L_3679, NULL);
		goto IL_66b6;
	}

IL_637b:
	{
		bool L_3680 = V_8;
		if (!L_3680)
		{
			goto IL_638c;
		}
	}
	{
		int32_t L_3681 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3682 = V_244;
		int32_t L_3683 = L_3682.___lastCharacterIndex_8;
		G_B930_0 = ((((int32_t)L_3681) == ((int32_t)L_3683))? 1 : 0);
		goto IL_638d;
	}

IL_638c:
	{
		G_B930_0 = 0;
	}

IL_638d:
	{
		V_330 = (bool)G_B930_0;
		bool L_3684 = V_330;
		if (!L_3684)
		{
			goto IL_6475;
		}
	}
	{
		Il2CppChar L_3685 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3686;
		L_3686 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3685, NULL);
		if (L_3686)
		{
			goto IL_63b3;
		}
	}
	{
		Il2CppChar L_3687 = V_242;
		G_B934_0 = ((((int32_t)L_3687) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_63b4;
	}

IL_63b3:
	{
		G_B934_0 = 1;
	}

IL_63b4:
	{
		V_331 = (bool)G_B934_0;
		bool L_3688 = V_331;
		if (!L_3688)
		{
			goto IL_6416;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3689 = V_244;
		int32_t L_3690 = L_3689.___lastVisibleCharacterIndex_9;
		V_332 = L_3690;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3691 = ___textInfo1;
		NullCheck(L_3691);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3692 = L_3691->___textElementInfo_10;
		int32_t L_3693 = V_332;
		NullCheck(L_3692);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3694 = (&((L_3692)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3693)))->___topRight_20);
		float L_3695 = L_3694->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3696 = ___textInfo1;
		NullCheck(L_3696);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3697 = L_3696->___textElementInfo_10;
		int32_t L_3698 = V_332;
		NullCheck(L_3697);
		float L_3699 = ((L_3697)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3698)))->___baseLine_24;
		float L_3700 = V_252;
		float L_3701 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3695, ((float)il2cpp_codegen_add(L_3699, ((float)il2cpp_codegen_multiply(L_3700, L_3701)))), (0.0f), NULL);
		goto IL_6453;
	}

IL_6416:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3702 = ___textInfo1;
		NullCheck(L_3702);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3703 = L_3702->___textElementInfo_10;
		int32_t L_3704 = V_240;
		NullCheck(L_3703);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3705 = (&((L_3703)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3704)))->___topRight_20);
		float L_3706 = L_3705->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3707 = ___textInfo1;
		NullCheck(L_3707);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3708 = L_3707->___textElementInfo_10;
		int32_t L_3709 = V_240;
		NullCheck(L_3708);
		float L_3710 = ((L_3708)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3709)))->___baseLine_24;
		float L_3711 = V_252;
		float L_3712 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3706, ((float)il2cpp_codegen_add(L_3710, ((float)il2cpp_codegen_multiply(L_3711, L_3712)))), (0.0f), NULL);
	}

IL_6453:
	{
		V_8 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3713 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3714 = V_10;
		float L_3715 = V_52;
		float L_3716 = V_52;
		float L_3717 = V_52;
		float L_3718 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3719 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3720 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3721 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3713, L_3714, (&V_33), L_3715, L_3716, L_3717, L_3718, L_3719, L_3720, L_3721, NULL);
		goto IL_66b6;
	}

IL_6475:
	{
		bool L_3722 = V_8;
		if (!L_3722)
		{
			goto IL_64c6;
		}
	}
	{
		int32_t L_3723 = V_240;
		int32_t L_3724 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3723) >= ((int32_t)L_3724)))
		{
			goto IL_64c6;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3725 = ___textInfo1;
		NullCheck(L_3725);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3726 = L_3725->___textElementInfo_10;
		int32_t L_3727 = V_240;
		NullCheck(L_3726);
		float L_3728 = ((L_3726)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3727, 1)))))->___pointSize_10;
		float L_3729 = V_51;
		if ((!(((float)L_3728) == ((float)L_3729))))
		{
			goto IL_64c3;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3730 = ___textInfo1;
		NullCheck(L_3730);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3731 = L_3730->___textElementInfo_10;
		int32_t L_3732 = V_240;
		NullCheck(L_3731);
		float L_3733 = ((L_3731)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3732, 1)))))->___baseLine_24;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3734 = V_246;
		float L_3735 = L_3734.___y_3;
		float L_3736 = V_53;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_3737;
		L_3737 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(((float)il2cpp_codegen_add(L_3733, L_3735)), L_3736, NULL);
		G_B943_0 = ((((int32_t)L_3737) == ((int32_t)0))? 1 : 0);
		goto IL_64c4;
	}

IL_64c3:
	{
		G_B943_0 = 1;
	}

IL_64c4:
	{
		G_B945_0 = G_B943_0;
		goto IL_64c7;
	}

IL_64c6:
	{
		G_B945_0 = 0;
	}

IL_64c7:
	{
		V_333 = (bool)G_B945_0;
		bool L_3738 = V_333;
		if (!L_3738)
		{
			goto IL_65a0;
		}
	}
	{
		V_8 = (bool)0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3739 = V_244;
		int32_t L_3740 = L_3739.___lastVisibleCharacterIndex_9;
		V_334 = L_3740;
		int32_t L_3741 = V_240;
		int32_t L_3742 = V_334;
		V_335 = (bool)((((int32_t)L_3741) > ((int32_t)L_3742))? 1 : 0);
		bool L_3743 = V_335;
		if (!L_3743)
		{
			goto IL_6546;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3744 = ___textInfo1;
		NullCheck(L_3744);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3745 = L_3744->___textElementInfo_10;
		int32_t L_3746 = V_334;
		NullCheck(L_3745);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3747 = (&((L_3745)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3746)))->___topRight_20);
		float L_3748 = L_3747->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3749 = ___textInfo1;
		NullCheck(L_3749);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3750 = L_3749->___textElementInfo_10;
		int32_t L_3751 = V_334;
		NullCheck(L_3750);
		float L_3752 = ((L_3750)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3751)))->___baseLine_24;
		float L_3753 = V_252;
		float L_3754 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3748, ((float)il2cpp_codegen_add(L_3752, ((float)il2cpp_codegen_multiply(L_3753, L_3754)))), (0.0f), NULL);
		goto IL_6581;
	}

IL_6546:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3755 = ___textInfo1;
		NullCheck(L_3755);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3756 = L_3755->___textElementInfo_10;
		int32_t L_3757 = V_240;
		NullCheck(L_3756);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3758 = (&((L_3756)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3757)))->___topRight_20);
		float L_3759 = L_3758->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3760 = ___textInfo1;
		NullCheck(L_3760);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3761 = L_3760->___textElementInfo_10;
		int32_t L_3762 = V_240;
		NullCheck(L_3761);
		float L_3763 = ((L_3761)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3762)))->___baseLine_24;
		float L_3764 = V_252;
		float L_3765 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3759, ((float)il2cpp_codegen_add(L_3763, ((float)il2cpp_codegen_multiply(L_3764, L_3765)))), (0.0f), NULL);
	}

IL_6581:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3766 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3767 = V_10;
		float L_3768 = V_52;
		float L_3769 = V_52;
		float L_3770 = V_52;
		float L_3771 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3772 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3773 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3774 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3766, L_3767, (&V_33), L_3768, L_3769, L_3770, L_3771, L_3772, L_3773, L_3774, NULL);
		goto IL_66b6;
	}

IL_65a0:
	{
		bool L_3775 = V_8;
		if (!L_3775)
		{
			goto IL_65d1;
		}
	}
	{
		int32_t L_3776 = V_240;
		int32_t L_3777 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3776) >= ((int32_t)L_3777)))
		{
			goto IL_65d1;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3778 = V_241;
		NullCheck(L_3778);
		int32_t L_3779;
		L_3779 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(L_3778, NULL);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3780 = V_54;
		int32_t L_3781 = V_240;
		NullCheck(L_3780);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3782 = ((L_3780)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3781, 1)))))->___fontAsset_4;
		NullCheck(L_3782);
		int32_t L_3783;
		L_3783 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(L_3782, NULL);
		G_B954_0 = ((((int32_t)((((int32_t)L_3779) == ((int32_t)L_3783))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_65d2;
	}

IL_65d1:
	{
		G_B954_0 = 0;
	}

IL_65d2:
	{
		V_336 = (bool)G_B954_0;
		bool L_3784 = V_336;
		if (!L_3784)
		{
			goto IL_663b;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3785 = ___textInfo1;
		NullCheck(L_3785);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3786 = L_3785->___textElementInfo_10;
		int32_t L_3787 = V_240;
		NullCheck(L_3786);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3788 = (&((L_3786)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3787)))->___topRight_20);
		float L_3789 = L_3788->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3790 = ___textInfo1;
		NullCheck(L_3790);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3791 = L_3790->___textElementInfo_10;
		int32_t L_3792 = V_240;
		NullCheck(L_3791);
		float L_3793 = ((L_3791)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3792)))->___baseLine_24;
		float L_3794 = V_252;
		float L_3795 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3789, ((float)il2cpp_codegen_add(L_3793, ((float)il2cpp_codegen_multiply(L_3794, L_3795)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3796 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3797 = V_10;
		float L_3798 = V_52;
		float L_3799 = V_52;
		float L_3800 = V_52;
		float L_3801 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3802 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3803 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3804 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3796, L_3797, (&V_33), L_3798, L_3799, L_3800, L_3801, L_3802, L_3803, L_3804, NULL);
		goto IL_66b6;
	}

IL_663b:
	{
		bool L_3805 = V_8;
		if (!L_3805)
		{
			goto IL_664a;
		}
	}
	{
		bool L_3806 = V_326;
		G_B959_0 = ((((int32_t)L_3806) == ((int32_t)0))? 1 : 0);
		goto IL_664b;
	}

IL_664a:
	{
		G_B959_0 = 0;
	}

IL_664b:
	{
		V_337 = (bool)G_B959_0;
		bool L_3807 = V_337;
		if (!L_3807)
		{
			goto IL_66b6;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3808 = ___textInfo1;
		NullCheck(L_3808);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3809 = L_3808->___textElementInfo_10;
		int32_t L_3810 = V_240;
		NullCheck(L_3809);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3811 = (&((L_3809)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3810, 1)))))->___topRight_20);
		float L_3812 = L_3811->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3813 = ___textInfo1;
		NullCheck(L_3813);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3814 = L_3813->___textElementInfo_10;
		int32_t L_3815 = V_240;
		NullCheck(L_3814);
		float L_3816 = ((L_3814)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3815, 1)))))->___baseLine_24;
		float L_3817 = V_252;
		float L_3818 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3812, ((float)il2cpp_codegen_add(L_3816, ((float)il2cpp_codegen_multiply(L_3817, L_3818)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3819 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3820 = V_10;
		float L_3821 = V_52;
		float L_3822 = V_52;
		float L_3823 = V_52;
		float L_3824 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3825 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3826 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3827 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3819, L_3820, (&V_33), L_3821, L_3822, L_3823, L_3824, L_3825, L_3826, L_3827, NULL);
	}

IL_66b6:
	{
		goto IL_6728;
	}

IL_66b9:
	{
		bool L_3828 = V_8;
		V_338 = L_3828;
		bool L_3829 = V_338;
		if (!L_3829)
		{
			goto IL_6727;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3830 = ___textInfo1;
		NullCheck(L_3830);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3831 = L_3830->___textElementInfo_10;
		int32_t L_3832 = V_240;
		NullCheck(L_3831);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3833 = (&((L_3831)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3832, 1)))))->___topRight_20);
		float L_3834 = L_3833->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3835 = ___textInfo1;
		NullCheck(L_3835);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3836 = L_3835->___textElementInfo_10;
		int32_t L_3837 = V_240;
		NullCheck(L_3836);
		float L_3838 = ((L_3836)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3837, 1)))))->___baseLine_24;
		float L_3839 = V_252;
		float L_3840 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3834, ((float)il2cpp_codegen_add(L_3838, ((float)il2cpp_codegen_multiply(L_3839, L_3840)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3841 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3842 = V_10;
		float L_3843 = V_52;
		float L_3844 = V_52;
		float L_3845 = V_52;
		float L_3846 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3847 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3848 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3849 = ___textInfo1;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3841, L_3842, (&V_33), L_3843, L_3844, L_3845, L_3846, L_3847, L_3848, L_3849, NULL);
	}

IL_6727:
	{
	}

IL_6728:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3850 = ___textInfo1;
		NullCheck(L_3850);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3851 = L_3850->___textElementInfo_10;
		int32_t L_3852 = V_240;
		NullCheck(L_3851);
		int32_t L_3853 = ((L_3851)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3852)))->___style_33;
		V_253 = (bool)((((int32_t)((int32_t)((int32_t)L_3853&((int32_t)512)))) == ((int32_t)((int32_t)512)))? 1 : 0);
		bool L_3854 = V_253;
		V_339 = L_3854;
		bool L_3855 = V_339;
		if (!L_3855)
		{
			goto IL_6afe;
		}
	}
	{
		V_340 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3856 = ___textInfo1;
		NullCheck(L_3856);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3857 = L_3856->___textElementInfo_10;
		int32_t L_3858 = V_240;
		NullCheck(L_3857);
		int32_t L_3859 = ((L_3857)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3858)))->___pageNumber_12;
		V_341 = L_3859;
		int32_t L_3860 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3861 = ___generationSettings0;
		NullCheck(L_3861);
		int32_t L_3862 = L_3861->___maxVisibleCharacters_32;
		if ((((int32_t)L_3860) > ((int32_t)L_3862)))
		{
			goto IL_67b1;
		}
	}
	{
		int32_t L_3863 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3864 = ___generationSettings0;
		NullCheck(L_3864);
		int32_t L_3865 = L_3864->___maxVisibleLines_34;
		if ((((int32_t)L_3863) > ((int32_t)L_3865)))
		{
			goto IL_67b1;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3866 = ___generationSettings0;
		NullCheck(L_3866);
		int32_t L_3867 = L_3866->___overflowMode_11;
		if ((!(((uint32_t)L_3867) == ((uint32_t)5))))
		{
			goto IL_67ae;
		}
	}
	{
		int32_t L_3868 = V_341;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3869 = ___generationSettings0;
		NullCheck(L_3869);
		int32_t L_3870 = L_3869->___pageToDisplay_38;
		G_B971_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_3868, 1))) == ((int32_t)L_3870))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_67af;
	}

IL_67ae:
	{
		G_B971_0 = 0;
	}

IL_67af:
	{
		G_B973_0 = G_B971_0;
		goto IL_67b2;
	}

IL_67b1:
	{
		G_B973_0 = 1;
	}

IL_67b2:
	{
		V_342 = (bool)G_B973_0;
		bool L_3871 = V_342;
		if (!L_3871)
		{
			goto IL_67c7;
		}
	}
	{
		V_340 = (bool)0;
	}

IL_67c7:
	{
		bool L_3872 = V_11;
		bool L_3873 = V_340;
		if (!((int32_t)(((((int32_t)L_3872) == ((int32_t)0))? 1 : 0)&(int32_t)L_3873)))
		{
			goto IL_67f1;
		}
	}
	{
		int32_t L_3874 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3875 = V_244;
		int32_t L_3876 = L_3875.___lastVisibleCharacterIndex_9;
		if ((((int32_t)L_3874) > ((int32_t)L_3876)))
		{
			goto IL_67f1;
		}
	}
	{
		Il2CppChar L_3877 = V_242;
		if ((((int32_t)L_3877) == ((int32_t)((int32_t)10))))
		{
			goto IL_67f1;
		}
	}
	{
		Il2CppChar L_3878 = V_242;
		G_B980_0 = ((((int32_t)((((int32_t)L_3878) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_67f2;
	}

IL_67f1:
	{
		G_B980_0 = 0;
	}

IL_67f2:
	{
		V_343 = (bool)G_B980_0;
		bool L_3879 = V_343;
		if (!L_3879)
		{
			goto IL_6859;
		}
	}
	{
		int32_t L_3880 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3881 = V_244;
		int32_t L_3882 = L_3881.___lastVisibleCharacterIndex_9;
		if ((!(((uint32_t)L_3880) == ((uint32_t)L_3882))))
		{
			goto IL_6818;
		}
	}
	{
		Il2CppChar L_3883 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3884;
		L_3884 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3883, NULL);
		G_B984_0 = ((((int32_t)L_3884) == ((int32_t)0))? 1 : 0);
		goto IL_6819;
	}

IL_6818:
	{
		G_B984_0 = 1;
	}

IL_6819:
	{
		V_344 = (bool)G_B984_0;
		bool L_3885 = V_344;
		if (!L_3885)
		{
			goto IL_6858;
		}
	}
	{
		V_11 = (bool)1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3886 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largePositiveVector2_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3887;
		L_3887 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_3886, NULL);
		V_12 = L_3887;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3888 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largeNegativeVector2_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3889;
		L_3889 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_3888, NULL);
		V_13 = L_3889;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3890 = ___textInfo1;
		NullCheck(L_3890);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3891 = L_3890->___textElementInfo_10;
		int32_t L_3892 = V_240;
		NullCheck(L_3891);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3893 = ((L_3891)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3892)))->___highlightColor_32;
		V_45 = L_3893;
	}

IL_6858:
	{
	}

IL_6859:
	{
		bool L_3894 = V_11;
		V_345 = L_3894;
		bool L_3895 = V_345;
		if (!L_3895)
		{
			goto IL_6a48;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3896 = ___textInfo1;
		NullCheck(L_3896);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3897 = L_3896->___textElementInfo_10;
		int32_t L_3898 = V_240;
		NullCheck(L_3897);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3899 = ((L_3897)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3898)))->___highlightColor_32;
		V_346 = L_3899;
		V_347 = (bool)0;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3900 = V_45;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3901 = V_346;
		bool L_3902;
		L_3902 = ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875(L_3900, L_3901, NULL);
		V_348 = (bool)((((int32_t)L_3902) == ((int32_t)0))? 1 : 0);
		bool L_3903 = V_348;
		if (!L_3903)
		{
			goto IL_698d;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3904 = V_13;
		float L_3905 = L_3904.___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3906 = ___textInfo1;
		NullCheck(L_3906);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3907 = L_3906->___textElementInfo_10;
		int32_t L_3908 = V_240;
		NullCheck(L_3907);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3909 = (&((L_3907)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3908)))->___bottomLeft_19);
		float L_3910 = L_3909->___x_2;
		(&V_13)->___x_2 = ((float)(((float)il2cpp_codegen_add(L_3905, L_3910))/(2.0f)));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3911 = V_12;
		float L_3912 = L_3911.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3913 = ___textInfo1;
		NullCheck(L_3913);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3914 = L_3913->___textElementInfo_10;
		int32_t L_3915 = V_240;
		NullCheck(L_3914);
		float L_3916 = ((L_3914)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3915)))->___descender_25;
		float L_3917;
		L_3917 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_3912, L_3916, NULL);
		(&V_12)->___y_3 = L_3917;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3918 = V_13;
		float L_3919 = L_3918.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3920 = ___textInfo1;
		NullCheck(L_3920);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3921 = L_3920->___textElementInfo_10;
		int32_t L_3922 = V_240;
		NullCheck(L_3921);
		float L_3923 = ((L_3921)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3922)))->___ascender_23;
		float L_3924;
		L_3924 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3919, L_3923, NULL);
		(&V_13)->___y_3 = L_3924;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3925 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3926 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3927 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3928 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3929 = ___textInfo1;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3925, L_3926, (&V_33), L_3927, L_3928, L_3929, NULL);
		V_11 = (bool)1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3930 = V_13;
		V_12 = L_3930;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3931 = ___textInfo1;
		NullCheck(L_3931);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3932 = L_3931->___textElementInfo_10;
		int32_t L_3933 = V_240;
		NullCheck(L_3932);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3934 = (&((L_3932)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3933)))->___topRight_20);
		float L_3935 = L_3934->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3936 = ___textInfo1;
		NullCheck(L_3936);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3937 = L_3936->___textElementInfo_10;
		int32_t L_3938 = V_240;
		NullCheck(L_3937);
		float L_3939 = ((L_3937)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3938)))->___descender_25;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_13), L_3935, L_3939, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3940 = ___textInfo1;
		NullCheck(L_3940);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3941 = L_3940->___textElementInfo_10;
		int32_t L_3942 = V_240;
		NullCheck(L_3941);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3943 = ((L_3941)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3942)))->___highlightColor_32;
		V_45 = L_3943;
		V_347 = (bool)1;
	}

IL_698d:
	{
		bool L_3944 = V_347;
		V_349 = (bool)((((int32_t)L_3944) == ((int32_t)0))? 1 : 0);
		bool L_3945 = V_349;
		if (!L_3945)
		{
			goto IL_6a47;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3946 = V_12;
		float L_3947 = L_3946.___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3948 = ___textInfo1;
		NullCheck(L_3948);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3949 = L_3948->___textElementInfo_10;
		int32_t L_3950 = V_240;
		NullCheck(L_3949);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3951 = (&((L_3949)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3950)))->___bottomLeft_19);
		float L_3952 = L_3951->___x_2;
		float L_3953;
		L_3953 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_3947, L_3952, NULL);
		(&V_12)->___x_2 = L_3953;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3954 = V_12;
		float L_3955 = L_3954.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3956 = ___textInfo1;
		NullCheck(L_3956);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3957 = L_3956->___textElementInfo_10;
		int32_t L_3958 = V_240;
		NullCheck(L_3957);
		float L_3959 = ((L_3957)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3958)))->___descender_25;
		float L_3960;
		L_3960 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_3955, L_3959, NULL);
		(&V_12)->___y_3 = L_3960;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3961 = V_13;
		float L_3962 = L_3961.___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3963 = ___textInfo1;
		NullCheck(L_3963);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3964 = L_3963->___textElementInfo_10;
		int32_t L_3965 = V_240;
		NullCheck(L_3964);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3966 = (&((L_3964)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3965)))->___topRight_20);
		float L_3967 = L_3966->___x_2;
		float L_3968;
		L_3968 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3962, L_3967, NULL);
		(&V_13)->___x_2 = L_3968;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3969 = V_13;
		float L_3970 = L_3969.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3971 = ___textInfo1;
		NullCheck(L_3971);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3972 = L_3971->___textElementInfo_10;
		int32_t L_3973 = V_240;
		NullCheck(L_3972);
		float L_3974 = ((L_3972)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3973)))->___ascender_23;
		float L_3975;
		L_3975 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3970, L_3974, NULL);
		(&V_13)->___y_3 = L_3975;
	}

IL_6a47:
	{
	}

IL_6a48:
	{
		bool L_3976 = V_11;
		if (!L_3976)
		{
			goto IL_6a57;
		}
	}
	{
		int32_t L_3977 = __this->___m_CharacterCount_48;
		G_B996_0 = ((((int32_t)L_3977) == ((int32_t)1))? 1 : 0);
		goto IL_6a58;
	}

IL_6a57:
	{
		G_B996_0 = 0;
	}

IL_6a58:
	{
		V_350 = (bool)G_B996_0;
		bool L_3978 = V_350;
		if (!L_3978)
		{
			goto IL_6a7e;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3979 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3980 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3981 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3982 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3983 = ___textInfo1;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3979, L_3980, (&V_33), L_3981, L_3982, L_3983, NULL);
		goto IL_6afb;
	}

IL_6a7e:
	{
		bool L_3984 = V_11;
		if (!L_3984)
		{
			goto IL_6aa0;
		}
	}
	{
		int32_t L_3985 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3986 = V_244;
		int32_t L_3987 = L_3986.___lastCharacterIndex_8;
		if ((((int32_t)L_3985) == ((int32_t)L_3987)))
		{
			goto IL_6a9d;
		}
	}
	{
		int32_t L_3988 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3989 = V_244;
		int32_t L_3990 = L_3989.___lastVisibleCharacterIndex_9;
		G_B1002_0 = ((((int32_t)((((int32_t)L_3988) < ((int32_t)L_3990))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_6a9e;
	}

IL_6a9d:
	{
		G_B1002_0 = 1;
	}

IL_6a9e:
	{
		G_B1004_0 = G_B1002_0;
		goto IL_6aa1;
	}

IL_6aa0:
	{
		G_B1004_0 = 0;
	}

IL_6aa1:
	{
		V_351 = (bool)G_B1004_0;
		bool L_3991 = V_351;
		if (!L_3991)
		{
			goto IL_6ac7;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3992 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3993 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3994 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3995 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3996 = ___textInfo1;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3992, L_3993, (&V_33), L_3994, L_3995, L_3996, NULL);
		goto IL_6afb;
	}

IL_6ac7:
	{
		bool L_3997 = V_11;
		if (!L_3997)
		{
			goto IL_6ad6;
		}
	}
	{
		bool L_3998 = V_340;
		G_B1009_0 = ((((int32_t)L_3998) == ((int32_t)0))? 1 : 0);
		goto IL_6ad7;
	}

IL_6ad6:
	{
		G_B1009_0 = 0;
	}

IL_6ad7:
	{
		V_352 = (bool)G_B1009_0;
		bool L_3999 = V_352;
		if (!L_3999)
		{
			goto IL_6afb;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4000 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4001 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4002 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4003 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4004 = ___textInfo1;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_4000, L_4001, (&V_33), L_4002, L_4003, L_4004, NULL);
	}

IL_6afb:
	{
		goto IL_6b26;
	}

IL_6afe:
	{
		bool L_4005 = V_11;
		V_353 = L_4005;
		bool L_4006 = V_353;
		if (!L_4006)
		{
			goto IL_6b25;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4007 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4008 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4009 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4010 = ___generationSettings0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4011 = ___textInfo1;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_4007, L_4008, (&V_33), L_4009, L_4010, L_4011, NULL);
	}

IL_6b25:
	{
	}

IL_6b26:
	{
		int32_t L_4012 = V_243;
		V_39 = L_4012;
		int32_t L_4013 = V_240;
		V_149 = L_4013;
		int32_t L_4014 = V_149;
		V_240 = ((int32_t)il2cpp_codegen_add(L_4014, 1));
	}

IL_6b35:
	{
		int32_t L_4015 = V_240;
		int32_t L_4016 = __this->___m_CharacterCount_48;
		V_354 = (bool)((((int32_t)L_4015) < ((int32_t)L_4016))? 1 : 0);
		bool L_4017 = V_354;
		if (L_4017)
		{
			goto IL_3a26;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4018 = ___textInfo1;
		int32_t L_4019 = __this->___m_CharacterCount_48;
		NullCheck(L_4018);
		L_4018->___characterCount_2 = L_4019;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4020 = ___textInfo1;
		int32_t L_4021 = __this->___m_SpriteCount_86;
		NullCheck(L_4020);
		L_4020->___spriteCount_3 = L_4021;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4022 = ___textInfo1;
		int32_t L_4023 = V_38;
		NullCheck(L_4022);
		L_4022->___lineCount_7 = L_4023;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4024 = ___textInfo1;
		int32_t L_4025 = V_37;
		G_B1018_0 = L_4024;
		if (!L_4025)
		{
			G_B1019_0 = L_4024;
			goto IL_6b7e;
		}
	}
	{
		int32_t L_4026 = __this->___m_CharacterCount_48;
		G_B1019_0 = G_B1018_0;
		if ((((int32_t)L_4026) > ((int32_t)0)))
		{
			G_B1020_0 = G_B1018_0;
			goto IL_6b81;
		}
	}

IL_6b7e:
	{
		G_B1021_0 = 1;
		G_B1021_1 = G_B1019_0;
		goto IL_6b83;
	}

IL_6b81:
	{
		int32_t L_4027 = V_37;
		G_B1021_0 = L_4027;
		G_B1021_1 = G_B1020_0;
	}

IL_6b83:
	{
		NullCheck(G_B1021_1);
		G_B1021_1->___wordCount_5 = G_B1021_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4028 = ___textInfo1;
		int32_t L_4029 = __this->___m_PageNumber_58;
		NullCheck(L_4028);
		L_4028->___pageCount_8 = ((int32_t)il2cpp_codegen_add(L_4029, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4030 = ___textInfo1;
		NullCheck(L_4030);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4031 = L_4030->___meshInfo_15;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_4032 = (&__this->___m_Underline_98);
		int32_t L_4033 = L_4032->___materialIndex_3;
		NullCheck(L_4031);
		int32_t L_4034 = V_33;
		((L_4031)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4033)))->___vertexCount_1 = L_4034;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4035 = ___generationSettings0;
		NullCheck(L_4035);
		int32_t L_4036 = L_4035->___geometrySortingOrder_42;
		V_355 = (bool)((!(((uint32_t)L_4036) <= ((uint32_t)0)))? 1 : 0);
		bool L_4037 = V_355;
		if (!L_4037)
		{
			goto IL_6bdd;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4038 = ___textInfo1;
		NullCheck(L_4038);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4039 = L_4038->___meshInfo_15;
		NullCheck(L_4039);
		MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1(((L_4039)->GetAddressAt(static_cast<il2cpp_array_size_t>(0))), 1, NULL);
	}

IL_6bdd:
	{
		V_356 = 1;
		goto IL_6c40;
	}

IL_6be6:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4040 = ___textInfo1;
		NullCheck(L_4040);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4041 = L_4040->___meshInfo_15;
		int32_t L_4042 = V_356;
		NullCheck(L_4041);
		MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830(((L_4041)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4042))), NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4043 = ___generationSettings0;
		NullCheck(L_4043);
		int32_t L_4044 = L_4043->___geometrySortingOrder_42;
		V_357 = (bool)((!(((uint32_t)L_4044) <= ((uint32_t)0)))? 1 : 0);
		bool L_4045 = V_357;
		if (!L_4045)
		{
			goto IL_6c2d;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4046 = ___textInfo1;
		NullCheck(L_4046);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4047 = L_4046->___meshInfo_15;
		int32_t L_4048 = V_356;
		NullCheck(L_4047);
		MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1(((L_4047)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4048))), 1, NULL);
	}

IL_6c2d:
	{
		int32_t L_4049 = V_356;
		V_149 = L_4049;
		int32_t L_4050 = V_149;
		V_356 = ((int32_t)il2cpp_codegen_add(L_4050, 1));
	}

IL_6c40:
	{
		int32_t L_4051 = V_356;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4052 = ___textInfo1;
		NullCheck(L_4052);
		int32_t L_4053 = L_4052->___materialCount_9;
		V_358 = (bool)((((int32_t)L_4051) < ((int32_t)L_4053))? 1 : 0);
		bool L_4054 = V_358;
		if (L_4054)
		{
			goto IL_6be6;
		}
	}

IL_6c5c:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ((Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields*)il2cpp_codegen_static_fields_for(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var))->___zeroVector_5;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___c0, const RuntimeMethod* method) 
{
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_0 = ___c0;
		float L_1 = L_0.___r_0;
		float L_2;
		L_2 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_1, NULL);
		float L_3;
		L_3 = bankers_roundf(((float)il2cpp_codegen_multiply(L_2, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_4 = ___c0;
		float L_5 = L_4.___g_1;
		float L_6;
		L_6 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_5, NULL);
		float L_7;
		L_7 = bankers_roundf(((float)il2cpp_codegen_multiply(L_6, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_8 = ___c0;
		float L_9 = L_8.___b_2;
		float L_10;
		L_10 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_9, NULL);
		float L_11;
		L_11 = bankers_roundf(((float)il2cpp_codegen_multiply(L_10, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_12 = ___c0;
		float L_13 = L_12.___a_3;
		float L_14;
		L_14 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_13, NULL);
		float L_15;
		L_15 = bankers_roundf(((float)il2cpp_codegen_multiply(L_14, (255.0f))));
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_16;
		memset((&L_16), 0, sizeof(L_16));
		Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline((&L_16), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_3), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_7), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_11), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_15), /*hidden argument*/NULL);
		V_0 = L_16;
		goto IL_0065;
	}

IL_0065:
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_17 = V_0;
		return L_17;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline (int32_t ___value0, int32_t ___min1, int32_t ___max2, const RuntimeMethod* method) 
{
	bool V_0 = false;
	bool V_1 = false;
	int32_t V_2 = 0;
	{
		int32_t L_0 = ___value0;
		int32_t L_1 = ___min1;
		V_0 = (bool)((((int32_t)L_0) < ((int32_t)L_1))? 1 : 0);
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_000e;
		}
	}
	{
		int32_t L_3 = ___min1;
		___value0 = L_3;
		goto IL_0019;
	}

IL_000e:
	{
		int32_t L_4 = ___value0;
		int32_t L_5 = ___max2;
		V_1 = (bool)((((int32_t)L_4) > ((int32_t)L_5))? 1 : 0);
		bool L_6 = V_1;
		if (!L_6)
		{
			goto IL_0019;
		}
	}
	{
		int32_t L_7 = ___max2;
		___value0 = L_7;
	}

IL_0019:
	{
		int32_t L_8 = ___value0;
		V_2 = L_8;
		goto IL_001d;
	}

IL_001d:
	{
		int32_t L_9 = V_2;
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline (const RuntimeMethod* method) 
{
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_0;
		memset((&L_0), 0, sizeof(L_0));
		Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline((&L_0), (1.0f), (1.0f), (1.0f), (1.0f), /*hidden argument*/NULL);
		V_0 = L_0;
		goto IL_001d;
	}

IL_001d:
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method) 
{
	{
		float L_0 = ___x0;
		__this->___x_2 = L_0;
		float L_1 = ___y1;
		__this->___y_3 = L_1;
		float L_2 = ___z2;
		__this->___z_4 = L_2;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___a0, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___b1, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___a0;
		float L_1 = L_0.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___b1;
		float L_3 = L_2.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___a0;
		float L_5 = L_4.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___b1;
		float L_7 = L_6.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___a0;
		float L_9 = L_8.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___b1;
		float L_11 = L_10.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), ((float)il2cpp_codegen_add(L_9, L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___a0, float ___d1, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___a0;
		float L_1 = L_0.___x_2;
		float L_2 = ___d1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___a0;
		float L_4 = L_3.___y_3;
		float L_5 = ___d1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___a0;
		float L_7 = L_6.___z_4;
		float L_8 = ___d1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_9), ((float)(L_1/L_2)), ((float)(L_4/L_5)), ((float)(L_7/L_8)), /*hidden argument*/NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = V_0;
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___a0, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___b1, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___a0;
		float L_1 = L_0.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___b1;
		float L_3 = L_2.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___a0;
		float L_5 = L_4.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___b1;
		float L_7 = L_6.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___a0;
		float L_9 = L_8.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___b1;
		float L_11 = L_10.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), ((float)il2cpp_codegen_subtract(L_9, L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline (float ___a0, float ___b1, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float G_B3_0 = 0.0f;
	{
		float L_0 = ___a0;
		float L_1 = ___b1;
		if ((((float)L_0) > ((float)L_1)))
		{
			goto IL_0008;
		}
	}
	{
		float L_2 = ___b1;
		G_B3_0 = L_2;
		goto IL_0009;
	}

IL_0008:
	{
		float L_3 = ___a0;
		G_B3_0 = L_3;
	}

IL_0009:
	{
		V_0 = G_B3_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline (float ___a0, float ___b1, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float G_B3_0 = 0.0f;
	{
		float L_0 = ___a0;
		float L_1 = ___b1;
		if ((((float)L_0) < ((float)L_1)))
		{
			goto IL_0008;
		}
	}
	{
		float L_2 = ___b1;
		G_B3_0 = L_2;
		goto IL_0009;
	}

IL_0008:
	{
		float L_3 = ___a0;
		G_B3_0 = L_3;
	}

IL_0009:
	{
		V_0 = G_B3_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___x0, float ___y1, const RuntimeMethod* method) 
{
	{
		float L_0 = ___x0;
		__this->___x_0 = L_0;
		float L_1 = ___y1;
		__this->___y_1 = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* __this, uint8_t ___r0, uint8_t ___g1, uint8_t ___b2, uint8_t ___a3, const RuntimeMethod* method) 
{
	{
		__this->___rgba_0 = 0;
		uint8_t L_0 = ___r0;
		__this->___r_1 = L_0;
		uint8_t L_1 = ___g1;
		__this->___g_2 = L_1;
		uint8_t L_2 = ___b2;
		__this->___b_3 = L_2;
		uint8_t L_3 = ___a3;
		__this->___a_4 = L_3;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___v0, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___v0;
		float L_1 = L_0.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___v0;
		float L_3 = L_2.___y_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4;
		memset((&L_4), 0, sizeof(L_4));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_4), L_1, L_3, (0.0f), /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_001a;
	}

IL_001a:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_5 = V_0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline (float ___value0, const RuntimeMethod* method) 
{
	bool V_0 = false;
	float V_1 = 0.0f;
	bool V_2 = false;
	{
		float L_0 = ___value0;
		V_0 = (bool)((((float)L_0) < ((float)(0.0f)))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0015;
		}
	}
	{
		V_1 = (0.0f);
		goto IL_002d;
	}

IL_0015:
	{
		float L_2 = ___value0;
		V_2 = (bool)((((float)L_2) > ((float)(1.0f)))? 1 : 0);
		bool L_3 = V_2;
		if (!L_3)
		{
			goto IL_0029;
		}
	}
	{
		V_1 = (1.0f);
		goto IL_002d;
	}

IL_0029:
	{
		float L_4 = ___value0;
		V_1 = L_4;
		goto IL_002d;
	}

IL_002d:
	{
		float L_5 = V_1;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F* __this, float ___r0, float ___g1, float ___b2, float ___a3, const RuntimeMethod* method) 
{
	{
		float L_0 = ___r0;
		__this->___r_0 = L_0;
		float L_1 = ___g1;
		__this->___g_1 = L_1;
		float L_2 = ___b2;
		__this->___b_2 = L_2;
		float L_3 = ___a3;
		__this->___a_3 = L_3;
		return;
	}
}
